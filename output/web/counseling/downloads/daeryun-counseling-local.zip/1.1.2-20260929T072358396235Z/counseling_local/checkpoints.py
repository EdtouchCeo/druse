"""Private, validated inference checkpoints; never part of a published result."""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

from .domain import CounselingError, now, require_revision
from .ollama import check_cancel

KINDS = {"analyze", "refine-record", "interview-questions", "interview-precheck", "interview-report"}
# The released 1.1.1 source validators are unchanged by the synthesis fix.
# Only this audited predecessor may supply matching record-analysis chunks;
# every request hash, model artifact and response is still checked again.
COMPATIBLE_ANALYSIS_IMPLEMENTATIONS = ("d52979fc53241a7feea08f60ce17118c650166cbbad405d95cdc1bdcf37f35e5",)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@lru_cache(maxsize=1)
def implementation_key():
    root = Path(__file__).parent
    return digest({name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in
                   ("checkpoints.py", "analysis.py", "interview.py", "record_refinement.py", "records.py", "ollama.py")})


def source_key(case, session_id, kind, options, *, implementation=None):
    session = next(s for s in case["sessions"] if s["id"] == session_id)
    options = {**options}
    if "workspace" in options:
        options["workspace"] = {k: v for k, v in options["workspace"].items() if k not in ("revision", "updated_at")}
    return digest({"implementation": implementation or implementation_key(), "student": case["student"],
                   "session": session, "kind": kind, "options": options})


def compatible_source_keys(case, session_id, kind, options):
    keys = {source_key(case, session_id, kind, options)}
    if kind == "analyze":
        keys.update(source_key(case, session_id, kind, options, implementation=old)
                    for old in COMPATIBLE_ANALYSIS_IMPLEMENTATIONS)
    return keys


class CheckpointStore:
    def __init__(self, store):
        self.store = store
        with store.connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS analysis_checkpoints (
                case_id TEXT NOT NULL, owner TEXT NOT NULL, session_id TEXT NOT NULL, kind TEXT NOT NULL,
                source_key TEXT NOT NULL, model_key TEXT NOT NULL, options TEXT NOT NULL,
                entries TEXT NOT NULL, updated_at TEXT NOT NULL,
                PRIMARY KEY(case_id, owner, session_id, kind))""")

    def rows(self, case_id, owner):
        with self.store.connect() as db:
            return [dict(row) for row in db.execute("SELECT * FROM analysis_checkpoints WHERE case_id=? AND owner=?", (case_id, owner))]

    def clear(self, case_id, owner, session_id, kind):
        with self.store.connect() as db:
            db.execute("DELETE FROM analysis_checkpoints WHERE case_id=? AND owner=? AND session_id=? AND kind=?", (case_id, owner, session_id, kind))

    def save(self, row, expected_revision):
        with self.store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT revision FROM cases WHERE id=? AND owner=?", (row["case_id"], row["owner"])).fetchone()
            if not current:
                raise CounselingError("case_not_found", "삭제한 학생의 중간 결과를 저장하지 않았습니다.", 404)
            require_revision(dict(current), expected_revision)
            db.execute("INSERT OR REPLACE INTO analysis_checkpoints VALUES (?,?,?,?,?,?,?,?,?)",
                       tuple(row[key] for key in ("case_id", "owner", "session_id", "kind", "source_key", "model_key", "options", "entries", "updated_at")))


class CheckpointModel:
    """Replay only committed outputs, which callers validate again on every run."""
    def __init__(self, model, store, case, owner, session_id, kind, options, stop, lock, authorize, progress):
        self.model, self.store, self.case, self.stop = model, store, case, stop
        self.lock, self.authorize, self.progress = lock, authorize, progress
        self.pending = self.first_key = None
        self.reused = 0
        self.entries = {}
        # An unidentifiable model may still run, but cannot reuse checkpoints.
        identity = model.checkpoint_identity(options["model"], stop)
        self.enabled = bool(identity)
        self.row = {"case_id": case["id"], "owner": owner, "session_id": session_id, "kind": kind,
                    "source_key": source_key(case, session_id, kind, options), "model_key": identity,
                    "options": json.dumps({k: v for k, v in options.items() if k != "workspace"}, ensure_ascii=False)}
        source_keys = compatible_source_keys(case, session_id, kind, options)
        for prior in store.rows(case["id"], owner):
            if self.enabled and prior["source_key"] in source_keys and all(prior[key] == self.row[key] for key in ("session_id", "kind", "model_key")):
                try:
                    entries = json.loads(prior["entries"])
                    if isinstance(entries, dict):
                        self.entries = {k: v for k, v in entries.items() if isinstance(v, dict) and isinstance(v.get("raw"), str) and digest(v["raw"]) == v.get("digest")}
                except (ValueError, TypeError):
                    pass
        self.progress(completed=len(self.entries), reused=0, checkpoint_available=self.enabled)

    def __getattr__(self, key):
        return getattr(self.model, key)

    def begin(self):
        self.first_key = self.pending = None

    def generate(self, *args, **kwargs):
        check_cancel(self.stop)
        request = {"args": args, "kwargs": {k: v for k, v in kwargs.items() if k not in ("stop", "on_transport")}}
        if self.first_key is None:
            self.first_key = digest(request)
        entry = self.entries.get(self.first_key) if self.enabled else None
        if entry:
            self.reused += 1
            self.progress(completed=len(self.entries), reused=self.reused, checkpoint_available=True)
            raw = entry["raw"]
        else:
            raw = self.model.generate(*args, **kwargs)
        self.pending = raw
        return raw

    def commit(self):
        if not self.enabled or self.first_key is None or self.pending is None:
            return
        with self.lock:
            check_cancel(self.stop)
            if self.authorize() != self.row["owner"]:
                raise CounselingError("session_changed", "교사 연결이 바뀌어 중간 결과를 저장하지 않았습니다.", 401)
            self.entries[self.first_key] = {"raw": self.pending, "digest": digest(self.pending)}
            self.row.update(entries=json.dumps(self.entries, ensure_ascii=False), updated_at=now())
            self.store.save(self.row, self.case["revision"])
            self.progress(completed=len(self.entries), reused=self.reused, checkpoint_available=True)
        self.begin()


def begin_checkpoint(model):
    if isinstance(model, CheckpointModel):
        model.begin()


def commit_checkpoint(model):
    if isinstance(model, CheckpointModel):
        model.commit()
