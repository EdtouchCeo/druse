"""Local exports with immutable evidence snapshots; DOCX uses standard OOXML."""
import io
import zipfile
from xml.etree import ElementTree as ET

from .interview import TOPICS, fail, report_source, question_source
from .report import Report


def report_lines(case, session, value, report_id):
    report = next((r for r in value["reports"] if r["id"] == report_id), None)
    if not report:
        fail("report_not_found", "보고서를 선택해 주세요.", 404)
    snapshot = report["source_snapshot"]
    student = snapshot["student"]
    current = report["source_hash"] == report_source(case, session, value)
    title = (student.get("name") or student.get("student_number") or "학생") + " 종합 면접 보고서"
    confirmation = report.get("confirmed")
    status = "교사 확정" if confirmation else "검토 전 초안"
    if report.get("imported_unverified"):
        status += " · 백업에서 가져온 미검증 자료"
    if not current:
        status += " · 이전 자료 기준"
    lines = [("title", title), ("text", status), ("text", f"생성일: {report['created_at'][:10]} / 자료: {snapshot['transcript_filename']}")]
    if confirmation:
        lines.append(("text", f"확정 교사: {confirmation['by']} / 확정일: {confirmation['at'][:10]}"))
    excluded = [u for u in snapshot["utterances"] if u["status"] != "confirmed"]
    lines += [("heading", "분석 범위"), ("text", f"학생부 기재 {len(snapshot['records'])}개 / 확인된 발화 {len(snapshot['utterances'])-len(excluded)}개 / 보류·제외 {len(excluded)}개")]
    for u in excluded:
        lines.append(("text", f"{u['id']} · {u['status']} · {u.get('reason') or '교사 확인 대기'}"))
    for key, heading in TOPICS.items():
        lines.extend([("heading", heading), ("text", report["edited_sections"][key])])
        for statement in report["statements"]:
            if statement["section"] == key:
                for ref in statement["refs"]:
                    lines.append(("text", f"근거 {ref['id']}: {ref['quote']}"))
    lines += [("heading", "교사 최종 의견"), ("text", report["teacher_opinion"] or "작성하지 않음")]
    lines.append(("heading", "검토한 학생부 기재"))
    for r in snapshot["records"]:
        lines.append(("text", f"{r['id']} · {r.get('label','')} · {r.get('pages',[])}쪽\n{r['text']}"))
    lines.append(("heading", "교사가 확인한 실제 문답"))
    for u in snapshot["utterances"]:
        if u["status"] == "confirmed":
            speaker = {"student": "학생", "interviewer": "면접관", "other": "기타"}.get(u["speaker"], "미정")
            lines.append(("text", f"{u['id']} · {speaker} {u.get('timecode','')}\n{u['text']}"))
    return title, lines


def export_report(case, session, value, report_id, kind):
    title, lines = report_lines(case, session, value, report_id)
    if kind == "pdf":
        document = Report(title)
        for style, content in lines:
            if style in ("heading", "title"):
                document.heading(content)
            else:
                document.paragraph(content)
        return document.finish(), "application/pdf"
    if kind != "docx":
        fail("export_format", "PDF 또는 Word 형식을 선택해 주세요.")
    ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    ET.register_namespace("w", ns)
    document = ET.Element(f"{{{ns}}}document")
    body = ET.SubElement(document, f"{{{ns}}}body")
    for style, content in lines:
        for line in content.splitlines() or [""]:
            p = ET.SubElement(body, f"{{{ns}}}p")
            run = ET.SubElement(p, f"{{{ns}}}r")
            props = ET.SubElement(run, f"{{{ns}}}rPr")
            ET.SubElement(props, f"{{{ns}}}rFonts", {f"{{{ns}}}ascii": "Malgun Gothic", f"{{{ns}}}eastAsia": "맑은 고딕"})
            ET.SubElement(props, f"{{{ns}}}sz", {f"{{{ns}}}val": "32" if style == "title" else "26" if style == "heading" else "21"})
            if style != "text":
                ET.SubElement(props, f"{{{ns}}}b")
            ET.SubElement(run, f"{{{ns}}}t", {"{http://www.w3.org/XML/1998/namespace}space": "preserve"}).text = line
    section = ET.SubElement(body, f"{{{ns}}}sectPr")
    ET.SubElement(section, f"{{{ns}}}pgSz", {f"{{{ns}}}w": "11906", f"{{{ns}}}h": "16838"})
    ET.SubElement(section, f"{{{ns}}}pgMar", {f"{{{ns}}}{k}": "1020" for k in ("top", "bottom", "left", "right")})
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        archive.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        archive.writestr("word/document.xml", ET.tostring(document, encoding="utf-8", xml_declaration=True))
    return buffer.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def export_questions(case,session,value):
    if value["question_source"] != question_source(case,session,value):
        fail("stale_questions", "현재 자료로 질문을 생성하고 검토해 주세요.", 409)
    questions=[q for q in value["questions"] if q["status"]=="accepted"]
    if not questions:
        fail("questions_required", "면접에 사용할 질문을 채택하고 저장해 주세요.",409)
    title=(case["student"].get("name") or "학생")+" 모의면접 질문지"
    report=Report(title)
    report.heading(title)
    report.paragraph("학생부 기반 연습 문항 · 교사 검토 후 채택 · 실제 대학 기출 아님")
    for q in questions:
        report.heading(q["id"]+". "+q["question"])
        report.paragraph("확인 목적: "+q["purpose"])
        for ref in q["refs"]:
            report.paragraph("기재 근거: "+ref["quote"])
    return report.finish()
