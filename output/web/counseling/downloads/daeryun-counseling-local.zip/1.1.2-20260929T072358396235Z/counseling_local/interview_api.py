"""Authenticated /api/cases/:id/interview route, hosted by the existing loopback service."""
import json

from .domain import require_revision, session_of, text
from .interview import SYNTHETIC_TRANSCRIPT, configured, fail, mutate, public_workspace
from .interview_export import export_report, export_questions


def dispatch(handler, case, user, body, query):
    app, owner = handler.app, user["id"]
    sid = body.get("session_id", case["current_session_id"]) if handler.command == "POST" else query.get("session_id", [case["current_session_id"]])[0]
    session = session_of(case, sid)
    value = app.interviews.get(case["id"], sid, owner)
    if handler.command == "GET":
        kind = query.get("format", [""])[0]
        if kind == "fixture":
            return handler.send_bytes(SYNTHETIC_TRANSCRIPT.encode(), "text/plain; charset=utf-8", filename="synthetic-transcript.txt")
        if kind == "questions":
            return handler.send_bytes(export_questions(case,session,value), "application/pdf", filename="interview-questions.pdf")
        if kind in ("pdf", "docx"):
            data, mime = export_report(case, session, value, query.get("report_id", [""])[0], kind)
            return handler.send_bytes(data, mime, filename="student-interview-report." + kind)
        if kind == "backup":
            bundle = {"format": "daeryun-interview", "version": 1, "case": case, "workspace": value}
            return handler.send_bytes(json.dumps(bundle, ensure_ascii=False, indent=2).encode(), filename="interview-backup.json")
        jobs = [app.job_public(j) for j in app.jobs.values() if j.get("_owner") == owner and j.get("_kind", "").startswith("interview-") and j["case_id"] == case["id"] and j.get("_session_id") == sid and j["state"] in ("queued", "running")]
        return handler.send_json({"workspace": public_workspace(case, session, value), "job": jobs[-1] if jobs else None})
    if handler.command != "POST":
        fail("method", "지원하지 않는 요청입니다.", 405)
    require_revision(case, body.get("case_revision"))
    require_revision(value, body.get("revision"))
    operation = body.get("operation")
    if app.demo and operation == "restore":
        fail("demo_import", "시연에서는 합성 전사본만 사용합니다. 실제 백업은 교사 계정을 연결해 가져와 주세요.")
    if app.demo and operation == "transcript":
        import base64
        if body.get("file_base64") != base64.b64encode(SYNTHETIC_TRANSCRIPT.encode()).decode():
            fail("demo_transcript", "시연에서는 제공하는 합성 전사본만 올릴 수 있습니다.")
    if operation in ("generate-questions", "precheck", "generate-report"):
        configured(case, session, value)
        model = text(body.get("model", ""), 160)
        if not model:
            fail("model_required", "설치된 로컬 모델을 선택해 주세요.")
        kind = {"generate-questions": "questions", "precheck": "precheck", "generate-report": "report"}[operation]
        return handler.send_json({"job": app.start_job(owner, case, sid, "interview-" + kind, {"model": model, "workspace": value})}, 202)
    with app.jobs_lock:
        if any(j["case_id"] == case["id"] and j["state"] in ("queued", "running") for j in app.jobs.values()):
            fail("job_busy", "분석을 완료하거나 취소한 뒤 수정해 주세요.", 409)
        if app.user()["id"] != owner:
            fail("session_changed", "교사 연결이 바뀌었습니다.", 401)
        result = mutate(case, session, value, operation, body, owner)
        saved = app.interviews.save(result, owner, value["revision"], case["revision"])
    return handler.send_json({"workspace": public_workspace(case, session, saved)})
