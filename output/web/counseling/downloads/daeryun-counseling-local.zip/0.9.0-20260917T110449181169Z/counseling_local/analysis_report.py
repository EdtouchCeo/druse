"""A self-contained student-record report independent of the counseling workflow."""
from __future__ import annotations

import json
from pathlib import Path

from .domain import CounselingError
from .preparation_report import visible_length
from .report import analysis_document_title
from .teacher_report import TeacherReport, finding_area, write_grouped_findings, write_proposed_actions


ANALYSIS_CHAPTERS = ("학습 이력과 학생부 영역 지도", "학업역량", "진로역량", "공동체역량", "종합 진단과 다음 준비")


def analysis_chapter_content(record, analysis):
    sources = {source.get("id"): source for source in record.get("sections", []) if isinstance(source, dict)}
    groups = {key: {"strengths": [], "improvements": []} for key in ("academic", "career", "community", "other")}
    for kind in ("strengths", "improvements"):
        for finding in analysis.get(kind) or []:
            area = finding_area(finding, sources)
            group = "academic" if area in ("학업", "탐구") else "career" if area == "진로" else "community" if area in ("공동체", "자기관리") else "other"
            groups[group][kind].append(finding)
    return sources, groups


def analysis_detail_status(record, analysis):
    """A legacy or sparse analysis stays useful without being called complete."""
    sources, groups = analysis_chapter_content(record, analysis)
    lengths = [visible_length(analysis.get("summary", ""))]
    counts = [len(sources)]
    for group in ("academic", "career", "community"):
        items = groups[group]["strengths"] + groups[group]["improvements"]
        lengths.append(sum(visible_length(item.get(key, "")) for item in items for key in ("text", "guidance")))
        counts.append(len(items))
    actions = analysis.get("actions") or []
    lengths.append(sum(visible_length(item.get(key, "")) for item in actions
                       for key in ("text", "reason", "expected_output", "review_criteria", "teacher_support")))
    counts.append(len(actions))
    missing = [title for title, length, count in zip(ANALYSIS_CHAPTERS, lengths, counts) if length < 650 or count < 3]
    return {"complete": not missing, "missing_chapters": missing, "chapter_characters": lengths}


def require_current_analysis(session):
    """An export must describe the record currently attached to this session."""
    record = session.get("record")
    analysis = session.get("analysis")
    if not record:
        raise CounselingError("record_required", "학생부 PDF를 불러오고 분석하면 학생부 분석 자료를 저장할 수 있습니다. 현재 교사 자료는 교사용 PDF로 저장할 수 있습니다.", 409)
    if not analysis:
        raise CounselingError("analysis_required", "학생부 분석을 완료하면 분석 자료를 저장할 수 있습니다. 현재 교사 자료는 교사용 PDF로 저장할 수 있습니다.", 409)
    if not record.get("sha256") or not analysis.get("record_sha256"):
        raise CounselingError("analysis_source_unverified", "저장된 분석과 현재 학생부의 연결을 확인할 수 없습니다. 학생부를 다시 분석해 주세요.", 409)
    if analysis["record_sha256"] != record["sha256"]:
        raise CounselingError("stale_analysis", "현재 학생부와 저장된 분석의 원본이 다릅니다. 현재 학생부를 다시 분석해 주세요.", 409)
    return record, analysis


def analysis_report_pdf(case, session):
    """Project final analysis only, without consulting or changing teacher decisions."""
    record, analysis = require_current_analysis(session)
    title = analysis_document_title(case, session)
    report = TeacherReport(title)
    report.paragraph(title, 19)
    report.paragraph("학교생활기록부에서 확인한 특징과 앞으로의 준비 방향", 10.5)
    report.paragraph("AI 분석 초안 · 학생부 원문과 해석을 교사가 대조하여 활용합니다.", 9)
    student = session.get("student_snapshot") or case["student"]
    metadata = [f"{student['academic_year']}학년도",
                f"{'중학교' if student['school_stage'] == 'middle' else '고등학교'} {student['grade']}학년"]
    if student.get("student_number"):
        metadata.append("학번 " + student["student_number"])
    if student.get("name"):
        metadata.append(student["name"])
    report.paragraph(" · ".join(metadata), 9)
    report.paragraph("작성일 " + session["date"], 9)
    if case.get("origin") == "synthetic":
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이나 교사의 검토 결과가 아닙니다.", 9)
    if session.get("imported_unverified"):
        report.paragraph("가져온 미검증 참고 자료 · 학생부 원문과 대조하여 확인해야 합니다.", 9)

    sections, groups = analysis_chapter_content(record, analysis)
    status = analysis_detail_status(record, analysis)
    report.paragraph("상세 분석 · 다섯 영역의 근거와 준비 방향" if status["complete"] else "부분 분석 · 상세 근거 추가 필요", 10)
    if not status["complete"]:
        report.paragraph("다음 영역은 상세 분석 분량이나 확인된 근거가 충분하지 않습니다: " + " · ".join(status["missing_chapters"]), 9)
        report.paragraph("아래에는 저장된 판단만 담았습니다. 자료가 적다는 이유로 학생의 역량이 부족하다고 판단하지 않습니다.", 9)
    report.section("01  " + ANALYSIS_CHAPTERS[0])
    criteria = json.loads((Path(__file__).parent / "data" / "analysis-criteria.json").read_text(encoding="utf-8"))
    report.heading(criteria["title"])
    report.paragraph(criteria["scope"], 9)
    report.table(["역량", "평가 관점과 확인할 근거"],
                 [[row["label"], row["criteria"] + "\n" + row["evidence"]] for row in criteria["competencies"]], [80, 423], 9)
    report.heading("학교생활기록부 영역별 평가 관점")
    report.table(["학생부 영역", "확인할 과정과 해석 범위"],
                 [[row["label"], row["criteria"]] for row in criteria["record_areas"]], [110, 393], 9)
    report.paragraph(criteria["interpretation"], 9)
    for source in criteria["sources"]:
        report.paragraph("기준 근거: " + source, 8)
    report.heading("분석 요약")
    report.plan_text(analysis.get("summary") or "제공된 학생부에서 확인한 내용과 근거를 아래 항목별로 정리했습니다.")
    if sections:
        report.heading("실제로 제공된 기록의 범위")
        rows = []
        for source in sections.values():
            period = " · ".join(str(source[key]) + suffix for key, suffix in
                                (("academic_year", "학년도"), ("grade", "학년"), ("semester", "학기")) if source.get(key))
            rows.append([source.get("label") or "학생부 항목", period or "학년·학기 확인 필요",
                         ", ".join(map(str, source.get("pages") or [])) or "확인 필요",
                         "판독한 내용 있음" if source.get("status") == "present" else "항목 상태 확인 필요"])
        report.table(["학생부 영역", "기록 시기", "쪽", "자료 상태"], rows, [180, 135, 50, 138], 9)

    for number, group in enumerate(("academic", "career", "community"), 2):
        report.section(f"{number:02}  " + ANALYSIS_CHAPTERS[number - 1], page_break=status["complete"])
        if group == "career":
            report.paragraph("기록 당시의 관심과 현재 희망은 구분합니다. 대학·학과의 평가요소나 권장과목은 해당 학년도 공식 자료를 확인한 뒤 연결해야 합니다.", 9)
        if group == "community":
            report.paragraph("협업에서는 학생 개인의 실제 역할과 공동 결과를 구분합니다. 역할이 적혀 있지 않다는 이유로 책임감이나 협업능력이 부족하다고 판단하지 않습니다.", 9)
        strengths, improvements = groups[group]["strengths"], groups[group]["improvements"]
        if strengths:
            report.heading("확인된 강점과 이어갈 방향")
            write_grouped_findings(report, strengths, sections)
        if improvements:
            report.heading("실제로 확인된 어려움과 필요한 도움")
            write_grouped_findings(report, improvements, sections, improvement=True)
        if not strengths and not improvements:
            report.paragraph("저장된 분석에 이 영역의 구체적인 판단이 없습니다. 현재 자료만으로 성취나 어려움을 단정할 수 없습니다.")

    report.section("05  " + ANALYSIS_CHAPTERS[4], page_break=status["complete"])
    for kind in ("strengths", "improvements"):
        if groups["other"][kind]:
            report.heading("다른 영역과 함께 살펴볼 관찰")
            write_grouped_findings(report, groups["other"][kind], sections, improvement=kind == "improvements")
    actions = analysis.get("actions") or []
    if actions:
        report.heading("근거에 따른 추천 준비 방향")
        write_proposed_actions(report, actions, sections)

    questions = analysis.get("questions") or []
    if questions:
        report.heading("추가로 확인할 질문")
        for index, question in enumerate(questions, 1):
            report.paragraph(f"{index}. {question}")

    report.heading("자료 범위와 해석 시 참고할 점")
    total = record.get("page_count", 0)
    readable = len(record.get("readable_pages") or [])
    report.paragraph(f"제공된 학교생활기록부 {total}쪽" +
                     (f" · 판독된 자료 {readable}쪽" if readable < total else ""), 9)
    report.paragraph("학생부 기록을 근거로 정리한 자료입니다. 기록에 없는 내용은 학생의 부족함을 뜻하지 않습니다.", 9)
    for item in dict.fromkeys([*(record.get("warnings") or []), *(analysis.get("limitations") or [])]):
        report.paragraph(item, 9)
    return report.finish()
