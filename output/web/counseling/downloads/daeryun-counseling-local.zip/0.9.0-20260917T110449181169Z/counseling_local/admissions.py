"""Version-aware public admission information, with no network or student storage."""
import json
import re
import unicodedata
from functools import lru_cache
from pathlib import Path

ALIASES = {'snu': ['서울대'], 'ku': ['고려대'], 'hyu': ['한양대'], 'kaist': ['카이스트'], 'gist': ['지스트'],
           'dgist': ['디지스트'], 'unist': ['유니스트'], 'postech': ['포스텍', '포항공대'],
           'kentech': ['켄텍', '한국에너지공대'], 'hufs': ['한국외대'], 'knu': ['경북대']}


@lru_cache(maxsize=1)
def admission_catalogue():
    return json.loads((Path(__file__).parent / 'data/admissions.json').read_text(encoding='utf-8'))


def normalize(value):
    return re.sub(r'[\s·._-]', '', unicodedata.normalize('NFKC', value).lower().replace('대학교', '대')) if isinstance(value, str) else ''


def type_name(value):
    compact = normalize(value).replace('전형', '')
    return {'학종': '학생부종합', '교과': '학생부교과', '종합': '학생부종합'}.get(compact, compact)


def university_parts(value):
    value = unicodedata.normalize('NFKC', value or '').strip()
    match = re.search(r'\s*\(?\s*(서울|다빈치|안성|국제|글로벌|ERICA|에리카|WISE|와이즈|경주|나주)\s*(?:캠퍼스)?\s*\)?$', value, re.I)
    if not match:
        return normalize(value), ''
    campus = {'안성': '다빈치', '에리카': 'erica', '와이즈': 'wise', '경주': 'wise'}.get(match.group(1).lower(), match.group(1).lower())
    return normalize(value[:match.start()].strip()), campus


def university_matches(base, university):
    return base in {normalize(name) for name in [university['name'], university['name'].split('(')[0], university['id'], *ALIASES.get(university['id'], [])]}


def matching_links(directory, base, campus='', university=None):
    names = {base}
    if university:
        names.update(normalize(name) for name in [university['name'], university['name'].split('(')[0], *ALIASES.get(university['id'], [])])
    result = []
    for link in directory:
        link_base, link_campus = university_parts(link['name'])
        if link_base not in names:
            continue
        if campus and link_campus and link_campus != campus:
            continue
        if university and link_campus and link_campus not in university.get('campuses', []):
            continue
        result.append(link)
    return result


def route_name(value):
    result = re.sub(r'[()\s·._-]', '', unicodedata.normalize('NFKC', value or '').lower()).replace('전형', '')
    for prefix in ('학생부종합', '학생부교과', '학종', '교과', '수능'):
        if result.startswith(prefix) and len(result) > len(prefix):
            return result[len(prefix):]
    return result


def preparation(value):
    value = type_name(value)
    if '종합' in value:
        return ['희망 전공과 연결되는 과목을 고른 이유와 앞으로 배울 개념을 설명해 보세요. 과목 안에서 생긴 질문을 탐구로 발전시키고, 해석이 바뀐 이유를 자신의 말로 정리하는 준비가 도움이 됩니다.']
    if '교과' in value:
        return ['앞으로 이수할 과목에서 개념 이해와 문제 해결을 안정적으로 이어갈 방법을 정하세요. 대학의 교과 반영 범위와 수능최저가 확인되면 학교 수업과 수능 학습의 준비 범위를 함께 조정합니다.']
    if '논술' in value:
        return ['수업에서 읽는 자료의 주장과 근거를 구분하고, 정해진 조건 안에서 설명을 구성하는 연습을 해보세요. 지원 전형의 논술 유형과 교과 범위가 확인되면 그 범위에 맞춰 준비합니다.']
    if '수능' in value or '정시' in value:
        return ['교과 개념을 연결해 문제를 해결하고 오답의 원인을 설명하는 학습을 이어가세요. 확인된 수능 반영 영역과 학생부·면접 반영 여부에 따라 과목별 준비 범위를 정합니다.']
    return ['관심 전공에서 배우는 내용과 앞으로 선택할 수 있는 과목을 비교하세요. 대학과 전형을 정하면 평가요소에 맞춰 교과 학습, 탐구 설명, 면접 준비의 비중을 조정합니다.']


def get_admission_context(profile):
    data = admission_catalogue()
    targets = []
    for target in (profile or {}).get('admission_targets', []):
        requested = {key: target.get(key, '') for key in ('university', 'major', 'admission_type', 'admission_name')}
        requested['admission_year'] = target.get('admission_year')
        if not any(requested.values()):
            continue
        query_university, campus = university_parts(requested['university'])
        base_matches = [u for u in data['universities'] if university_matches(query_university, u)]
        matching = [u for u in base_matches if not campus or campus in u.get('campuses', [])]
        links = matching_links(data['directory'], query_university, campus)

        row = {'requested': requested, 'match_status': 'university_not_found', 'university': requested['university'],
               'admission_year': None, 'reference_only': True, 'reference_status': '대학별 자료 확인 필요',
               'source_url': '', 'source_title': '', 'reviewed_on': data['reviewed_on'], 'elements': [],
               'course_recommendations': [], 'campus_scope': '', 'links': links, 'notes': [], 'preparation_focus': preparation(requested['admission_type'])}
        if not matching:
            row['match_status'] = 'university_required' if not requested['university'] else 'campus_not_reviewed' if base_matches and campus else 'directory_only' if links else 'university_not_found'
            row['notes'] = ['선택한 대학의 전형요소를 확인한 자료가 아직 없습니다. 입학처에서 해당 대입 학년도와 모집단위의 안내를 확인한 뒤 구체적인 조건을 적용합니다.']
            if row['match_status'] == 'campus_not_reviewed':
                row['notes'].append('입력한 캠퍼스의 시행계획을 확인한 상세자료가 없습니다. 다른 캠퍼스의 전형을 대신 적용하지 않습니다.')
            targets.append(row)
            continue
        university = matching[0]
        for key in ('admission_year', 'source_url', 'source_title', 'reviewed_on'):
            row[key] = university[key]
        row['university'] = university['name']
        row['campus_scope'] = university.get('campus_scope', '')
        year = university['admission_year']
        row['reference_only'] = requested['admission_year'] != year
        campus_label = (' · ' + row['campus_scope']) if row['campus_scope'] else ''
        row['reference_status'] = ((f"{year}학년도 참고자료 · 희망 {requested['admission_year']}학년도와 다름" if requested['admission_year'] else f'{year}학년도 참고자료 · 희망 대입 학년도 미입력') if row['reference_only'] else f'{year}학년도 시행계획') + campus_label + f" · {university['reviewed_on']} 확인"
        row['notes'] = ['이 자료의 전형방법과 권장과목을 희망 대입 학년도의 확정 조건으로 적용하지 않습니다.' if row['reference_only'] else '지원 전 최종 모집요강과 정정 공지를 확인하세요.',
                        '모집단위별 적용 범위는 아래 조건과 공식 자료로 확인합니다. 희망 전공을 입력한 것만으로 지원자격이 확인되지는 않습니다.']
        row['links'] = matching_links(data['directory'], query_university, campus, university)
        type_query = normalize(type_name(requested['admission_type']))
        typed = [route for route in university['routes'] if not type_query or type_query in normalize(route['type']) or type_query in normalize(route['round'])]
        query = route_name(requested['admission_name'])
        exact = [route for route in typed if route_name(route['name']) == query]
        selected = (exact or [route for route in typed if len(query) > 1 and query in route_name(route['name'])]) if query else typed
        # The catalogue's common list contains reviewed course guidance only.
        row['course_recommendations'] = list(university['shared_rules']) if selected else []
        if not selected:
            row['match_status'] = 'route_not_found'
            row['notes'].append('입력한 전형명과 일치하는 검토 자료가 없습니다. 아래 입학처에서 정확한 전형명을 확인하세요.')
        elif not query or len(selected) > 3:
            row['match_status'] = 'overview'
            row['elements'] = [{**route, **{key: [] for key in ('selection', 'csat', 'assessment', 'interview', 'courses', 'exceptions')}, 'eligibility': ''} for route in selected]
            row['notes'].append('전형명을 입력하면 해당 경로의 전형방법과 준비 범위를 볼 수 있습니다.')
        else:
            row['match_status'] = 'matched' if len(selected) == 1 else 'candidates'
            row['elements'] = selected
        targets.append(row)
    return {'targets': targets, 'scope': '대입 학년도와 캠퍼스·전형·모집단위가 맞는 범위만 전략에 반영합니다. 시행계획은 최종 모집요강과 구분합니다.', 'coverage': data.get('coverage', {})}
