# 로컬 학생부 분석·전략 API 계약

2026-09-17 · **0.9.0 구현 기준, 배포용 구현·검증 기록**. 현재 화면은 **학생 자료·로컬 분석 → 결과 대시보드**이며 결과 대시보드는 **학생부 분석 → 대학·학과별 학종 준비 → 질문 중심 학습**으로 이어진다. 원문·상세 분석은 로컬 Ollama에서 처리하고, 두 후속 전략만 로컬에서 변환한 허용 분류와 공개 자료로 외부 생성한다. 자유서술 일반 AI 전송과 이전 `strategy-draft` 생성 경로는 차단한다. 현재 처리 경계와 지원 범위는 [0.9.0 구현 문서](../docs/61-admissions-dashboards-and-private-ai.md)를 따른다. 실제 계정·외부 AI 실행과 운영 배포 상태는 별도로 검증·기록한다.

기존 저장·확정·학생 안내 계약은 보존한다. 아래에 명시한 0.7~0.8 생성 상세는 과거 기록의 해석과 호환을 위한 이력이며 현재 새 생성 경로가 아니다. 과거 [0.7.0](../docs/57-student-record-and-long-term-strategy.md)·[0.7.1](../docs/58-record-area-strategies.md)·[0.7.2](../docs/59-inquiry-question-titles.md)·[0.8.0](../docs/60-admissions-and-future-learning.md)의 사용 지침과 구분한다.

코디네이터: 로컬 Python 서버·저장·Ollama·PDF 보고서·실행기. 프론트: `apps/counseling/`. 학생부 파서: `counseling_local/records.py`. 대륜고 연결: `integrations/daeryun/` 격리 체크아웃. 실제 학생 데이터는 이 소스 폴더에 저장하지 않는다.

로컬 서버는 `127.0.0.1:8765`에서 Vue 빌드(`/counseling/`)와 `/api/*`를 제공한다. JSON 성공 응답은 아래 구조, 오류는 `{error:{code,message}}`. 모든 변경 요청에 `/api/health`가 반환한 `csrf_token`을 `X-Counseling-Token`으로 보낸다. 데이터에는 `privacy: "local_only"`를 고정한다. 웹 배포 일반 상담은 별도 cloud transport를 사용한다.

## Case

```json
{
 "schema_version":1,"id":"uuid","revision":1,"privacy":"local_only",
 "created_at":"ISO","updated_at":"ISO","origin":"teacher",
 "student":{"student_id":"uuid","student_number":"10101","academic_year":2026,"school_stage":"high","grade":1,"name":""},
 "teacher":{"display_name":""},"current_session_id":"uuid",
 "sessions":[{"id":"uuid","date":"2026-09-11","topic":"","student_question":"","context":"","evidence_notes":"","teacher_opinion":"","actions":[{"id":"uuid","text":"","due_date":"","status":"planned"}],"next_date":"","record":null,"analysis":null,"review":null,"confirmed":null}]
}
```

세션의 record와 analysis는 API가 저장한다. 리뷰·확정은 임의 PUT으로 통과시킬 수 없다. PUT은 읽었던 revision을 포함하며 충돌 시 409. 수정된 세션의 review/confirmed를 무효화한다. 기존 확정 세션은 다음 회차로 이어서 쓰고 원본을 보존한다.

## Local API

- GET `/api/health` → `{version,mode:"local",demo:boolean,csrf_token,teacher:null|{id,display_name,approved:true},storage_path,ollama:{available,models:[{name,vision}],message}}`. models는 로컬 모델만.
- POST `/api/auth` `{access_token}` → 승인 교사를 고정 대륜고 endpoint에서 확인 후 로컬 메모리 세션 시작. 분석 본문은 전송하지 않음. 실제 endpoint 배포 전에는 demo로 검증.
- GET `/api/cases` → `{cases:[Case]}`.
- POST `/api/cases` `{student,teacher}` → `{case:Case}`. 최초 세션 생성.
- GET `/api/cases/{id}` → `{case:Case}`.
- PUT `/api/cases/{id}` `{case:Case}` → `{case:Case}`. ID·privacy·원본 보관 제약 검사.
- POST `/api/cases/{id}/sessions` `{revision}` → `{case:Case}`. 이전 상담 참고한 새 회차 생성.
- POST `/api/cases/{id}/record` `{revision,session_id,filename,pdf_base64,password?}` → `{case:Case}`. PDF 20MB/80페이지 제한, 원본은 로컬 개인 저장소. demo 모드는 제공한 합성 PDF 해시만 허용.
- POST `/api/cases/{id}/record-metadata` `{revision,session_id,record_id,section_id,metadata:{academic_year,grade,semester,school_stage},source_checked:true}` → `{case:Case}`. 교사가 원본을 확인하고 해당 PDF 항목의 시기·학교급을 정정한다. 상세 계약은 아래 항목 메타데이터 절을 따른다.
- POST `/api/cases/{id}/analyze` `{revision,session_id,model,goal}` → `{job:{id,state}}`. 시간 상한은 전송하지 않는다. 이전 클라이언트의 `time_budget_minutes`는 형식 호환을 위해 받을 수 있지만 분석에서 시간을 배정하지 않는다.
- GET `/api/cases/{id}/preparation-status?session_id=...` → `{source_hash}`. 현재 학생·분석·기본자료·상담 입력의 결과 연결값을 로컬에서 확인한다.
- POST `/api/cases/{id}/preparation-strategy` `{revision,session_id,stage:"admissions"|"inquiry",target_id}` → 202 `{job}`. 저장한 목표별로 다섯 영역을 순서대로 생성하고 모든 검증 후 보고서를 저장한다. 브라우저는 로컬 모델명·원문·자유서술 프로필을 이 요청에 포함하지 않는다. `inquiry`에는 동일 목표·동일 입력의 최신 `admissions` 결과가 필요하다. 시연 모드는 409 `demo_external_disabled`로 외부 생성을 차단한다.
- GET `/api/cases/{id}/preparation.pdf?session_id=...&kind=admissions|inquiry&target_id=...` → 선택한 목표·단계의 PDF. 다섯 본문 장이 각각 새 페이지에서 시작하고 장문은 다음 페이지로 이어진다. 현재 입력 연결·가져온 자료의 미검증 상태·분량·형식 검사를 통과해야 한다.
- POST `/api/cases/{id}/strategy-draft` → 409 `strategy_workflow_changed`. 이전 단일 전략 생성은 실행하지 않으며 새 대시보드 흐름을 안내한다.
- POST `/api/cases/{id}/review` `{revision,session_id,model?}` → `{job:{id,state}}`. model이 있으면 Ollama 문체 검토, 없으면 자동 점검+교사 수동 검토용 결과. 수동 확인은 아래 별도 경로.
- POST `/api/cases/{id}/confirm` `{revision,session_id,review_acknowledged:true}` → `{case:Case}`. 근거·문체 검토 내용을 교사가 확인. 필수 내용/이력 검사.
- GET `/api/jobs/{id}` → `{job:{id,state:"queued"|"running"|"succeeded"|"needs_revision"|"failed"|"cancelled",stage,message,case_id}}`.
- POST `/api/jobs/{id}/cancel` `{}` → `{job}`.
- GET `/api/cases/{id}/export` → JSON 첨부. `{format:"daeryun-counseling",version:1,case:Case}`.
- POST `/api/import` `{bundle}` → `{case:Case}`. 새 ID/사본, 이전 확인 표시는 참고 이력으로만 보존. 상담 학생 식별을 UI에서 확인한 뒤 가져오기.
- GET `/api/cases/{id}/report.pdf?session_id=...` → 로컬 생성 PDF. 미확정은 초안 표시.
- GET `/api/cases/{id}/report.pdf?session_id=...&audience=analysis` → 학생부 분석 보고서. 현재 학생부와 분석의 원본 해시가 일치하면 준비·상담·전략·확정 없이 출력할 수 있다. 누락·해시 미확인·다른 원본 분석은 409. 읽기 전용이며 분석 요약·영역별 관찰의 의미·발전 방향·학생 준비 제안을 담는다. 원문 인용·확인 위치·내부 식별자와 분석 순서·처리 정보는 기본 문서에 반복하지 않는다. 교사 기본자료·사전 전략·상담 메모·중간 분석은 제외하고 가져온 분석의 미검증 표시는 유지한다. 저장된 인용과 원본 해시는 바꾸지 않는다.
- GET `/api/cases/{id}/report.pdf?session_id=...&audience=student` → 현재 내용의 교사 확정 후 학생 안내 PDF. 미확정·해시 불일치·전략 내용이 모두 빈 경우는 409. `audience=teacher` 또는 생략은 원문 분석·전략을 포함한 교사용 보고서이며 초안 출력 가능. 학생용에는 전략 9개 항목, 전략 제목·작성일, 학년도·학번, 학생·담당 교사 표시 이름을 포함한다. 이전 `actions` 배열·과제 점검일·진행 상태·다음 점검일은 출력하지 않는다. 또한 학생부 원문·AI 분석 상세·교사 내부 메모는 제외한다. 교사가 직접 전달하며 온라인 게시하지 않는다. 교사용 제목은 학생명 학생부 분석 자료, 학생용 제목은 학생명 학습·진로 전략 보고서이며 합성자료 시연의 확정은 실제 교사 검토와 구분한다.
- GET `/api/fixtures` → `{fixtures:[{id,title,description}]}`; GET `/api/fixtures/{id}.pdf` 합성 PDF 다운로드.

## Record/Analysis

records.py는 `extract_record(pdf_bytes: bytes, filename: str, password: str|None=None) -> dict`를 제공한다. 출력은 `{id,filename,sha256,page_count,school_stage,sections:[{id,category,label,school_stage,academic_year,grade,semester,pages:[1],text,status}],warnings:[str],readable_pages:[int],unreadable_pages:[int]}`. status는 `present|empty|not_applicable|uncertain`. 범위에 없는 항목은 임의 empty로 추가하지 않는다. PDF의 식별 머리말은 분석에 불필요하면 제외하며 원문 페이지와 수치는 보존한다.

analysis는 `{summary,strengths:[{area,text,evidence_ids:[section-id],quote,guidance}],improvements:[{area,text,evidence_ids:[section-id],quote,guidance}],questions:[str],actions:[{area,text,reason,evidence_ids:[section-id],expected_output,review_criteria,teacher_support}],limitations:[str],model,created_at}`. area는 학업·탐구·진로·공동체·자기관리·기타 중 하나다. 이전 결과에 새 필드가 없어도 원래 내용은 보존한다. Ollama 결과에서 실재하고 present인 section ID만 인용하며 원문 인용 후보를 검증한다. 분석 텍스트는 사실 확인을 위한 초안이다. 일부 기본자료·전략·상담 미입력은 분석을 막지 않으며 누락/빈칸만으로 약점을 판단하지 않는다. 전략의 시간 계획은 학생이 세운다.

분석 화면·PDF는 `data/analysis-criteria.json`의 3역량·학생부 8영역별 평가 관점을 함께 제공한다. 프로젝트 지식베이스의 학종 시행계획·SL-P01~SL-P10을 바탕으로 한 교육적 해석이며 대학 공통 배점표가 아니다. 상세 근거·분량 기준에 미달하는 이전 분석도 읽을 수 있지만 PDF에 `부분 분석 · 상세 근거 추가 필요`를 표시하며 완성된 다섯 장 분석으로 간주하지 않는다.

review는 `{state:"passed"|"needs_revision"|"pending",method:"manual"|"ollama",content_hash,notes:[str],created_at}`. content hash와 교사의 확인 기록은 로컬 서버 또는 인증된 cloud API만 생성한다. 프론트가 통과를 만들어 보내지 않는다.

### PDF 항목의 학년도·학년·학기·학교급 확인

`record-metadata`는 승인된 로컬 교사가 소유한 미확정 회차의 **항목 하나**만 수정한다. 화면의 **원문 확인 후 저장** 동작이 `source_checked:true`를 보낸다. 네 메타값을 모두 보내며 `academic_year`는 1900~2100 정수 또는 null, `grade`는 1~6 정수 또는 null(학교급이 middle/high이면 1~3), `semester`는 1/2 또는 null, `school_stage`는 middle/high/unknown이다. 미정 값은 자동 추정하지 않는다. JSON의 문자열 숫자·boolean·추가 키·원문 text·임의 작성자와 시각을 받지 않는다.

이는 **PDF에 기록된 과거 학년도·학년**의 확인이다. Case.student의 현재 학년도·학년·학교급과 별개이며 현재 학생 정보나 다른 PDF 항목에 전파하지 않는다. Record.school_stage는 PDF 전체의 최초 판독값으로 남기고 대상 section.school_stage만 정정한다. 원본 PDF, 파일 SHA-256, record/section ID, text, label, pages, status와 evidence_index·인용 문장은 바꾸지 않는다.

대상 항목에 `metadata_confirmation:{source:"teacher",confirmed_by,confirmed_at,original:{academic_year,grade,semester,school_stage}}`을 서버가 기록한다. original은 최초 수동 확인 전 판독값이며 다시 수정해도 유지한다. record의 `metadata_history`에는 `{section_id,source:"teacher",confirmed_by,confirmed_at,before:{네 값},after:{네 값}}`을 누적한다(최대1,000회). 작성자·시간은 현재 로컬 교사 세션과 서버 시각에서만 온다. 전후 Case 버전도 기존 저장 이력에 남는다. 예전 기록에 이 필드가 없으면 그대로 읽으며 기존 확정 해시는 바뀌지 않는다.

수정하면 해당 회차의 analysis/review/confirmed/guidance를 null로 초기화한다. 작성한 전략·실행과제·사전 전략 사본·상담 내용은 삭제하지 않으므로 교사가 수정한 기간과 기존 계획의 관련성을 다시 대조해야 한다. 원문을 다시 업로드하면 새 판독값으로 시작한다. 가져온 사본의 이력은 형식만 검증해 보존하며 `imported_unverified`를 해제하거나 이전 작성자를 현재 교사로 인정하지 않는다.

추가 OCR의 결과가 이전 항목과 ID·text·pages까지 같으면 수정한 기간과 metadata_confirmation을 유지한다. 다른 원문으로 판독되어 ID가 바뀌면 이전 교사 확인을 새 항목에 자동 적용하지 않으며 metadata_history에는 이전 항목의 이력을 남긴다. 일반 문자 PDF 항목은 OCR 병합으로 바뀌지 않는다.

`source_check_required`/`invalid_record_metadata`는400, 없는 항목은404 `record_section_not_found`, PDF가 바뀌었으면409 `record_changed`, 확정 회차는409 `confirmed_session`이다. revision/CAS 충돌은 기존409를 유지한다. 분석·문체 job이 queued/running이면409 `job_busy`로 완료·취소 후 수정을 요청한다. 기존 CSRF·로컬 교사 인증·소유자 검사를 따르며 범용 Case PUT으로 record를 직접 바꾸면 기존 보호 필드 오류로 거절한다. 온라인 API에는 이 경로가 없다.

## 준비 보고서 저장·전송 계약 (0.9.0)

새 결과는 `session.preparation_reports:{version:1,reports:[Report]}`에 저장한다. 각 Report는 `id,kind,target_id,title,summary,sections,created_at,source_hash,model`과 공개 `sources`, 로컬 `evidence_map`, 로컬 `school_connections`, 후속 단계용 `external_context_token`을 포함할 수 있다. 각 section은 `id,title,overview,items`이고 각 item은 `title,detail,reason,steps,evidence_refs`다. 증거 참조는 `strength:<code>`, `need:<code>`, `public:<sourceid>`로 로컬 근거와 공개 출처를 연결한다. 로컬 원문 인용을 외부 참조로 보내지 않는다.

정확히 다섯 영역에 영역당 세 개 이상 항목, 각 항목 설명 120자 이상·이유 40자 이상·비어 있지 않은 방법 두 개 이상을 요구한다. 같은 설명의 반복을 거절하고 영역 전체의 실질 내용도 검증한다. 저장·PDF는 검증을 통과한 결과만 사용하며 중간 결과를 완성본으로 저장하지 않는다. 동일 목표의 학종 준비 결과를 다시 생성하면 그 이전 결과에 의존한 질문 중심 학습을 다시 생성해야 한다.

`source_hash`는 학생의 현재 학교급·학년·학년도와 분석·기본자료·맥락·근거 메모·교사 의견·상담을 포함한 로컬 입력에서 계산한다. 원본 PDF 해시 하나만 비교하지 않는다. 프런트는 미저장 변경 시 현재 해시를 해제하고 저장 후 다시 조회한다. 해시 미확인·불일치·`imported_unverified` 보고서는 현재 결과로 후속 생성·내보내기를 허용하지 않는다. 확정·안내된 회차의 변경은 새 회차에서 진행한다.

공개 자료가 연결된 17개 대학·29개 학과 분류만 외부 요청으로 변환한다. 실제 대학별 개설 학과·교육과정이 모두 검증된 것은 아니며 학년도·캠퍼스·모집단위·공식 자료 범위를 표시한다. 분류로 변환할 수 없는 자유 입력은 외부로 보내지 않는다. 외부에는 허용된 학습 코드·학년·과목/분야·기회/제약 분류와 공개 목표 정보만 사용한다. 학생부 원문·전체 분석·교사 관찰/상담/의견 원문·이름·학번·파일 경로는 로컬에 남는다. 질문 단계는 검증된 앞 단계 연결 토큰을 사용한다.

학교 평가계획·활동·동아리의 실제 명칭·학년도·학년·학기·운영 조건은 프로젝트 지식베이스를 대조해 `school_connections`에 로컬로 연결한다. 해당 연도 실제 운영 여부는 교사가 확인한다. 로컬 `evidence_map`과 이 연결 정보는 외부 AI 입력에 포함하지 않는다.

`preparation_reports` 필드가 있는 모든 사본은 로컬 비공개 자료다. `privacy`를 표준으로 위조하거나 `record`·`analysis`를 삭제해도 온라인 저장·가져오기·AI 요청을 차단한다. 로컬 JSON 백업과 정규화는 보고서·근거·연결 토큰을 보존하며 학생용 조회는 내부 보고서 묶음을 제외한다. 가져온 백업의 이전 검토·확정·게시·근거 신뢰를 현재 교사의 확인으로 승계하지 않는다.

## 기존 직접 작성 전략 저장 계약

각 Session에 `strategy:{target_major,target_path,strengths,gaps,subject_plan,inquiry_plan,activity_plan,semester_plan,student_message}`를 추가한다. 모든 값은 문자열이며 필드당 12,000자 이내다. 기존 기록의 누락 필드는 빈 문자열로 읽고, 빈 기본값 때문에 기존 확정 해시가 달라지지 않도록 유지한다. 전략 변경은 현재 회차의 검토를 무효화하며 확정 회차는 직접 변경할 수 없다. 최종 수동·Ollama 문체 검토 입력에는 소비자용 전략과 분석의 설명 문장을 포함한다. 숨긴 과제·상담 원문·교사 메모·기본자료는 문체 지적 대상으로 삼지 않으며 원문 인용은 수정하지 않는다. 전략이 전혀 없는 과거 기록의 교사 의견은 검토한다. 전체 내용 해시는 계속 모든 보호 대상 입력을 포함한다. 전략이 있으면 `student_message`와 교과·탐구·활동·학년별 계획 중 하나 이상을 요구하며 별도 `actions` 등록은 요구하지 않는다. 과거 교사 의견만으로 작성한 legacy 기록은 호환한다.

학생부 분석과 전략 작성에는 각 단계에 필요한 현재 입력·상담 조건·검증 근거를 구성하고 모델의 실제 입력 예산을 계산한다. 긴 기존 전략 전체를 모든 단계에 반복하지 않으며, 필요한 단계의 계획이나 개요를 참고한다. 저장 원문이나 기존 전략을 짧게 덮어써 예산을 맞추지 않는다. 필수 입력과 근거를 함께 검토할 공간이 부족하면 구분된 오류로 중단하고 이전 기록을 보존한다. 대학별 정보는 아래 공개 자료 계약의 출처와 적용 범위 안에서만 연결한다.

`guidance:null`은 보호 필드다. 로컬에서 온라인 게시 상태를 만들거나 가져온 백업의 게시 상태를 승계하지 않는다. 학생부·분석·파생 전략은 계속 `privacy:"local_only"`로 보관·PDF 생성한다. 0.9.0 후속 전략의 분류 기반 외부 요청은 위 별도 계약을 따른다. 다음 회차는 마지막 회차의 전략과 기본자료를 이어받고 `actions:[]`, `next_date:""`로 시작한다. 이전 날짜·전략 제목만 참고 맥락으로 남기며 원문·분석·검토·확정·게시 상태는 승계하지 않는다. 이전 회차의 과제 데이터는 그대로 보존한다.

## 학생 기본자료

각 회차의 `profile`에는 `target_major,interests,learning_concerns,study_habits,activities,reading,attendance_notes,teacher_observations` 문자열(각 6,000자), `selected_subjects` 목록(중복 없이 최대20개·각100자), `weekly_minutes`(미입력 null 또는 0~2,400 정수), `grades`(최대60개)를 저장한다. 성적 행은 `id,subject,academic_year,semester,grade_scale,rank_grade,score,achievement`를 사용한다. 5등급·9등급·성취도·미확인 체계를 구분하고 석차등급은 해당 척도 범위, 원점수는 0~100으로 검증한다. 서로 다른 등급 체계는 변환하지 않는다.

복수 희망은 선택 입력인 `profile.admission_targets` 배열(최대 12행)에 저장한다. 각 행은 `id`(중복 없는 UUID), `university`(200자), `major`(모집단위·전공, 200자), `admission_type`(100자), `admission_name`(200자), `admission_year`(1990~2100 정수 또는 null)이다. 글은 빈 문자열, 학년도는 null이 기본값이며 대학·전공·전형 중 아는 항목만 적은 부분 행도 허용한다. 전형 유형의 원래 표현을 보존하고 희망 대학·전공·학년도를 자동으로 만들지 않는다. 기존 `target_major`는 별도로 보존한다. 최대 행 수는 입력 용량이며 대학 지원 횟수를 뜻하지 않는다.

0.9.0의 새 입력 화면은 전형 유형을 학생부종합으로 고정하며 다른 유형 선택을 제공하지 않는다. 기존 백업의 전형 필드와 자유 입력값은 보존하지만 새 자동 생성은 검토한 대학·학과 분류로 연결된 목표만 허용한다. 희망 미입력은 학생부 분석을 막지 않으며 목표별 후속 생성에는 사용할 목표가 필요하다.

새 희망 배열이 없거나 비어 있거나 행에 실제 입력 내용이 없으면 내용 해시에서 제외한다. 이전의 비어 있지 않은 기본자료도 기존 확정 해시가 유지된다. 실제 희망 정보가 바뀌면 현재 검토를 무효화하며 확정 회차의 변경은 거부한다. 저장·가져오기·새 회차에서 부분 입력과 원래 행을 보존하고, 희망 미입력으로 분석·전략 작성을 차단하지 않는다. 대학별 정보 안내는 입력값과 검토 자료의 학년도·전형을 대조해 참고 범위를 표시하며 기존 학생부 원문 외부 전송 제한을 유지한다.

빈 기본자료는 이전 확정 해시를 바꾸지 않으며, 내용이 바뀌면 새 최종 검토가 필요하다. 다음 전략에는 자료를 이어받고 확정된 이전 회차는 보존한다. 가져오기에서도 형식과 값 범위를 검증한다. 기본자료의 내부 입력과 교사 메모는 학생 안내 PDF에 자동 포함하지 않는다. 예외적으로 사용자가 입력한 희망 대학·전공·전형·대입 학년도는 교사용·학생용 PDF에 요약한다. 기본 교사용 PDF도 입력 양식과 비공개 메모를 나열하지 않고 분석·현재 전략을 중심으로 구성한다. 문체 검토는 소비자 문서의 설명을 대상으로 하며 비공개 기본자료를 문체 지적 대상으로 삼지 않는다. 학생부 원문과 교사가 입력한 맥락을 구분한다.

## 과거 0.8.0 공개 대학 정보·단일 전략 생성 이력

이 절은 이전 참고 안내와 `strategy-draft` 생성 규칙의 이력이다. 기존 자료는 계속 해석·보존하지만 현재 자동 생성은 위 0.9.0 준비 보고서 계약을 사용한다.

`admissions.py`의 `get_admission_context(profile)`은 로컬 `data/admissions.json`에서 입력한 희망 대학과 전형의 공개 참고자료를 구성한다. 네트워크 요청이나 학생 정보 저장을 하지 않는다. 학생 입력 `requested`와 자료의 `admission_year`, `source_url`, `source_title`, `reviewed_on`, `reference_only`, `reference_status`를 구분한다. 학년도 미입력·불일치는 참고자료로 표시한다.

전형명 미입력은 후보 목록을 우선 제시하고, 대학 미일치·링크만 존재·전형 미일치·복수 후보·단일 일치를 구분한다. 대학 이름만 맞는다고 특정 전형의 수능최저·면접·선택 과목·지원자격을 적용하지 않는다. 캠퍼스와 모집단위별 조건은 공식 자료에서 확인하며 시행계획과 최종 모집요강·정정 공지를 구분한다. 공개 맥락은 전략 생성에 참고자료로 전달하며 자료 속 문장을 사용자 지시로 취급하지 않는다. 로컬 원문과 파생 전략의 외부 전송 제한은 그대로 유지한다.

0.8.0 새 전략은 앞으로의 교과 선택과 배울 개념·방법, 발전시킬 탐구 질문을 중심으로 작성한다. 과거 기록의 관찰은 현재 학습 기반을 설명하는 근거이며 복습·원자료 재확보를 모든 학생의 필수 과제로 만들지 않는다. 필요한 자료가 없을 때의 확보 대안을 제안하고, 현재 상담에서 정한 범위와 미확정 진로를 보존한다.

새 `semester_plan`은 `단계:` 소제목으로 현재 남은 학기와 이후 학년의 1·2학기를 구분한다. 각 단계에는 `과목과 선택 조건`, `학습 개념·방법`, `탐구 질문`, `자료 선정·확보 대안`, `준비 결과`, `필요한 도움`, `다음 단계로 이어지는 이유`가 있어야 한다. 관심이나 여건이 달라질 때는 `방향을 바꿀 때`에 대안을 제시한다. 이미 지난 학년이나 고교 졸업 뒤의 학기를 새 고교 계획에 추가하지 않는다. 날짜나 과거 성적으로 현재 학기를 추정하지 않는다.

해당 내용 검증은 새 생성 응답에 적용한다. 필수 학기·항목이 빠지거나 제목만 채운 응답은 수정 요청하고, 검증이 끝난 결과만 기존 9개 문자열에 저장한다. 필드당 12,000자 한도와 기존 백업·교사 수정·확정 해시 계약은 유지한다.

## 과거 단일 전략 생성과 현재 상담·확정 호환

아래 `run_strategy_draft`·0.7.1·0.7.2의 자동 생성 설명은 과거 구현 이력이다. 현재 API는 해당 생성 요청을 409로 차단한다. 상담 저장·기존 전략 검토·확정·PDF 호환은 계속 유지한다.

0.7.1은 저장 계약을 바꾸지 않고 생성 단계를 방향·근거, 교과·탐구, 영역별 활동 준비, 로드맵·학생 준비사항의 네 단계로 나눈다. `activity_plan`에는 자율·자치활동, 동아리활동, 진로활동, 봉사활동, 독서활동, 행동특성 및 종합의견을 `영역:` 소제목으로 구분한다. 새 생성 응답의 각 영역은 현재 근거·준비 방향·준비할 자료와 결과물·필요한 도움·연결할 교과와 탐구를 포함해야 한다. 영역 누락 재요청은 새 AI 응답에만 적용하고 이전 저장본·교사 작성 문장은 그대로 보존한다.

활동 단계는 최종 분석에 선정된 강점뿐 아니라 해당 영역의 현재 학생부 원문 인용도 균형 있게 제공한다. 원문 인용과 출처를 검증하고 각 영역의 근거를 먼저 확보한 뒤 입력 예산 안에서 추가한다. 이수·활동·자료 보유 사실은 실제 원문이나 확인된 입력에서만 설명하며, 기록이 없는 영역의 조건부 준비를 학생의 과거 실적이나 약점으로 바꾸지 않는다.

새 회차에는 기존과 같이 `workflow_version:2`, `preparation:null`, `consultation:{status:"not_started",date:"",student_response:"",agreed_direction:"",adjustments:"",summary:""}`를 저장한다. 버전 번호는 기존 백업·해시 호환을 위해 유지하며 0.5.0의 강제 입력 순서를 의미하지 않는다. 이전 회차의 버전과 확정 해시는 보존한다.

`run_strategy_draft(ollama,model,case,session,policy,stop,progress,on_transport)`는 `{topic,strategy,analysis?}`를 반환한다. 9개 전략 문자열은 필드당 12,000자 이내이며 교과별 준비, 탐구의 질문·방법·한계·산출물, 현재 학년부터 졸업까지의 발전 방향과 학생 준비사항을 구조화한다. 원문·분석이 있으면 파일 해시와 인용을 검증해 근거로 사용한다. `imported_unverified` 원문·분석은 신뢰된 근거로 사용하지 않으며 기본자료·실제 상담 등 사용 가능한 입력만으로 작성할 수 있다. 입력이 없으면 `strategy_context_required`, 입력 범위를 초과하면 `strategy_context_large` 등 구분된 오류로 이전 기록을 보존한다.

명시적 생성 요청은 현재 전략을 교사가 편집할 새 초안으로 바꾸고 `review`를 무효화한다. `preparation`, `consultation`, `confirmed`, `guidance`, `actions`, `next_date`를 자동으로 작성·완료·확정하지 않는다. 확정·공개된 회차는 생성 대상으로 받지 않는다. 작업은 기존 소유자·revision·단일 case job·취소·교사 연결 검사를 사용한다. 모든 생성 결과를 검증한 뒤 한 번에 저장하며 취소·실패·새 수정과의 충돌에서는 중간 분석이나 전략을 저장하지 않는다.

0.7.2의 로컬 새 생성 `topic`은 학생의 기록·관심·상담과 연결된 탐구질문 한 문장이다. 명사형 표제에 물음표만 붙이거나 여러 질문을 나열한 형식은 `strategy_title_not_question`으로 검증하고 해당 생성 단계를 한 번 재요청한다. 재검증 실패 시 기존 기록을 보존한다. 이 규칙은 새 생성 결과에 적용하며 과거 저장·확정 제목, 일반 저장·가져오기·PDF 출력 과정에서 제목을 강제 변환하지 않는다. `topic`의 기존 200자 문자열 계약과 9개 전략 필드는 유지한다. 온라인 일반 AI의 동일 지침은 프롬프트 안내이며 로컬 강제 검증·재요청과 구분한다. 문서명은 학생명 학생부 분석 자료 / 학생명 학습·진로 전략 보고서를 유지한다.

상담 서술은 항목당 6,000자, 날짜는 유효한 `YYYY-MM-DD`다. 사전 준비 없이 입력할 수 있으며 `not_started` 또는 `in_progress`도 현재 자료로 최종 전략을 검토할 수 있다. 다만 `completed`라고 기록하려면 실제 상담일·학생 반응·합의한 방향이 필요하다. 상담·전략 내용이 바뀌면 현재 검토가 무효화된다. 최종 확정에는 제목·학생 안내·구체적인 계획과 현재 내용의 리뷰 해시·교사 확인이 필요하다.

POST `/api/cases/{id}/prepare` `{revision,session_id}`는 기존 클라이언트와 백업을 위한 선택적 호환 경로로 남는다. 서버가 현재 제목·구체적인 계획을 확인해 `preparation:{prepared_at,prepared_by,topic,strategy,actions}`를 보관하고 상담 상태를 `in_progress`로 설정한다. 이미 준비한 사본은 덮어쓰지 않고 임의 PUT으로 작성자·시간·내용을 바꾸지 못한다. 새 사용자 흐름에서는 이 요청을 필수로 호출하지 않는다.

사전 전략 사본·상담 원문·작업 과정은 소비자용 기본 PDF에 나열하지 않는다. 학생 PDF와 온라인 학생 조회는 원문·내부 입력·비공개 메모를 제외하고 최종 전략을 제공한다. 가져온 사전 전략의 작성자·시각은 백업 참고 이력이며 현재 교사의 신뢰로 승계되지 않는다. 가져오기의 기존 확정·게시·검토 해제와 원본 재확인 조건은 유지한다.

소비자용 교사·분석·학생 PDF에서 `finding.quote`와 `evidence_ids`의 확인 위치를 반복하지 않는다. 별도 자료·분석 화면의 원문 확인 기능과 저장값은 보존한다. 전략 본문의 명시적 원문 근거·확인 위치 행, 출처 행의 내부 자료 ID·플랫폼 경로·개정 식별번호는 표시에서만 제외한다. 공식 자료명·서명·저자·학년도·학기·학교 조건·교사 설명은 보존한다. 과거 무손실 표시 규약과 충돌하면 사용자가 명시적으로 제외한 인용·위치·내부 식별자를 소비자 문서에 반복하지 않는 현재 계약을 적용한다.

PDF의 알려진 LaTeX 화살표와 Markdown·HTML은 읽을 수 있게 표시하며, 일반 금액의 달러 기호와 본문 의미를 보존한다. 저장 문장·원문 인용·확정 해시는 바꾸지 않는다. 새 전략은 장식 기호로 논리를 대신하지 않는 평문으로 생성한다. 실제 입력과 관계없이 붙이던 고정 전략 소개 문구는 출력하지 않는다. 학기별 로드맵은 소제목과 표로 구성한다.

`actions[].text`, `due_date`, `status`, `next_date`, `profile.weekly_minutes`는 이전 백업과 해시 호환을 위해 보존한다. 새로운 UI에서 과제 상태·점검일·시간 배정을 요구하지 않으며, 부족하다는 이유로 확정을 막지 않는다. 다음 회차에는 전략·기본자료만 이어받고 과제·점검 일정은 새로 복사하지 않는다. 이전 회차 원본과 백업에는 기존 값을 보존한다. 학생부 원문·상세 분석은 로컬에서 처리하고 현재 두 후속 전략의 외부 요청은 0.9.0 분류 계약을 따른다.

## 전략 전체 삭제

DELETE `/api/cases/{id}` `{revision}`는 인증된 소유 교사의 전략 전체를 삭제한다. GET에서 확인한 revision과 `X-Counseling-Token`이 필요하다. 성공은 `{deleted:true,case_id}`이며 다른 소유자·없는 기록은 404, 수정 충돌은 409다. 모든 회차·버전 스냅샷을 트랜잭션으로 제거하고 내용 없는 삭제 감사 이벤트만 남긴다. 진행 중 작업·PDF 암호 캐시를 정리하고 늦은 업로드·분석 저장으로 삭제 기록이 되살아나지 않게 한다. 공유될 수 있는 개인 저장소의 원본 PDF는 제거하지 않는다. 학생 계정이나 배정 삭제 기능이 아니다.

## Cloud adapter 연결

`/.netlify/functions/counseling-session` GET Bearer → `{user:{id,role:"teacher"|"student",approved:boolean,display_name,student_id?},ai:{server:boolean}}`.
`/.netlify/functions/counseling-cases` GET 목록, GET `?id=`, POST 생성, PUT 수정, POST `?action=next|confirm|import` 등은 로컬 Case 형식과 대응. 실제 cloud 계약은 integration 담당자가 API.md로 명시하고 프론트에 전달.
`/.netlify/functions/counseling-ai` POST는 입력·개인정보·권한 검사 후 409 `LEGACY_AI_DISABLED`로 이전 일반 AI 실행을 거절한다. 기존 학생 기록 조회나 외부 모델 호출을 수행하지 않는다. 프런트 `cloudTransport.generalAi`도 서버·Gemini·Ollama 선택과 무관하게 fetch 전에 차단한다. 개인 키로 자유서술 본문을 직접 전송하는 예전 경로는 현재 사용하지 않는다.

Cloud에서는 private student PDF 분석 UI를 제공하지 않고 로컬 실행 안내로 연결한다. `preparation_reports`가 있는 사본도 원문·분석과 같은 비공개 자료로 저장·가져오기·게시를 거절한다. Local 브라우저는 학생부 원문을 외부로 직접 보내는 AI transport를 포함하지 않으며, 새 후속 전략은 로컬 서버의 전용 경로가 허용된 분류·공개 정보로만 요청한다. 새 외부 서버 연동의 인증·요청 검증은 통합 API 계약을 따른다.
