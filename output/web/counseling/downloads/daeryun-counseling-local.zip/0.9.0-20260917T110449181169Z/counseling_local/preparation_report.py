"""Offline, substantive chapter reports for the two preparation dashboards."""
from __future__ import annotations

import re

from .domain import CounselingError
from .report import readable_text
from .teacher_report import TeacherReport, evidence_location


REPORT_LABELS = {"admissions": "대학·학과별 학종 준비 전략", "inquiry": "질문 중심 학습 전략"}
MIN_SECTION_CHARACTERS = 650


def visible_length(value):
    return len(re.sub(r"\s+", "", readable_text(value)))


def school_connection_context(connection, student):
    """Preserve source applicability without claiming enrollment or a current task."""
    year, grade, semester = (connection.get(key) for key in ("academic_year", "grade", "semester"))
    scope = " · ".join((f"{year}학년도" if type(year) is int else "학년도 미확인",
                        f"{grade}학년" if type(grade) is int else "대상 학년 미확인",
                        f"{semester}학기" if type(semester) is int else "학기 미확인"))
    notice = "계획 참고 · 현재 이수·과제 공지와 참여 조건을 확인합니다."
    current_grade = student.get("grade")
    if type(grade) is int and type(current_grade) is int and grade != current_grade:
        notice = ("이후 학년의 선택 후보 · 현재 과제나 향후 이수를 확정하지 않습니다." if grade > current_grade
                  else "이전 학년의 참고 자료 · 현재 과제로 적용하지 않습니다.")
    elif type(year) is int and type(student.get("academic_year")) is int and year != student["academic_year"]:
        notice = "다른 학년도의 계획 · 현재 운영과 과제 공지를 다시 확인합니다."
    return scope, notice


def preparation_quality_issue(value):
    """Check stored content too; counting blank pages is never a completion test."""
    if not isinstance(value, dict) or value.get("kind") not in REPORT_LABELS:
        return "보고서 종류를 확인할 수 없습니다."
    if not str(value.get("title") or "").strip() or not str(value.get("summary") or "").strip():
        return "보고서 제목과 요약을 보완해 주세요."
    sections = value.get("sections")
    if not isinstance(sections, list) or len(sections) != 5:
        return "다섯 개의 상세 장을 모두 작성한 뒤 PDF를 저장할 수 있습니다."
    details = set()
    for index, section in enumerate(sections, 1):
        if not isinstance(section, dict) or not str(section.get("title") or "").strip():
            return f"{index}장의 제목을 확인해 주세요."
        items = section.get("items")
        if not isinstance(items, list) or len(items) < 3:
            return f"{index}장에 근거와 방법을 갖춘 세부 항목이 세 개 이상 필요합니다."
        content = [section.get("overview", "")]
        for item in items:
            if not isinstance(item, dict) or not str(item.get("title") or "").strip():
                return f"{index}장의 세부 항목 제목을 확인해 주세요."
            detail, reason = item.get("detail", ""), item.get("reason", "")
            if not isinstance(detail, str) or not isinstance(reason, str) or len(detail.strip()) < 120 or len(reason.strip()) < 40:
                return f"{index}장의 준비 내용과 판단 이유를 구체적으로 보완해 주세요."
            normalized = re.sub(r"\s+", "", readable_text(detail))
            if normalized in details:
                return "같은 상세 설명을 반복한 항목이 있습니다. 각 항목의 서로 다른 목적과 근거를 보완해 주세요."
            details.add(normalized)
            steps = item.get("steps")
            if not isinstance(steps, list) or len(steps) < 2 or any(not isinstance(step, str) or not step.strip() for step in steps):
                return f"{index}장의 각 항목에 구체적인 방법이 두 가지 이상 필요합니다."
            content.extend([item["title"], detail, reason, *steps])
        if sum(visible_length(part) for part in content) < MIN_SECTION_CHARACTERS:
            return f"{index}장의 상세 내용이 부족합니다. 반복이나 빈 공간 없이 근거·내용·방법을 보완해 주세요."
    return ""


def require_preparation_report(case, session, kind, target_id=""):
    if kind not in REPORT_LABELS:
        raise CounselingError("invalid_report_kind", "학종 준비 전략 또는 질문 중심 학습 전략을 선택해 주세요.")
    if session.get("imported_unverified"):
        raise CounselingError("preparation_unverified", "가져온 자료는 원문을 확인하고 전략을 다시 작성한 뒤 PDF로 저장해 주세요.", 409)
    reports = (session.get("preparation_reports") or {}).get("reports") or []
    matching = [value for value in reports if isinstance(value, dict) and value.get("kind") == kind
                and (value.get("target_id") or "") == target_id]
    if not matching:
        raise CounselingError("preparation_required", "선택한 상세 전략을 먼저 작성해 주세요.", 409)
    value = matching[-1]
    from .private_strategy import preparation_source_hash
    if not value.get("source_hash") or value["source_hash"] != preparation_source_hash(case, session):
        raise CounselingError("stale_preparation", "분석이나 입력 자료가 바뀌었습니다. 변경 내용을 반영해 상세 전략을 다시 작성해 주세요.", 409)
    issue = preparation_quality_issue(value)
    if issue:
        raise CounselingError("preparation_incomplete", issue, 409)
    return value


def preparation_report_pdf(case, session, kind, target_id=""):
    """Render only the selected reviewed projection; never add private inputs."""
    value = require_preparation_report(case, session, kind, target_id)
    student = session.get("student_snapshot") or case.get("student") or {}
    name = student.get("name") or student.get("student_number") or "학생"
    title = f"{name} {REPORT_LABELS[kind]}"
    report = TeacherReport(title)
    sources = {source.get("id"): source for source in (session.get("record") or {}).get("sections", [])
               if isinstance(source, dict)}
    for number, section in enumerate(value["sections"], 1):
        if number > 1:
            report.new_page()
        if number == 1:
            report.paragraph(title, 17)
            report.paragraph(value["title"], 11)
            report.paragraph("학종 준비를 위한 제안 · 실행 결과나 합격 가능성의 판단이 아닙니다.", 9)
            if case.get("origin") == "synthetic":
                report.paragraph("합성자료 시연 · 실제 학생의 분석이나 준비 결과가 아닙니다.", 9)
            report.plan_text(value["summary"])
        # Section bars are short; arbitrary generated titles are wrapped below.
        report.section(f"{number:02}  {REPORT_LABELS[kind]} · 상세 {number}장")
        report.paragraph(section["title"], 13)
        if section.get("overview"):
            report.plan_text(section["overview"])
        for position, item in enumerate(section["items"], 1):
            report.heading(f"{position}. {item['title']}")
            report.plan_text(item["detail"])
            report.plan_text("판단과 연결 이유: " + item["reason"])
            for step_number, step in enumerate(item["steps"], 1):
                report.paragraph(f"방법 {step_number}: {step}")
            known_refs = [ref for ref in item.get("evidence_refs", []) if ref in sources]
            if known_refs:
                report.paragraph("연결 자료: " + evidence_location({"evidence_ids": known_refs}, sources), 9)
            evidence_map = value.get("evidence_map") or {}
            for ref in item.get("evidence_refs", []):
                bound = evidence_map.get(ref)
                if isinstance(bound, dict) and bound.get("label"):
                    report.paragraph("연결 근거: " + str(bound["label"]), 9)
        school_chapter = 5 if kind == "admissions" else 4
        if number == school_chapter and value.get("school_connections"):
            report.heading("학교에서 확인할 실제 과제·활동과 조건")
            for connection in value["school_connections"]:
                report.heading(" · ".join(str(connection.get(key) or "") for key in ("subject", "task") if connection.get(key)))
                scope, notice = school_connection_context(connection, student)
                report.paragraph("원문 적용 범위: " + scope, 9)
                report.paragraph(notice, 9)
                if connection.get("status"):
                    report.paragraph("자료 상태: " + str(connection["status"]), 9)
                for label, key in (("연결 이유", "reason"), ("원래 과제 조건", "conditions"), ("출처", "source")):
                    detail = connection.get(key)
                    if detail:
                        report.paragraph(label + ": " + (" · ".join(map(str, detail)) if isinstance(detail, list) else str(detail)))
                if connection.get("learning_topics"):
                    report.paragraph("연결할 학습 내용: " + " · ".join(map(str, connection["learning_topics"])))
                for step_number, step in enumerate(connection.get("steps") or [], 1):
                    report.paragraph(f"원래 수행 절차 {step_number}: {step}")
        report.flush_headings()
    if len(report.doc) < 5:
        report.doc.close()
        raise CounselingError("preparation_incomplete", "다섯 장의 상세 본문이 모두 작성되지 않았습니다.", 409)
    return report.finish()
