"""Closed-vocabulary strategy requests. Private source text never leaves this module."""
from __future__ import annotations

import copy
import json
import re
import ssl
import unicodedata
from pathlib import Path

import httpx

from .domain import CounselingError, digest, new_id, now
from .ollama import check_cancel


DATA = Path(__file__).parent / "data"
ENDPOINT = "https://daeryun.life/.netlify/functions/counseling-strategy"
KINDS = {
    "admissions": ["target_basis", "learner_alignment", "academic_preparation", "experience_preparation", "next_decisions"],
    "inquiry": ["inquiry_question", "concept_learning", "inquiry_method", "school_connection", "reflection_extension"],
}
PATTERNS = {
    "concept_explanation": r"개념.{0,20}설명|자신의 말|자기 설명",
    "textual_evidence": r"텍스트|인용|읽은.{0,12}근거|문헌.{0,12}근거",
    "quantitative_analysis": r"정량|수치|통계|계산|비율|데이터",
    "experiment_design": r"실험.{0,12}설계|실험.{0,12}계획|가설",
    "variable_control": r"변인|통제|대조군|측정 조건",
    "source_evaluation": r"출처|신뢰|자료.{0,12}검토|자료.{0,12}선정",
    "counterexample": r"반례|반박|예외",
    "mathematical_reasoning": r"증명|수학적|추론|논리",
    "data_visualization": r"시각화|그래프|도표|인포그래픽",
    "coding_debugging": r"코딩|프로그래밍|알고리즘|디버깅|구현",
    "model_limitations": r"모델.{0,12}한계|오차|적용.{0,12}범위|가정",
    "question_refinement": r"질문.{0,12}구체|질문.{0,12}수정|질문.{0,12}좁|문제 설정",
    "compare_perspectives": r"관점|대조|다른.{0,12}해석|비교",
    "achievement": r"성취|성적|개념|이해|풀이|문제 해결|문제해결",
    "learning_attitude": r"학습 태도|학습태도|꾸준|복습|자기주도|자기 주도|성실",
    "inquiry": r"탐구|실험|가설|변인|검증|분석|비교|자료",
    "course_selection": r"과목 선택|과목선택|이수|수강|교육과정",
    "major_learning": r"전공|교과.*연결|관련 과목|관련과목",
    "career_exploration": r"진로|관심|직업|탐색|선택 이유",
    "collaboration": r"협업|협력|공동|모둠|팀|협의",
    "care": r"배려|나눔|봉사|도움|경청",
    "responsibility": r"책임|역할|약속|규칙|준수",
    "leadership": r"리더|이끌|조정|주도|조율",
    "reflection": r"성찰|수정|반성|피드백|오류|한계|반례",
    "communication": r"소통|발표|설명|토론|표현|논증",
}
FIELD_WORDS = {
    "humanities": ["국어", "문학", "역사", "언어", "철학"],
    "social_science": ["사회", "사회문제", "정치", "경제", "심리"],
    "business": ["경제", "경영", "수학", "확률", "통계"],
    "science": ["과학", "수학", "생명", "물리", "화학"],
    "engineering": ["공학", "물리", "화학", "수학", "정보"],
    "computing": ["정보", "프로그래밍", "수학", "인공지능", "통계"],
    "health": ["생명", "과학", "화학", "보건", "윤리"],
    "education": ["교육", "사회", "국어", "심리"],
    "arts": ["미술", "음악", "예술", "디자인", "체육"],
    "interdisciplinary": ["과학", "사회", "정보"],
    "undecided": [],
}
OPPORTUNITIES = {
    "literature_review": r"독서|읽기|문헌|자료 조사",
    "data_comparison": r"자료|통계|비교|분석",
    "experiment": r"실험|관찰|측정",
    "debate": r"토론|쟁점|논증",
    "presentation": r"발표|설명",
    "infographic": r"인포그래픽|시각화",
    "coding": r"코딩|프로그래밍|구현|알고리즘",
    "mathematical_model": r"수학|모델|함수|수식",
    "creative_work": r"작품|제작|창작|표현",
    "community_project": r"공동체|봉사|캠페인|협업",
}


def load_json(name):
    try:
        return json.loads((DATA / name).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise CounselingError("strategy_catalog_unavailable", "전략 자료가 설치되지 않았습니다. 최신 로컬 앱으로 다시 실행해 주세요.", 503) from exc


def norm(value):
    return re.sub(r"[\s·._()\-]", "", unicodedata.normalize("NFKC", str(value)).lower()).replace("대학교", "대")


def preparation_source_hash(case, session):
    """Local-only revision of every input that can affect the three-stage strategy."""
    return digest({"student": {k: case.get("student", {}).get(k) for k in ("grade", "school_stage", "academic_year")},
                   "inputs": {k: session.get(k) for k in ("record", "analysis", "profile", "context", "evidence_notes", "teacher_opinion", "student_question", "consultation")}})


def require_analysis(session):
    record, analysis = session.get("record") or {}, session.get("analysis") or {}
    if not record.get("sha256") or not analysis or analysis.get("record_sha256") != record["sha256"]:
        raise CounselingError("analysis_required", "현재 학생부의 로컬 분석을 먼저 완료해 주세요.", 409)
    if session.get("imported_unverified"):
        raise CounselingError("original_required", "가져온 자료는 원본 학생부를 다시 확인하고 분석한 뒤 전략을 생성해 주세요.", 409)


def taxonomy_items(taxonomy, key):
    value = taxonomy.get(key, {})
    return value if isinstance(value, dict) else {item: item for item in value}


def target_request(session, target_id, taxonomy, catalogue):
    targets = (session.get("profile") or {}).get("admission_targets", [])
    target = next((row for row in targets if row.get("id") == target_id), None)
    if target is None:
        raise CounselingError("target_required", "희망 대학·학과를 추가한 뒤 전략을 생성해 주세요.", 409)
    university = None
    universities = catalogue.get("universities", [])
    if isinstance(universities, dict):
        universities = [{"id": key, **row} for key, row in universities.items()]
    for row in universities:
        aliases = [row.get("id", ""), row.get("name", ""), *row.get("aliases", [])]
        if norm(target.get("university", "")) in {norm(alias) for alias in aliases if alias}:
            university = row
            break
    if university is None:
        raise CounselingError("university_not_reviewed", "공개 자료가 연결된 대학을 선택해 주세요. 입력한 대학 이름을 외부 AI에 그대로 보내지는 않습니다.", 409)
    department = None
    for code, row in taxonomy_items(taxonomy, "departments").items():
        if isinstance(row, str):
            row = {"label": row, "field": "undecided"}
        aliases = [code, row.get("label", ""), *row.get("aliases", [])]
        if norm(target.get("major", "")) in {norm(alias) for alias in aliases if alias}:
            department = {"id": code, **row}
            break
    if department is None:
        raise CounselingError("department_not_reviewed", "희망 학과에 공개 학과 분류를 연결해 주세요. 학과 입력 아래의 지원 학과 목록에서 선택할 수 있습니다.", 409)
    year = target.get("admission_year")
    if year is not None and (type(year) is not int or not 1990 <= year <= 2100):
        raise CounselingError("invalid_admission_year", "대입 학년도를 확인해 주세요.")
    return {"university_id": university["id"], "department_id": department["id"],
            "field": department.get("field", "undecided"), "admission_year": year}, target


def feature_rows(session, taxonomy):
    allowed = taxonomy_items(taxonomy, "competencies")
    result, evidence = {"strengths": [], "needs": []}, {}
    analysis = session.get("analysis") or {}
    for source, output, prefix in (("strengths", "strengths", "strength"), ("improvements", "needs", "need")):
        for item in analysis.get(source, []):
            prose = str(item.get("text", ""))
            for code, pattern in PATTERNS.items():
                if code not in allowed or not re.search(pattern, prose):
                    continue
                if code not in result[output]:
                    result[output].append(code)
                ref = f"{prefix}:{code}"
                label = allowed[code] if isinstance(allowed[code], str) else allowed[code].get("label", code)
                entry = evidence.setdefault(ref, {"label": label, "details": []})
                if prose and prose not in entry["details"]:
                    entry["details"].append(prose)
    # Optional opinions supplement preparation needs, never rewrite them as observed strengths.
    optional = " ".join(str(session.get(key, "")) for key in ("teacher_opinion", "student_question"))
    consultation = session.get("consultation") or {}
    optional += " " + " ".join(str(consultation.get(key, "")) for key in ("agreed_direction", "adjustments", "summary"))
    profile = session.get("profile") or {}
    optional += " " + str(profile.get("learning_concerns", ""))
    observations = str(profile.get("teacher_observations", ""))
    for code, pattern in PATTERNS.items():
        if code in allowed and re.search(pattern, observations) and not re.search(r"보완|어려|미흡|부족|확인 필요", observations):
            if code not in result["strengths"]:
                result["strengths"].append(code)
            evidence.setdefault(f"strength:{code}", {"label": allowed[code] if isinstance(allowed[code], str) else allowed[code].get("label", code),
                                                    "details": ["교사가 선택 입력한 관찰 내용을 함께 참고했습니다. 학생부 기록에서 확인한 근거와 구분합니다."]})
    for code, pattern in PATTERNS.items():
        if code in allowed and re.search(pattern, optional) and re.search(r"보완|어려|필요|연습|준비|개선", optional):
            if code not in result["needs"]:
                result["needs"].append(code)
            evidence.setdefault(f"need:{code}", {"label": allowed[code] if isinstance(allowed[code], str) else allowed[code].get("label", code),
                                                       "details": ["선택 입력의 준비·보완 의견을 함께 참고했습니다. 학생부에서 확인된 어려움과 구분하여 해석합니다."]})
    return result, evidence


def school_connections(case, session, field):
    """School-specific names and conditions stay local, alongside original provenance."""
    data = load_json("school-context.json")
    student = case.get("student", {})
    profile = session.get("profile") or {}
    selected = profile.get("selected_subjects", [])
    words = FIELD_WORDS.get(field, [])
    candidates = []
    for task in data.get("assessments", []):
        subject = task.get("subject", "")
        if task.get("school_stage") != student.get("school_stage"):
            continue
        haystack = " ".join([subject, task.get("title", ""), *task.get("learning_topics", [])])
        relevant = [word for word in words if word in haystack]
        enrolled = subject in selected
        if not relevant and not enrolled:
            continue
        score = len(relevant) + 4 * enrolled + 2 * (task.get("grade") == student.get("grade"))
        candidates.append((score, task))
    candidates.sort(key=lambda row: (-row[0], row[1].get("id", "")))
    result = []
    for _, task in candidates[:5]:
        result.append({"subject": task.get("subject", ""), "task": task.get("title", ""),
                       "reason": "관련 교과 개념과 수행 방법을 준비할 때 참고할 학교 평가계획입니다. 현재 이수·과제 공지와 대조한 뒤 적용합니다.",
                       "conditions": list(task.get("conditions", [])), "steps": list(task.get("steps", [])),
                       "learning_topics": list(task.get("learning_topics", [])), "source": task.get("source_label", ""),
                       "academic_year": task.get("academic_year"), "grade": task.get("grade"), "semester": task.get("semester"),
                       "status": "원문 계획 · 실제 운영과 현재 적용 확인 필요"})
    for club in data.get("clubs", []):
        haystack = str(club.get("description", ""))
        if words and any(word in haystack for word in words):
            result.append({"subject": "동아리", "task": club.get("name", ""), "reason": haystack,
                           "conditions": [club.get("summary_note", "현재 개설·참여 조건 확인 필요")],
                           "source": club.get("source_label", ""), "academic_year": club.get("school_year"),
                           "semester": club.get("semester"), "status": "활동 성격 참고 · 해당 연도 참여 확인 필요"})
            break
    return result


def build_request(case, session, target_id, stage):
    if stage not in KINDS:
        raise CounselingError("invalid_strategy_stage", "학종 준비 또는 질문 중심 학습 단계를 선택해 주세요.")
    require_analysis(session)
    taxonomy = load_json("private-strategy-taxonomy.json")
    catalogue = load_json("private-strategy-data.json")
    target, original_target = target_request(session, target_id, taxonomy, catalogue)
    features, evidence = feature_rows(session, taxonomy)
    profile = session.get("profile") or {}
    student = case.get("student", {})
    subject_text = " ".join(profile.get("selected_subjects", [])) + " " + " ".join(str(s.get("label", "")) for s in (session.get("record") or {}).get("sections", []))
    subjects = [subject for subject in taxonomy_items(taxonomy, "subjects") if subject in subject_text]
    connections = school_connections(case, session, target["field"])
    methods = set()
    constraints = set()
    for connection in connections:
        local_text = json.dumps(connection, ensure_ascii=False)
        for code, pattern in OPPORTUNITIES.items():
            if code in taxonomy_items(taxonomy, "school_opportunities") and re.search(pattern, local_text):
                methods.add(code)
        conditions = " ".join(connection.get("conditions", []))
        if re.search(r"AI.{0,12}(금지|불가)|인공지능.{0,12}(금지|불가)", conditions, re.I):
            constraints.add("ai_prohibited")
        if re.search(r"수업.{0,8}(중|내)|평가 시간.{0,8}(내|중)", conditions):
            constraints.add("in_class_only")
        if re.search(r"자료.{0,12}(제한|반입|금지)|교과서만", conditions):
            constraints.add("source_limited")
    learner = {"grade": student.get("grade", 1), "school_stage": student.get("school_stage", "high"),
               "strengths": features["strengths"][:12], "needs": features["needs"][:12],
               "interests": [target["field"]], "subjects": subjects[:12], "school_opportunities": sorted(methods),
               "school_constraints": sorted(constraints) or ["unknown"]}
    request = {"version": 1, "stage": stage, "target": target, "learner": learner}
    # This object has no slots for text from a record, profile, opinion or source path.
    return request, {"source_hash": preparation_source_hash(case, session), "target_id": target_id,
                     "target_label": f"{original_target.get('university', '')} · {original_target.get('major', '')}",
                     "evidence_map": evidence, "school_connections": connections}


def validate_report(value, *, complete=True):
    if not isinstance(value, dict):
        raise CounselingError("strategy_response", "전략 응답 형식이 올바르지 않습니다.", 502)
    sections = value.get("sections")
    if not isinstance(sections, list) or len(sections) != (5 if complete else 1):
        raise CounselingError("strategy_incomplete", "상세 전략의 필수 장이 누락되어 저장하지 않았습니다.", 502)
    seen = set()
    for section in sections:
        if not isinstance(section, dict) or not isinstance(section.get("items"), list) or len(section["items"]) < 3:
            raise CounselingError("strategy_incomplete", "각 장의 구체적인 준비 내용이 충분하지 않습니다.", 502)
        for item in section["items"]:
            if not isinstance(item, dict):
                raise CounselingError("strategy_response", "상세 항목 형식을 확인할 수 없습니다.", 502)
            detail, reason = item.get("detail", ""), item.get("reason", "")
            if not isinstance(detail, str) or not isinstance(reason, str) or len(detail.strip()) < 120 or len(reason.strip()) < 40:
                raise CounselingError("strategy_incomplete", "설명과 선택 이유가 짧아 상세 보고서로 저장하지 않았습니다.", 502)
            steps = item.get("steps", [])
            if not isinstance(steps, list) or len(steps) < 2 or any(not isinstance(step, str) or not step.strip() for step in steps):
                raise CounselingError("strategy_incomplete", "구체적인 학습 방법이 누락되어 저장하지 않았습니다.", 502)
            normalized = re.sub(r"\s+", "", detail)
            if normalized in seen:
                raise CounselingError("strategy_repetition", "반복된 설명이 있어 전략을 저장하지 않았습니다.", 502)
            seen.add(normalized)
        visible = [section.get("overview", "")]
        for item in section["items"]:
            visible.extend([item.get("title", ""), item["detail"], item["reason"], *item["steps"]])
        if sum(len(re.sub(r"\s+", "", str(part))) for part in visible) < 650:
            raise CounselingError("strategy_incomplete", "상세 보고서 분량이 충분하지 않습니다.", 502)
    return value


def run_private_strategy(case, session, target_id, stage, token, stop, progress, on_transport, *, client_factory=httpx.Client):
    request, local = build_request(case, session, target_id, stage)
    if not token:
        raise CounselingError("external_auth_required", "학교 계정을 다시 연결하면 비식별 외부 AI 전략을 사용할 수 있습니다. 시연 모드에서는 외부로 전송하지 않습니다.", 401)
    if stage == "inquiry":
        previous = (session.get("preparation_reports") or {}).get("reports", [])
        admission_report = next((row for row in previous if row.get("kind") == "admissions" and row.get("target_id") == target_id and row.get("source_hash") == local["source_hash"]), None)
        if not admission_report or not admission_report.get("external_context_token"):
            raise CounselingError("admissions_strategy_required", "현재 자료에 맞는 대학·학과별 학종 준비 전략을 먼저 생성해 주세요.", 409)
        request["context_token"] = admission_report["external_context_token"]
        local["admissions_report_id"] = admission_report["id"]
    result = {"version": 1, "kind": stage, "stage": stage, "title": "", "summary": "", "sections": [], "sources": []}
    with client_factory(verify=ssl.create_default_context(), trust_env=False, follow_redirects=False, timeout=170) as client:
        on_transport(client.close)
        try:
            for index, section_id in enumerate(KINDS[stage]):
                check_cancel(stop)
                progress("external_strategy", f"비식별 학습 정보로 상세 전략 {index + 1}/5장을 작성하고 있습니다.")
                response = client.post(ENDPOINT, headers={"Authorization": "Bearer " + token}, json={**request, "section_id": section_id})
                check_cancel(stop)
                if response.status_code in (401, 403):
                    raise CounselingError("external_auth_required", "학교 로그인 연결이 만료되었습니다. 계정을 다시 연결해 주세요.", 401)
                if response.status_code != 200:
                    raise CounselingError("external_strategy_unavailable", "외부 AI가 상세 전략을 완료하지 못했습니다. 이전 결과는 보존했습니다. 연결 상태를 확인한 뒤 다시 실행해 주세요.", 503)
                try:
                    part = response.json()
                    if isinstance(part, dict) and isinstance(part.get("report"), dict):
                        part = part["report"]
                    validate_report(part, complete=False)
                except ValueError as exc:
                    raise CounselingError("strategy_response", "전략 응답을 읽을 수 없어 저장하지 않았습니다.", 502) from exc
                if part["sections"][0].get("id") != section_id:
                    raise CounselingError("strategy_response", "전략 장의 순서가 올바르지 않아 저장하지 않았습니다.", 502)
                result["sections"].extend(part["sections"])
                if not result["title"]:
                    result["title"] = str(part.get("title", ""))
                    result["summary"] = str(part.get("summary", ""))
                result["model"] = str(part.get("model", ""))
                if stage == "admissions" and section_id == "academic_preparation" and part.get("context_token"):
                    result["external_context_token"] = part["context_token"]
                for source in part.get("sources", []):
                    if source not in result["sources"]:
                        result["sources"].append(source)
        except httpx.HTTPError as exc:
            check_cancel(stop)
            raise CounselingError("external_strategy_unavailable", "외부 AI 연결이 중단되었습니다. 이전 결과는 보존했습니다.", 503) from exc
        finally:
            on_transport(None)
    validate_report(result)
    check_cancel(stop)
    # Responses are never allowed to reintroduce the user's known identifiers.
    returned = json.dumps(result, ensure_ascii=False)
    identifiers = [case.get("student", {}).get("name", ""), case.get("student", {}).get("student_number", ""), case.get("teacher", {}).get("display_name", "")]
    for identifier in identifiers:
        if len(identifier) >= 2 and re.search(r"(?<!\w)" + re.escape(identifier) + r"(?!\w)", returned):
            raise CounselingError("strategy_identity_detected", "응답에 개인 식별정보 후보가 있어 저장하지 않았습니다.", 502)
    result.update(id=new_id(), created_at=now(), **local)
    reports = copy.deepcopy(session.get("preparation_reports") or {"version": 1, "reports": []})
    # A regenerated admissions strategy invalidates its dependent inquiry report.
    # The previous version remains available in the store's immutable history.
    reports["reports"] = [row for row in reports["reports"] if not (row.get("target_id") == target_id and (row.get("kind") == stage or stage == "admissions" and row.get("kind") == "inquiry"))] + [result]
    session["preparation_reports"] = reports
    session["review"] = None
    return result
