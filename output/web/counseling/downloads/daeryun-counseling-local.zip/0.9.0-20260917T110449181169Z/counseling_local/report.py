"""Offline PDF rendering. No HTML renderer, external font, or network dependency."""
from __future__ import annotations

import fitz
import math
import re
from html import unescape
from html.parser import HTMLParser

from .domain import (CounselingError, content_hash,
                     has_admission_target, has_profile, profile_value, require_consultation_complete, strategy_value)


class _ReadableHTML(HTMLParser):
    """Extract display text; never interpret HTML or fetch linked resources."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.hidden = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.hidden += 1
        if self.hidden:
            return
        if tag in ("p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr"):
            self.parts.append("\n")
        if tag == "li":
            self.parts.append("• ")
        if tag in ("td", "th"):
            self.parts.append(" | ")
        if tag == "img":
            self.parts.append(dict(attrs).get("alt", ""))

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.hidden = max(0, self.hidden - 1)
        elif not self.hidden and tag in ("p", "div", "li", "h1", "h2", "h3", "h4", "tr"):
            self.parts.append("\n")

    def handle_data(self, value):
        if not self.hidden:
            self.parts.append(value)


def readable_text(value, *, keep_blocks=False):
    """Normalize presentation only; saved plans, original quotes and hashes stay intact."""
    value = str(value or "")
    # These exact remnants can result from JSON interpreting \r / \t inside
    # an improperly escaped LaTeX command. Do not rewrite ordinary line breaks.
    value = re.sub(r"\$\s*(?:\\+text|" + "\t" + r"ext)\{([^{}]*)\}\s*\$", r"\1", value)
    value = value.replace("\r" + "ightarrow", "→")
    value = re.sub("\t" + r"ext\{([^{}]*)\}", r"\1", value)
    arrows = {"rightarrow": "→", "longrightarrow": "→", "Rightarrow": "⇒", "Longrightarrow": "⇒",
              "leftarrow": "←", "longleftarrow": "←", "Leftarrow": "⇐", "leftrightarrow": "↔",
              "Leftrightarrow": "⇔", "to": "→"}
    value = re.sub(r"\\+(" + "|".join(arrows) + r")\b", lambda match: arrows[match.group(1)], value)
    value = re.sub(r"\\\((.*?)\\\)|\\\[(.*?)\\\]", lambda match: match.group(1) or match.group(2) or "", value, flags=re.S)
    parts, cursor = [], 0
    # Inspect overlapping dollar pairs: currency before a formula must not
    # consume the formula's opening delimiter (for example "$20 ... $A → B$").
    for match in re.finditer(r"(?<!\\)(?=\$([^$\n]+)\$)", value):
        body = match.group(1)
        if match.start() < cursor:
            continue
        if (re.search(r"[→←↔⇒⇐⇔]|\\[A-Za-z]+", body) or
                re.fullmatch(r"[A-Za-z]", body.strip()) or
                re.fullmatch(r"[A-Za-z][A-Za-z0-9_(){}+*/=^ .-]*[(){}+*/=^][A-Za-z0-9_(){}+*/=^ .-]*", body.strip())):
            parts.extend((value[cursor:match.start()], body))
            cursor = match.start() + len(body) + 2
    value = "".join(parts) + value[cursor:]
    value = re.sub(r"\\+(?:text|mathrm|mathbf|operatorname)\{([^{}]*)\}", r"\1", value)
    value = value.replace(r"\$", "$")
    value = unescape(value)
    if re.search(r"</?[A-Za-z][^>]*>", value):
        parser = _ReadableHTML()
        parser.feed(value)
        parser.close()
        value = "".join(parser.parts)
    value = re.sub(r"!?\[([^\]\n]+)\]\(([^)\n]+)\)", lambda match: match.group(1) + " (" + match.group(2) + ")", value)
    value = re.sub(r"(?m)^\s*```[^\n]*$", "", value)
    for pattern in (r"\*\*(.+?)\*\*", r"__(.+?)__", r"~~(.+?)~~", r"`([^`]+)`"):
        value = re.sub(pattern, r"\1", value)
    value = re.sub(r"(?<![\w*])\*([^*\n]+)\*(?!\w)", r"\1", value)
    if not keep_blocks:
        value = re.sub(r"(?m)^\s*#{1,6}\s+", "", value)
    return re.sub(r"\n{3,}", "\n\n", value).replace("\x00", "")


def consumer_plan_lines(value):
    """Omit explicit source-audit rows while keeping educational prose intact."""
    lines = readable_text(value, keep_blocks=True).splitlines()
    result = []
    for line in lines:
        if re.match(r"^\s*(?:[-*•]\s*|#{1,6}\s*)?(?:원문\s*근거|확인\s*위치|원문\s*위치|자료\s*ID)\s*[:：]", line):
            continue
        source = re.match(r"^(\s*(?:[-*•]\s*|#{1,6}\s*)?출처\s*[:：]\s*)(.*)$", line)
        if source:
            parts = []
            school_link = bool(re.search(r"(?:^|·)\s*(?:/[A-Za-z_][A-Za-z0-9_/-]*/|개정\s*(?:\d+|확인\s*필요))", source.group(2)))
            for index, part in enumerate(source.group(2).split("·")):
                part = part.strip()
                # These fragments are appended by the school-data link UI.
                # Keep names, authors, years and conditions in the readable label.
                if (re.fullmatch(r"개정\s*(?:\d+|확인\s*필요)", part) or
                        school_link and index > 0 and re.fullmatch(r"자료\s+(?:ID\s*[:：]?\s*)?[A-Za-z0-9][A-Za-z0-9_.:-]*", part)):
                    continue
                part = re.sub(r"(?<![:/\w])/(?:[A-Za-z_][A-Za-z0-9_.~-]*/)+[A-Za-z0-9_.~-]+", "", part)
                part = re.sub(r"(?:자료\s+(?:ID\s*[:：]?\s*)?)?\b(?:source|section|src)[-_][A-Za-z0-9_-]+\b", "", part, flags=re.I)
                part = re.sub(r"(?:자료\s+(?:ID\s*[:：]?\s*)?)?\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b", "", part, flags=re.I)
                part = part.strip(" \t·,;")
                if part:
                    parts.append(part)
            if not parts:
                continue
            line = source.group(1) + " · ".join(parts)
        result.append(line)
    return result


def write_admission_targets(report, session):
    """Only user-entered admission targets are public; private profile notes stay out."""
    targets = profile_value(session.get("profile", {})).get("admission_targets") or []
    rows = []
    for item in targets:
        if not has_admission_target(item):
            continue
        route = " · ".join(value for value in (item.get("admission_type"), item.get("admission_name")) if value)
        year = item.get("admission_year")
        rows.append([item.get("university", ""), item.get("major", ""), route, f"{year}학년도" if year else ""])
    if rows:
        report.heading("검토할 희망 대학·전공")
        report.table(["대학", "전공", "전형", "대입학년도"], rows, [110, 140, 165, 88], 9)


def write_profile(report, session):
    profile = profile_value(session.get("profile", {}))
    if not has_profile(profile):
        return
    report.heading("학생 기본자료 · 교사 검토용")
    report.paragraph("교사가 입력한 자료를 정리했습니다. 학생부 원문이나 검증된 평가 결과와 구분하며, 미입력 항목은 약점을 뜻하지 않습니다.", 9)
    fields = (("희망 전공", "target_major"), ("관심 분야", "interests"), ("학습 고민", "learning_concerns"),
              ("학습 습관", "study_habits"), ("참여 활동", "activities"), ("읽기·독서", "reading"),
              ("출결 관련 확인", "attendance_notes"), ("교사의 관찰", "teacher_observations"))
    for label, key in fields:
        if profile[key]:
            report.heading(label)
            report.paragraph(profile[key])
    if profile["selected_subjects"]:
        report.paragraph("실제 이수 과목: " + ", ".join(profile["selected_subjects"]))
    if profile["grades"]:
        report.heading("입력한 교과 성적")
        for grade in sorted(profile["grades"], key=lambda g: (g["academic_year"], g["semester"], g["subject"])):
            scale = grade["grade_scale"]
            parts = [f"{grade['academic_year']}학년도 {grade['semester']}학기", grade["subject"] or "과목 미입력",
                     f"{scale}등급 체계" if scale in ("5", "9") else "성취도 체계" if scale == "achievement" else "등급 체계 미확인"]
            if grade["rank_grade"] is not None:
                parts.append(f"석차등급 {grade['rank_grade']}")
            if grade["score"] is not None:
                parts.append(f"원점수 {grade['score']}")
            if grade["achievement"]:
                parts.append("성취도 " + grade["achievement"])
            report.paragraph(" · ".join(parts), 9)
        report.paragraph("5등급과 9등급을 변환·합산하지 않습니다. 원점수의 변화는 평가 조건을 확인한 뒤 해석합니다.", 9)


STRATEGY_LABELS = (("목표 전공·관심 분야", "target_major"), ("희망 진로·진학 방향", "target_path"),
                   ("근거에서 확인한 강점", "strengths"), ("보완할 점과 필요한 도움", "gaps"),
                   ("교과별 학습 전략", "subject_plan"), ("탐구 주제와 발전 방법", "inquiry_plan"),
                   ("창체·봉사·독서·행동특성 전략", "activity_plan"), ("1~3년 학습·탐구 로드맵", "semester_plan"),
                   ("전략의 핵심과 먼저 준비할 사항", "student_message"))


def analysis_document_title(case, session):
    student = session.get("student_snapshot") or case["student"]
    name = student.get("name") or student.get("student_number") or "학생"
    return str(name).strip() + " 학생부 분석 자료"


def write_strategy(report, session, heading="학생 성장·학습·진학 전략", student=False):
    strategy = strategy_value(session.get("strategy", {}))
    if any(strategy.values()):
        report.heading(heading)
        fields = sorted(STRATEGY_LABELS, key=lambda item: item[1] != "student_message") if student else STRATEGY_LABELS
        for label, key in fields:
            if strategy[key]:
                report.heading(label)
                (report.roadmap_text if key == "semester_plan" else report.plan_text)(strategy[key])


def write_actions(report, session, heading="학생이 준비할 사항"):
    """Keep useful legacy recommendations without turning them into a task tracker."""
    actions = [action for action in session.get("actions", []) if action.get("text", "").strip()]
    if actions:
        report.heading(heading)
        report.table(["순서", "준비할 내용"],
                     [[str(index), action["text"]] for index, action in enumerate(actions, 1)], [45, 458])


def write_student_strategy(report, session):
    """Present the agreed direction, its reasoning, and the student's preparation."""
    strategy = strategy_value(session.get("strategy", {}))
    if strategy["student_message"]:
        report.heading("전략의 핵심과 먼저 준비할 사항")
        report.plan_text(strategy["student_message"])
    for heading, fields in (("선택한 방향과 근거", STRATEGY_LABELS[:4]),
                            ("교과·탐구·진로의 중장기 전략", STRATEGY_LABELS[4:8])):
        present = [(label, key, strategy[key]) for label, key in fields if strategy[key]]
        if present:
            report.heading(heading)
            for label, key, value in present:
                report.heading(label)
                (report.roadmap_text if key == "semester_plan" else report.plan_text)(value)


def student_report_pdf(case, session):
    """Render only the teacher-confirmed student-facing projection."""
    student = session.get("student_snapshot") or case["student"]
    title = (student.get("name") or student.get("student_number") or "학생") + " 학습·진로 전략 보고서"
    report = Report(title)
    report.paragraph(title, 19)
    synthetic = case.get("origin") == "synthetic"
    if synthetic:
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이 아니며 실제 교사의 검토나 학생 전달을 뜻하지 않습니다.")
    student = session.get("student_snapshot") or case["student"]
    teacher = session.get("teacher_snapshot") or case["teacher"]
    metadata = [f"{student['academic_year']}학년도"]
    if student.get("student_number"):
        metadata.append("학번 " + student["student_number"])
    if student.get("name"):
        metadata.append(student["name"])
    report.paragraph(" · ".join(metadata), 9)
    details = ["시연 확정본" if synthetic else "교사 확인본", "작성일 " + session["date"]]
    if teacher.get("display_name"):
        details.append("담당 교사 " + teacher["display_name"])
    report.paragraph(" · ".join(details), 9)
    write_admission_targets(report, session)
    if session.get("topic"):
        report.paragraph(session["topic"], 14)
    write_student_strategy(report, session)
    return report.finish()


class Report:
    def __init__(self, title):
        self.doc = fitz.open()
        self.font = fitz.Font("korea")
        self.title = title
        self.page = None
        self.y = 0
        self.pending_headings = []
        self.new_page()

    def new_page(self):
        self.page = self.doc.new_page(width=595, height=842)
        self.page.insert_font(fontname="CounselingFont", fontbuffer=self.font.buffer)
        self.page.insert_text((46, 34), "대륜고 학생부 분석·학습·진로 전략", fontname="CounselingFont", fontsize=9, color=(0.25, 0.3, 0.4))
        self.page.draw_line((46, 43), (549, 43), color=(0.8, 0.83, 0.87), width=0.5)
        self.y = 68

    def line(self, value, size=10.5, color=(0.13, 0.17, 0.22)):
        if self.y + size * 1.65 > 785:
            self.new_page()
        self.page.insert_text((46, self.y), value, fontname="CounselingFont", fontsize=size, color=color)
        self.y += size * 1.65

    def wrapped_lines(self, value, size, width=500):
        value = readable_text(value)
        lines = []
        for paragraph in value.splitlines() or [""]:
            buffer = ""
            for char in paragraph:
                if char == "\x00":
                    continue
                if buffer and self.font.text_length(buffer + char, fontsize=size) > width:
                    boundary = buffer.rfind(" ")
                    if boundary > len(buffer) // 2:
                        lines.append(buffer[:boundary])
                        buffer = buffer[boundary + 1:]
                    else:
                        lines.append(buffer)
                        buffer = ""
                buffer += char
            lines.append(buffer)
        return lines

    def table(self, headers, rows, widths, size=9.5):
        """Render complete cells, repeating headers when a table crosses pages."""
        if not rows:
            return
        leading = size * 1.6
        padding = 9
        header_lines = [self.wrapped_lines(value, size, width - padding * 2)
                        for value, width in zip(headers, widths)]
        header_height = max(map(len, header_lines)) * leading + padding * 2

        def draw(cells, height, header=False, shaded=False):
            left, top = 46, self.y
            for lines, width in zip(cells, widths):
                self.page.draw_rect((left, top, left + width, top + height),
                                    color=(0.80, 0.85, 0.89), width=0.5,
                                    fill=(0.90, 0.94, 0.96) if header else
                                         (0.97, 0.98, 0.99) if shaded else (1, 1, 1))
                for index, line in enumerate(lines):
                    self.page.insert_text((left + padding, top + padding + size + index * leading),
                                          line, fontname="CounselingFont", fontsize=size,
                                          color=(0.13, 0.25, 0.37) if header else (0.13, 0.17, 0.22))
                left += width
            self.y += height

        first_lines = max(len(self.wrapped_lines(value, size, width - padding * 2))
                          for value, width in zip(rows[0], widths))
        heading_height = sum(14 + len(self.wrapped_lines(heading, 12.5)) * 12.5 * 1.65
                             for heading in self.pending_headings)
        first_height = min(first_lines * leading + padding * 2,
                           max(leading + padding * 2, 717 - header_height - heading_height))
        if self.y > 68 and self.y + heading_height + header_height + first_height > 785:
            self.new_page()
        self.flush_headings(3, size)
        draw(header_lines, header_height, header=True)
        for row_index, row in enumerate(rows):
            remaining = [self.wrapped_lines(value, size, width - padding * 2)
                         for value, width in zip(row, widths)]
            full_height = max(map(len, remaining)) * leading + padding * 2
            if row_index > 0 and full_height <= 717 - header_height and self.y + full_height > 785:
                self.new_page()
                draw(header_lines, header_height, header=True)
            while any(remaining):
                capacity = max(0, math.floor((785 - self.y - padding * 2) / leading))
                if capacity < 1:
                    self.new_page()
                    draw(header_lines, header_height, header=True)
                    continue
                count = min(capacity, max(map(len, remaining)))
                draw([lines[:count] for lines in remaining], count * leading + padding * 2,
                     shaded=row_index % 2 == 1)
                remaining = [lines[count:] for lines in remaining]
                if any(remaining):
                    self.new_page()
                    draw(header_lines, header_height, header=True)
        self.y += 12

    def write_lines(self, lines, size):
        """Keep at least two lines together at a page boundary when possible."""
        remaining = list(lines)
        while remaining:
            capacity = max(0, math.floor((785 - self.y) / (size * 1.65)))
            if capacity < min(2, len(remaining)):
                self.new_page()
                continue
            count = min(capacity, len(remaining))
            if len(remaining) - count == 1 and count > 1:
                count -= 1
            if count == 1 and len(remaining) > 1:
                # Three lines cannot split into two non-orphan fragments.
                self.new_page()
                continue
            for line in remaining[:count]:
                self.line(line, size)
            remaining = remaining[count:]
            if remaining:
                self.new_page()

    def flush_headings(self, body_lines=0, body_size=10.5):
        if not self.pending_headings:
            return
        headings = [(value, self.wrapped_lines(value, 12.5)) for value in self.pending_headings]
        first_fragment = min(3 if body_lines == 3 else 2, body_lines)
        needed = sum(14 + len(lines) * 12.5 * 1.65 for _, lines in headings) + first_fragment * body_size * 1.65
        if self.y > 68 and self.y + needed > 785:
            self.new_page()
        self.pending_headings = []
        for _, lines in headings:
            self.y += 9
            self.write_lines(lines, 12.5)
            self.y += 5

    def paragraph(self, value, size=10.5):
        lines = self.wrapped_lines(value, size)
        self.flush_headings(len(lines), size)
        self.write_lines(lines, size)
        self.y += 5

    def heading(self, value):
        self.pending_headings.append(value)

    def task(self, value, metadata):
        body = self.wrapped_lines(value, 10.5)
        details = self.wrapped_lines(metadata, 9)
        required = len(body) * 10.5 * 1.65 + len(details) * 9 * 1.65 + 10
        required += sum(14 + len(self.wrapped_lines(heading, 12.5)) * 12.5 * 1.65
                        for heading in self.pending_headings)
        # Long free-text tasks may span pages; ordinary tasks keep their deadline.
        if required <= 717 and self.y > 68 and self.y + required > 785:
            self.new_page()
        self.paragraph(value)
        self.paragraph(metadata, 9)

    def plan_text(self, value):
        """Render headings, lists and Markdown tables without shortening saved prose."""
        def display(value):
            # Remove paired emphasis markers, retaining mathematical stars and underscores.
            return re.sub(r"\*\*(.+?)\*\*", r"\1", value)

        def cells(line):
            return [display(part.strip()).replace(r"\|", "|")
                    for part in re.split(r"(?<!\\)\|", line.strip().strip("|"))]

        normal = []
        lines = consumer_plan_lines(value)
        index = 0

        def flush():
            if normal:
                self.paragraph("\n".join(normal))
                normal.clear()

        while index < len(lines):
            line = display(lines[index])
            prefix = line.lstrip()
            if index + 1 < len(lines) and "|" in line:
                headers = cells(line)
                separator = cells(lines[index + 1])
                if len(headers) >= 2 and len(separator) == len(headers) and all(
                        re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in separator):
                    rows = []
                    end = index + 2
                    while end < len(lines) and "|" in lines[end] and len(cells(lines[end])) == len(headers):
                        rows.append(cells(lines[end]))
                        end += 1
                    if rows:
                        flush()
                        # Wide tables read better as complete labelled records on A4.
                        if len(headers) > 4:
                            for row in rows:
                                self.heading(headers[0] + ": " + row[0])
                                for label, content in zip(headers[1:], row[1:]):
                                    self.paragraph(label + ": " + content)
                        else:
                            widths = [503 / len(headers)] * len(headers)
                            self.table(headers, rows, widths)
                        index = end
                        continue
            reference = prefix.startswith(("학교 계획 참고:", "학교 활동 참고:"))
            source = prefix.startswith(("출처:", "자료 ID:", "원문 위치:"))
            condition = prefix.startswith(("조건:", "AI 관련 원문:", "원문 대상:", "원문 시기:", "적용 상태:"))
            markdown_heading = re.match(r"^#{1,6}\s+(.+)$", prefix)
            labelled_heading = re.fullmatch(r"\[([^\[\]]+)\]", prefix)
            preparation_heading = re.fullmatch(r"(?:먼저 준비할 것|주제를 선택할 때|교사에게 요청할 도움)\s*[:：]?", prefix)
            topic_heading = re.match(r"^(?:주제|탐구 주제|과목|교과|영역|단계|후보\s*\d+)\s*[:：]", prefix)
            detail = prefix.startswith(("핵심 질문:", "기록 연결:", "현재 근거:", "선수 개념:",
                                        "핵심 개념:", "학습 방법:", "탐구 방법:", "준비 자료:",
                                        "준비할 내용:", "예상 산출물:", "확장 방향:", "순서의 이유:",
                                        "준비 방향:", "준비할 자료·결과물:", "필요한 도움:", "연결할 교과·탐구:",
                                        "과거 관찰:", "관찰 요약:", "현재 의미:", "앞으로의 방향:",
                                        "학습 기반:", "탐구 발전:", "준비할 자료:", "다음 단계로 이어지는 이유:", "방향을 바꿀 때:",
                                        "과목과 선택 조건:", "학습 개념·방법:", "탐구 질문:", "자료 선정·확보 대안:", "준비 결과:"))
            if not prefix:
                flush()
            elif reference or source or condition or markdown_heading or labelled_heading or topic_heading or preparation_heading or detail:
                flush()
                if markdown_heading or labelled_heading:
                    self.heading((markdown_heading or labelled_heading).group(1))
                elif reference or topic_heading or preparation_heading or (detail and prefix.endswith((":", "："))):
                    self.heading(prefix)
                else:
                    self.paragraph(line, 9 if source else 10.5)
            elif re.match(r"^(?:[-*•]\s+|\d+[.)]\s+)", prefix):
                flush()
                self.paragraph(re.sub(r"^[-*]\s+", "• ", prefix))
            else:
                normal.append(line)
            index += 1
        flush()

    def roadmap_text(self, value):
        """Group authored year stages into labelled rows without inventing steps."""
        lines = consumer_plan_lines(value)
        stages, opening = [], []
        for line in lines:
            plain = re.sub(r"^\s*#{1,6}\s+", "", line).strip()
            if re.match(r"^(?:단계\s*[:：]\s*|(?:고등학교\s*|중학교\s*)?[1-3]\s*학년(?:\s|[:：]|$))", plain):
                stages.append((plain, []))
            elif stages:
                stages[-1][1].append(line)
            else:
                opening.append(line)
        if not stages:
            self.plan_text(value)
            return
        if any(line.strip() for line in opening):
            self.plan_text("\n".join(opening))
        labels = ("학습 기반", "탐구 발전", "준비할 자료", "과목과 선택 조건", "학습 개념·방법", "탐구 질문",
                  "자료 선정·확보 대안", "준비 결과", "필요한 도움", "다음 단계로 이어지는 이유", "방향을 바꿀 때")
        for title, body in stages:
            self.heading(title)
            rows, preface = [], []
            for line in body:
                match = re.match(r"^\s*(" + "|".join(labels) + r")\s*[:：]\s*(.*)$", line)
                if match:
                    rows.append([match.group(1), match.group(2)])
                elif rows:
                    rows[-1][1] += "\n" + line
                else:
                    preface.append(line)
            if any(line.strip() for line in preface):
                self.plan_text("\n".join(preface))
            if rows:
                self.table(["발전 단계", "준비 방향과 이유"], rows, [108, 395])

    def source_text(self, value):
        """Style source identifiers without deleting or rewriting any source text."""
        for line in str(value).splitlines():
            self.paragraph(line, 9 if line.lstrip().startswith(("출처:", "자료 ID:", "원문 위치:")) else 10.5)

    def finish(self):
        self.flush_headings()
        count = len(self.doc)
        for index, page in enumerate(self.doc):
            page.insert_text((46, 813), "학생부 분석·학습·진로 전략", fontname="CounselingFont", fontsize=8, color=(0.4, 0.43, 0.48))
            page.insert_text((500, 813), f"{index + 1} / {count}", fontname="CounselingFont", fontsize=8, color=(0.4, 0.43, 0.48))
        self.doc.set_metadata({"title": self.title, "author": "대륜고 학종 전략실", "subject": self.title})
        output = self.doc.tobytes(garbage=4, deflate=True)
        self.doc.close()
        return output


def report_pdf(case, session, audience="teacher"):
    if audience not in ("teacher", "student", "analysis"):
        raise CounselingError("invalid_audience", "학생부 분석 자료, 교사 검토용 또는 학생 안내용을 선택해 주세요.")
    if audience == "analysis":
        from .analysis_report import analysis_report_pdf
        return analysis_report_pdf(case, session)
    synthetic = case.get("origin") == "synthetic"
    confirmed = session.get("confirmed")
    imported = bool(session.get("imported_unverified"))
    unverified_analysis = imported and session.get("analysis") is not None
    unverified_record = imported and session.get("record") is not None
    valid_confirmation = bool(not (unverified_record or unverified_analysis) and confirmed and confirmed.get("content_hash") == content_hash(case, session))
    if audience == "student":
        require_consultation_complete(session)
        if not any(strategy_value(session.get("strategy", {})).values()):
            raise CounselingError("student_guidance_required", "학생 안내 내용이 없습니다. 새 전략 차수에 안내 내용을 작성한 뒤 검토·확정해 주세요.", 409)
        if not valid_confirmation:
            raise CounselingError("student_report_unconfirmed", "학생 안내 PDF는 현재 학습·진로 전략을 교사가 검토하고 확정한 뒤 저장할 수 있습니다.", 409)
        return student_report_pdf(case, session)
    from .teacher_report import teacher_report_pdf
    return teacher_report_pdf(case, session, synthetic=synthetic,
                              valid_confirmation=valid_confirmation, imported=imported,
                              unverified_record=unverified_record,
                              unverified_analysis=unverified_analysis)
