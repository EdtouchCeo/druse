"""A dedicated, cloud-disabled Ollama process; no provider fallback exists here."""
from __future__ import annotations

import json
import os
import re
import ctypes
import shutil
import socket
import subprocess
import threading
import time
from pathlib import Path

import httpx

from .domain import CounselingError

CONTEXT_TOKENS = 32768
TEMPLATE_RESERVE = 4096


def prompt_size(system, prompt, schema=None, images=None):
    # UTF-8 bytes deliberately overestimate the text tokens of supported local
    # models. Reserve room for the model's template and image embeddings too.
    return (len(system.encode("utf-8")) + len(prompt.encode("utf-8"))
            + (len(json.dumps(schema, ensure_ascii=False).encode("utf-8")) if schema else 0)
            + 4096 * len(images or []))


def check_prompt_budget(system, prompt, schema=None, images=None, max_tokens=2600, template=""):
    reserve = max(TEMPLATE_RESERVE, len(template.encode("utf-8")) + 512)
    if prompt_size(system, prompt, schema, images) + reserve + max_tokens > CONTEXT_TOKENS:
        raise CounselingError("input_too_large", "상담 배경이나 질문이 모델의 입력 범위를 넘었습니다. 내용을 나누거나 줄여 주세요. 원문을 임의로 잘라 분석하지 않았습니다.")


class Cancelled(Exception):
    pass


def check_cancel(stop):
    if stop is not None and stop.is_set():
        raise Cancelled()


def generation_error(message, status=500):
    """Classify local transport errors without exposing a prompt or model output."""
    value = str(message).lower()
    if re.search(r"out of memory|not enough.{0,40}memory|requires more.{0,40}memory|cannot allocate|unable to allocate|cuda.{0,40}memory|failed to allocate", value):
        return CounselingError("model_memory", "모델을 실행할 메모리가 부족합니다. 다른 분석을 종료하거나 더 작은 로컬 모델을 선택해 주세요.", 503)
    if status == 404:
        return CounselingError("model_unavailable", "선택한 로컬 모델을 찾을 수 없습니다. 이 PC의 설치 모델 목록을 다시 확인해 주세요.", 503)
    if status == 400 and re.search(r"think|thinking", value):
        return CounselingError("model_thinking_unsupported", "설치 모델이 생각 모드 설정을 지원하지 않습니다. Ollama와 모델 버전을 확인하거나 다른 로컬 모델을 선택해 주세요.", 503)
    if status == 400 and re.search(r"format|schema|json", value):
        return CounselingError("model_format_unsupported", "설치 모델이 분석 응답 형식을 지원하지 않습니다. Ollama와 모델 버전을 확인하거나 다른 로컬 모델을 선택해 주세요.", 503)
    return CounselingError("ollama_generation", "로컬 모델이 응답을 완료하지 못했습니다. Ollama 실행 상태와 사용 가능한 메모리를 확인해 주세요.", 503)


class _WindowsProcessGroup:
    """Own only our serve process and descendants, including after serve exits.

    An unnamed, non-inherited Job Object cannot capture an existing user
    Ollama process. KILL_ON_JOB_CLOSE also covers an unexpected Python exit.
    """
    def __init__(self):
        from ctypes import wintypes
        class BasicLimits(ctypes.Structure):
            _fields_ = [("process_time", ctypes.c_longlong), ("job_time", ctypes.c_longlong),
                        ("flags", wintypes.DWORD), ("min_working_set", ctypes.c_size_t),
                        ("max_working_set", ctypes.c_size_t), ("process_limit", wintypes.DWORD),
                        ("affinity", ctypes.c_size_t), ("priority", wintypes.DWORD), ("scheduling", wintypes.DWORD)]
        class Limits(ctypes.Structure):
            _fields_ = [("basic", BasicLimits), ("io_counters", ctypes.c_ulonglong * 6),
                        ("process_memory", ctypes.c_size_t), ("job_memory", ctypes.c_size_t),
                        ("peak_process_memory", ctypes.c_size_t), ("peak_job_memory", ctypes.c_size_t)]
        self.api = ctypes.WinDLL("kernel32", use_last_error=True)
        self.api.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        self.api.CreateJobObjectW.restype = wintypes.HANDLE
        self.api.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.SetInformationJobObject.restype = wintypes.BOOL
        self.api.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.api.AssignProcessToJobObject.restype = wintypes.BOOL
        self.api.CloseHandle.argtypes = [wintypes.HANDLE]
        self.api.CloseHandle.restype = wintypes.BOOL
        self.handle = self.api.CreateJobObjectW(None, None)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        limits = Limits()
        limits.basic.flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not self.api.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
            error = ctypes.WinError(ctypes.get_last_error())
            self.close()
            raise error

    def assign(self, process):
        # Retained Popen handle identifies this process even if a PID is reused.
        if not self.api.AssignProcessToJobObject(self.handle, int(process._handle)):
            raise ctypes.WinError(ctypes.get_last_error())

    def close(self):
        if self.handle:
            handle, self.handle = self.handle, None
            if not self.api.CloseHandle(handle):
                raise ctypes.WinError(ctypes.get_last_error())


class Ollama:
    def __init__(self, models_dir=None):
        self.process = None
        self._process_group = None
        self.url = None
        self._lock = threading.Lock()
        self._discovery_cache = None
        self._discovery_at = 0
        self.models_dir = models_dir or os.environ.get("OLLAMA_MODELS")
        if not self.models_dir:
            # Both locations are used by the installed desktop apps. Select
            # only an existing Ollama manifest store; never download a model.
            for candidate in (Path.home() / ".ollama/models", Path.home() / ".lmstudio/models"):
                manifests = candidate / "manifests"
                if manifests.is_dir() and any(p.is_file() for p in manifests.rglob("*")):
                    self.models_dir = str(candidate)
                    break

    @staticmethod
    def _request(base, path, body=None, timeout=4):
        if not base.startswith("http://127.0.0.1:") or "/" in base.split(":")[-1] or not base.split(":")[-1].isdigit():
            raise CounselingError("local_only", "이 기능은 교사 PC의 Ollama만 사용할 수 있습니다.")
        with httpx.Client(trust_env=False, follow_redirects=False, timeout=timeout) as client:
            response = client.get(base + path) if body is None else client.post(base + path, json=body)
            if response.status_code != 200:
                raise CounselingError("ollama_response", "Ollama 응답을 확인할 수 없습니다. 실행 상태와 설치 모델을 확인해 주세요.", 503)
            return response.json()

    @staticmethod
    def _local_models(response):
        models = []
        for model in response.get("models", []):
            name = model.get("name", "")
            if not isinstance(name, str) or not name or len(name) > 160:
                continue
            if "cloud" in name.lower() or model.get("remote_host") or model.get("remote_model") or not model.get("size"):
                continue
            models.append({"name": name, "vision": False})
        return models

    def status(self):
        if self._discovery_cache is not None and time.monotonic() - self._discovery_at < 10:
            return self._discovery_cache
        try:
            base = self.url if self.process and self.process.poll() is None else "http://127.0.0.1:11434"
            models = self._local_models(self._request(base, "/api/tags"))
            for model in models:
                info = self._request(base, "/api/show", {"model": model["name"]})
                model["vision"] = "vision" in info.get("capabilities", [])
            result = {"available": bool(models) and bool(shutil.which("ollama")), "models": models,
                      "message": "분석에는 클라우드를 끈 별도 로컬 실행기를 사용합니다." if models else "Ollama에 로컬 모델을 설치해 주세요."}
        except (httpx.HTTPError, ValueError, KeyError, CounselingError):
            result = {"available": False, "models": [], "message": "Ollama를 실행한 뒤 연결을 다시 확인해 주세요."}
        self._discovery_cache, self._discovery_at = result, time.monotonic()
        return result

    def _ensure_service(self, stop=None):
        with self._lock:
            check_cancel(stop)
            if self.process and self.process.poll() is None:
                return
            if self._process_group:
                self._process_group.close()
                self._process_group = None
            executable = shutil.which("ollama")
            if not executable:
                raise CounselingError("ollama_missing", "Ollama 설치를 확인해 주세요.", 503)
            with socket.socket() as address:
                address.bind(("127.0.0.1", 0))
                port = address.getsockname()[1]
            self.url = f"http://127.0.0.1:{port}"
            environment = os.environ.copy()
            environment.update({"OLLAMA_NO_CLOUD": "1", "OLLAMA_NOPRUNE": "1", "OLLAMA_HOST": f"127.0.0.1:{port}", "OLLAMA_KEEP_ALIVE": "2m",
                                "OLLAMA_NUM_PARALLEL": "1", "OLLAMA_CONTEXT_LENGTH": str(CONTEXT_TOKENS), "OLLAMA_DEBUG": "0"})
            environment.pop("OLLAMA_ORIGINS", None)
            if self.models_dir:
                environment["OLLAMA_MODELS"] = str(Path(self.models_dir).expanduser().resolve())
            self.process = subprocess.Popen([executable, "serve"], env=environment, stdin=subprocess.DEVNULL,
                                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if os.name == "nt":
                group = None
                try:
                    group = _WindowsProcessGroup()
                    group.assign(self.process)
                    self._process_group = group
                except OSError as exc:
                    if group:
                        group.close()
                    self.process.terminate()
                    self.process.wait(timeout=8)
                    raise CounselingError("ollama_process_group", "로컬 모델의 종료 관리를 준비하지 못했습니다. 모델을 실행하지 않았습니다. 실행기 권한과 Windows 환경을 확인해 주세요.", 503) from exc
            for _ in range(60):
                check_cancel(stop)
                if self.process.poll() is not None:
                    raise CounselingError("ollama_start_failed", "로컬 Ollama 실행기를 시작하지 못했습니다. 메모리와 실행 상태를 확인해 주세요.", 503)
                try:
                    self._request(self.url, "/api/version", timeout=1)
                    return
                except (httpx.HTTPError, ValueError, CounselingError):
                    time.sleep(0.2)
            raise CounselingError("ollama_timeout", "Ollama 실행 준비가 지연되고 있습니다. 잠시 뒤 다시 시도해 주세요.", 503)

    def model_info(self, model, stop=None):
        self._ensure_service(stop)
        allowed = {item["name"] for item in self._local_models(self._request(self.url, "/api/tags"))}
        if model not in allowed:
            raise CounselingError("model_not_local", "이 PC에 설치된 로컬 모델을 선택해 주세요. 클라우드 모델은 사용할 수 없습니다.")
        info = self._request(self.url, "/api/show", {"model": model})
        if info.get("remote_host") or info.get("remote_model"):
            raise CounselingError("model_not_local", "원격 모델은 학생부 분석에 사용할 수 없습니다.")
        return info

    def generate(self, model: str, system: str, prompt: str, schema=None, images=None, stop=None, on_transport=None, max_tokens=2600):
        check_prompt_budget(system, prompt, schema, images, max_tokens)
        info = self.model_info(model, stop)
        check_prompt_budget(system, prompt, schema, images, max_tokens,
                            str(info.get("template", "")) + str(info.get("system", "")))
        if images and "vision" not in info.get("capabilities", []):
            raise CounselingError("vision_required", "스캔 PDF를 읽으려면 이미지 판독을 지원하는 로컬 모델이 필요합니다.")
        check_cancel(stop)
        message = {"role": "user", "content": prompt}
        if images:
            message["images"] = images
        payload = {"model": model, "messages": [{"role": "system", "content": system}, message], "stream": True,
                   "options": {"temperature": 0, "num_ctx": CONTEXT_TOKENS, "num_predict": max_tokens}}
        if "thinking" in info.get("capabilities", []):
            family = str(info.get("details", {}).get("family", "")).lower()
            payload["think"] = "low" if family in ("gptoss", "gpt-oss") or model.lower().startswith("gpt-oss") else False
        if schema is not None:
            payload["format"] = schema
        client = httpx.Client(trust_env=False, follow_redirects=False, timeout=httpx.Timeout(240, connect=8))
        output, output_size, done = [], 0, False
        try:
            if on_transport:
                on_transport(client.close)
            check_cancel(stop)
            with client.stream("POST", self.url + "/api/chat", json=payload) as response:
                if response.status_code != 200:
                    response.read()
                    try:
                        failure = response.json()
                    except ValueError:
                        failure = {}
                    raise generation_error(failure.get("error", "") if isinstance(failure, dict) else "", response.status_code)
                for line in response.iter_lines():
                    check_cancel(stop)
                    if not line:
                        continue
                    try:
                        item = json.loads(line)
                    except (TypeError, json.JSONDecodeError) as exc:
                        raise CounselingError("invalid_model_stream", "모델 응답 전송 형식이 올바르지 않습니다. 결과를 저장하지 않았습니다.", 503) from exc
                    if not isinstance(item, dict):
                        raise CounselingError("invalid_model_stream", "모델 응답 전송 형식을 확인할 수 없습니다.", 503)
                    if item.get("error"):
                        raise generation_error(item["error"])
                    message = item.get("message", {})
                    if not isinstance(message, dict) or not isinstance(message.get("content", ""), str):
                        raise CounselingError("invalid_model_stream", "모델의 최종 응답을 글자로 읽을 수 없습니다.", 503)
                    part = message.get("content", "")
                    output.append(part)
                    output_size += len(part)
                    if output_size > 180_000:
                        raise CounselingError("response_too_large", "모델 응답이 너무 깁니다. 상담 범위를 나누어 다시 실행해 주세요.")
                    if item.get("done") is True:
                        if item.get("done_reason") == "length":
                            raise CounselingError("response_truncated", "모델 응답이 길이 제한으로 끝났습니다. 다른 로컬 모델이나 짧은 분석 범위로 다시 시도해 주세요.")
                        done = True
            check_cancel(stop)
            if not done:
                raise CounselingError("response_incomplete", "모델 응답이 끝나기 전에 연결이 종료되었습니다. 결과는 확정하지 않았습니다.")
            final = "".join(output)
            if not final.strip():
                raise CounselingError("empty_model_response", "모델이 분석 본문을 반환하지 않았습니다. 응답 형식과 생각 모드 지원을 확인하거나 다른 로컬 모델을 선택해 주세요.")
            return final
        except httpx.TimeoutException as exc:
            check_cancel(stop)
            raise CounselingError("ollama_timeout", "로컬 모델 응답 대기시간을 초과했습니다. 모델 로딩·메모리 상태를 확인하거나 더 작은 로컬 모델을 선택해 주세요.", 503) from exc
        except (httpx.HTTPError, OSError) as exc:
            check_cancel(stop)
            raise CounselingError("ollama_connection", "Ollama 연결이 끊어졌습니다. 로컬 실행 상태를 확인한 뒤 다시 시도해 주세요.", 503) from exc
        finally:
            if on_transport:
                on_transport(None)
            client.close()

    def close(self):
        with self._lock:
            group, self._process_group = self._process_group, None
            try:
                if group:
                    group.close()
            finally:
                if self.process and self.process.poll() is None:
                    # Windows job close may still be completing termination.
                    if not group:
                        self.process.terminate()
                    try:
                        self.process.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        self.process.kill()
                        self.process.wait(timeout=3)
