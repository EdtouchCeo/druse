# 대륜고 상담실 통합과 배포

2026-09-12 · 버전 0.2.0. 구현과 합성 검증을 완료했다. 실제 운영 반영 결과는 별도 배포 기록으로 확인한다. 사용자가 개발·검증·배포를 승인했다.

## 구성

- 학교 로그인은 기존 Supabase Auth와 `users`를 사용한다. 승인된 학교 회원에게 별도의 상담 역할을 부여한다.
- 일반 상담은 Netlify의 비공개 site-wide Blobs 저장소 `daeryun-counseling-v1`에 보관한다. 브라우저에 저장소 자격 증명을 전달하지 않는다. 기본 운영에는 새 SQL 마이그레이션이 필요하지 않다.
- 학생은 본인 상담을 읽고 내려받는다. 현재 배정된 승인 교사가 작성·검토·확정한다. 관리자 역할만으로 상담 내용을 열람할 수 없다.
- 학생의 고정 UUID와 학년도별 학번을 연결한다. 역할·학생·담당 배정과 관리 이력은 조건부 저장으로 갱신한다.
- 상담 버전은 별도 객체에 보존하고 현재 버전 참조를 ETag로 비교·저장한다. 충돌하면 409로 응답한다. 여러 객체를 묶은 DB 트랜잭션은 아니며 저장 직전 권한을 다시 확인한다.
- 상담 함수와 회원 관리 함수는 Netlify native `.mjs` 진입점에서 실행한다. SDK의 자동 연결 정보로 강한 일관성을 사용하고 실패를 저장 완료로 표시하지 않는다.

## 학교 관리자의 첫 설정

기존 학교 관리자가 이메일 확인과 학교 승인을 마친 계정으로 상담실에 로그인하면 최초 관리자 역할을 한 번 연결하고 이력을 남긴다. 가입 화면의 역할 선택으로 관리자 권한을 얻을 수 없다.

1. 사용설명서에서 교사·학생의 학교 회원 승인을 확인한다.
2. 상담실 권한 관리에서 교사 또는 학생 상담 권한을 부여한다.
3. 학생 계정에 학년도·학번·학교급·학년을 등록한다. 이후 학번이 바뀌어도 고정 학생 ID를 유지한다.
4. 승인 교사를 학생의 담당 교사로 배정한다.

실제 계정의 등록과 배정은 운영자의 로그인 후 진행한다. 시험에서 실제 사용자로 가장하거나 학생 정보를 임의 등록하지 않았다.

## AI와 보관 범위

일반 상담 서버 AI는 기존 `GEMINI_API_KEY` 또는 `VERTEX_PROJECT`와 `VERTEX_SA_KEY`를 사용한다. `COUNSELING_SERVER_AI_ENABLED=false`이면 끄며 모델은 `LLM_MODEL` 또는 기존 학교 서비스의 기본값 `gemini-2.5-flash`다. 실제 호출은 담당 교사가 요청할 때 수행한다. 환경 존재와 실제 모델 응답 검증은 구분한다. 개인 Gemini와 개인 Ollama도 일반 상담에서 선택할 수 있다.

학생부 PDF·추출문·분석·전략·AI 문체 검토는 교사 PC의 로컬 Ollama만 사용한다. 온라인 API는 이 자료를 거절하며 자동 동기화나 외부 모델 대체를 하지 않는다. 로컬 자료는 기본 `%LOCALAPPDATA%\DaeryunCounsel`에 저장하며 프로젝트·OneDrive 아래의 데이터 경로를 거절한다.

## 배포와 확인

격리 작업본 `integrations/daeryun`에서 검토한 커밋을 `EdtouchCeo/druse`의 `main`에 push하면 기존 Netlify 배포가 실행된다. 원래 학교 작업 폴더는 수정하지 않는다. 시작 커밋은 `5a48a17ec334a3e9df4610b228af7a9fd76f7974`다.

Netlify 빌드에서 상담 API 검사 65개와 합성 deploy-store의 생성·강한 읽기·조건부 수정·충돌 거절·삭제를 검사한다. 이 임시 검사는 운영 site-wide 저장소의 쓰기 검증을 대신하지 않는다. 실패하면 배포를 중단한다.

- 상담실: `https://daeryun.life/counseling/`
- 안내: `https://daeryun.life/counseling/guide.html`
- 실행 파일: `https://daeryun.life/counseling/downloads/daeryun-counseling-local.zip`
- 상태: `/.netlify/functions/counseling-health`는 저장소 읽기·기존 회원 스키마·서버 AI 설정 여부만 반환한다. 회원 내용은 반환하지 않는다.

공개 배포 검사에서는 파일 해시·무인증 거절·새 브라우저 화면을 확인한다. 운영 계정의 저장·학생 조회와 실제 교사의 내용 검토는 로그인 후 확인한다.

## 유지 관리

API는 [API.md](../integrations/daeryun/API.md), 사용자 절차는 [사용 안내](43-counseling-user-guide.md), 검증 근거는 [검증 기록](44-counseling-verification.md)에 있다.

`supabase/migrations/202609110001_counseling.sql`은 선택적 후속 전환안이며 적용하지 않았다. `COUNSELING_STORAGE=supabase`는 별도 스키마·권한 검증 후 사용한다. 자동 저장소 전환은 없다. Blobs의 설정 문서는 10 MiB 상한이 있으며 커지면 이관이 필요하다. 같은 Netlify 사이트의 preview도 site-wide 저장소를 공유하므로 운영 자료를 사용하는 시험은 별도 사이트로 분리한다.
