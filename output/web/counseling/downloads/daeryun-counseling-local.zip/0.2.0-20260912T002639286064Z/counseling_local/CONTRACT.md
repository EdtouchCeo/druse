# 1차 구현 계약

코디네이터: 로컬 Python 서버·저장·Ollama·PDF 보고서·실행기. 프론트: `apps/counseling/`. 학생부 파서: `counseling_local/records.py`. 대륜고 연결: `integrations/daeryun/` 격리 체크아웃. 실제 학생 데이터는 이 소스 폴더에 저장하지 않는다.

로컬 서버는 `127.0.0.1:8765`에서 Vue 빌드(`/counseling/`)와 `/api/*`를 제공한다. JSON 성공 응답은 아래 구조, 오류는 `{error:{code,message}}`. 모든 변경 요청에 `/api/health`가 반환한 `csrf_token`을 `X-Counseling-Token`으로 보낸다. 데이터에는 `privacy: "local_only"`를 고정한다. 웹 배포 일반 상담은 별도 cloud transport를 사용한다.

## Case

```json
{
 "schema_version":1,"id":"uuid","revision":1,"privacy":"local_only",
 "created_at":"ISO","updated_at":"ISO","origin":"teacher",
 "student":{"student_id":"uuid","student_number":"10101","academic_year":2026,"school_stage":"high","grade":1,"name":""},
 "teacher":{"display_name":""},"current_session_id":"uuid",
 "sessions":[{"id":"uuid","date":"2026-09-11","topic":"","student_question":"","context":"","evidence_notes":"","teacher_opinion":"","actions":[{"id":"uuid","text":"","due_date":"","status":"planned"}],"next_date":"","record":null,"analysis":null,"review":null,"confirmed":null}]
}
```

세션의 record와 analysis는 API가 저장한다. 리뷰·확정은 임의 PUT으로 통과시킬 수 없다. PUT은 읽었던 revision을 포함하며 충돌 시 409. 수정된 세션의 review/confirmed를 무효화한다. 기존 확정 세션은 다음 회차로 이어서 쓰고 원본을 보존한다.

## Local API

- GET `/api/health` → `{version,mode:"local",demo:boolean,csrf_token,teacher:null|{id,display_name,approved:true},storage_path,ollama:{available,models:[{name,vision}],message}}`. models는 로컬 모델만.
- POST `/api/auth` `{access_token}` → 승인 교사를 고정 대륜고 endpoint에서 확인 후 로컬 메모리 세션 시작. 분석 본문은 전송하지 않음. 실제 endpoint 배포 전에는 demo로 검증.
- GET `/api/cases` → `{cases:[Case]}`.
- POST `/api/cases` `{student,teacher}` → `{case:Case}`. 최초 세션 생성.
- GET `/api/cases/{id}` → `{case:Case}`.
- PUT `/api/cases/{id}` `{case:Case}` → `{case:Case}`. ID·privacy·원본 보관 제약 검사.
- POST `/api/cases/{id}/sessions` `{revision}` → `{case:Case}`. 이전 상담 참고한 새 회차 생성.
- POST `/api/cases/{id}/record` `{revision,session_id,filename,pdf_base64,password?}` → `{case:Case}`. PDF 20MB/80페이지 제한, 원본은 로컬 개인 저장소. demo 모드는 제공한 합성 PDF 해시만 허용.
- POST `/api/cases/{id}/analyze` `{revision,session_id,model,goal,time_budget_minutes}` → `{job:{id,state}}`.
- POST `/api/cases/{id}/review` `{revision,session_id,model?}` → `{job:{id,state}}`. model이 있으면 Ollama 문체 검토, 없으면 자동 점검+교사 수동 검토용 결과. 수동 확인은 아래 별도 경로.
- POST `/api/cases/{id}/confirm` `{revision,session_id,review_acknowledged:true}` → `{case:Case}`. 근거·문체 검토 내용을 교사가 확인. 필수 내용/이력 검사.
- GET `/api/jobs/{id}` → `{job:{id,state:"queued"|"running"|"succeeded"|"needs_revision"|"failed"|"cancelled",stage,message,case_id}}`.
- POST `/api/jobs/{id}/cancel` `{}` → `{job}`.
- GET `/api/cases/{id}/export` → JSON 첨부. `{format:"daeryun-counseling",version:1,case:Case}`.
- POST `/api/import` `{bundle}` → `{case:Case}`. 새 ID/사본, 이전 확인 표시는 참고 이력으로만 보존. 상담 학생 식별을 UI에서 확인한 뒤 가져오기.
- GET `/api/cases/{id}/report.pdf?session_id=...` → 로컬 생성 PDF. 미확정은 초안 표시.
- GET `/api/fixtures` → `{fixtures:[{id,title,description}]}`; GET `/api/fixtures/{id}.pdf` 합성 PDF 다운로드.

## Record/Analysis

records.py는 `extract_record(pdf_bytes: bytes, filename: str, password: str|None=None) -> dict`를 제공한다. 출력은 `{id,filename,sha256,page_count,school_stage,sections:[{id,category,label,school_stage,academic_year,grade,semester,pages:[1],text,status}],warnings:[str],readable_pages:[int],unreadable_pages:[int]}`. status는 `present|empty|not_applicable|uncertain`. 범위에 없는 항목은 임의 empty로 추가하지 않는다. PDF의 식별 머리말은 분석에 불필요하면 제외하며 원문 페이지와 수치는 보존한다.

analysis는 `{summary,strengths:[{text,evidence_ids:[section-id],guidance}],improvements:[{text,evidence_ids:[section-id],guidance}],questions:[str],actions:[{text,reason,evidence_ids:[section-id]}],limitations:[str],model,created_at}`. Ollama 결과에서 실재하고 present인 section ID만 인용한다. 분석 텍스트는 사실 확인을 위한 초안이다. 누락/빈칸만으로 약점 판단 금지.

review는 `{state:"passed"|"needs_revision"|"pending",method:"manual"|"ollama",content_hash,notes:[str],created_at}`. content hash와 교사의 확인 기록은 로컬 서버 또는 인증된 cloud API만 생성한다. 프론트가 통과를 만들어 보내지 않는다.

## Cloud adapter

`/.netlify/functions/counseling-session` GET Bearer → `{user:{id,role:"teacher"|"student",approved:boolean,display_name,student_id?},ai:{server:boolean}}`.
`/.netlify/functions/counseling-cases` GET 목록, GET `?id=`, POST 생성, PUT 수정, POST `?action=next|confirm|import` 등은 로컬 Case 형식과 대응. 실제 cloud 계약은 integration 담당자가 API.md로 명시하고 프론트에 전달.
`/.netlify/functions/counseling-ai` POST 표준 상담용만. 학생부/프리미엄 입력 불허. Supabase 승인 역할을 검증한 뒤 기존 Vertex/Gemini 서버 모듈을 재사용. Firebase 토큰을 위조하거나 공개 generate-open에 우회하지 않음.

Cloud에서는 private student PDF 분석 UI를 제공하지 않고 로컬 실행 안내로 연결한다. Local 브라우저는 local assets만 사용하고 학생부 데이터를 외부로 보내는 AI transport를 포함하지 않는다.
