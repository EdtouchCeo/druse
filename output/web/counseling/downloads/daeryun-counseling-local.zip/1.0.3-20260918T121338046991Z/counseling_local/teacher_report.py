"""Consumer-readable analysis and strategy, with source audits kept in the app."""
from __future__ import annotations

import re

from .domain import strategy_value
from .report import Report, STRATEGY_LABELS, analysis_document_title, write_actions, write_admission_targets


NAVY = (0.13, 0.25, 0.37)
MUTED = (0.36, 0.42, 0.48)
PALE = (0.92, 0.95, 0.97)
AREAS = ("학업", "탐구", "진로", "공동체", "자기관리", "기타")


class TeacherReport(Report):
    """Add document hierarchy without changing the student report renderer."""

    def __init__(self, title):
        self.bookmarks = []
        super().__init__(title)

    def section(self, title, *, page_break=False, minimum_height=105):
        self.flush_headings()
        if (page_break and self.y > 68) or self.y + minimum_height > 785:
            self.new_page()
        self.y += 6
        self.page.draw_rect((46, self.y - 10, 549, self.y + 21), color=None, fill=PALE)
        self.page.draw_rect((46, self.y - 10, 49, self.y + 21), color=None, fill=NAVY)
        self.page.insert_text((58, self.y + 10), title, fontname="CounselingFont", fontsize=12.5, color=NAVY)
        self.bookmarks.append([1, title, self.page.number + 1])
        self.y += 41

    def flush_headings(self, body_lines=0, body_size=10.5):
        if not self.pending_headings:
            return
        headings = [self.wrapped_lines(value, 11.5) for value in self.pending_headings]
        fragment = min(3 if body_lines == 3 else 2, body_lines)
        needed = sum(14 + len(lines) * 11.5 * 1.65 for lines in headings) + fragment * body_size * 1.65
        if self.y > 68 and self.y + needed > 785:
            self.new_page()
        self.pending_headings = []
        for lines in headings:
            self.y += 9
            for value in lines:
                self.line(value, 11.5, NAVY)
            self.y += 5

    def finding(self, index, item, sections, guidance_label="이어갈 방향"):
        self.table(["기록에서 확인한 특징", guidance_label],
                   [[item.get("text", ""), item.get("guidance") or "교사와 학생이 함께 확인할 필요가 있습니다."]],
                   [270, 233])

    def finish(self):
        if self.bookmarks:
            self.doc.set_toc(self.bookmarks)
        return super().finish()


def evidence_location(item, sections):
    references = []
    for evidence_id in item.get("evidence_ids", []):
        source = sections.get(evidence_id)
        if source:
            pages = ", ".join(map(str, source.get("pages", [])))
            label = source.get("label", "기록")
            context = []
            if source.get("academic_year"):
                context.append(str(source["academic_year"]) + "학년도")
            if source.get("grade"):
                context.append(str(source["grade"]) + "학년")
            if source.get("semester"):
                context.append(str(source["semester"]) + "학기")
            references.append(label + (" · " + " · ".join(context) if context else "") +
                              (" " + pages + "쪽" if pages else ""))
        else:
            references.append("원문 위치 확인 필요")
    return "; ".join(references)


def finding_area(item, sections):
    sources = [sections.get(key) or {} for key in item.get("evidence_ids") or []]
    career_words = re.compile(r"관심|진로|전공|과목.{0,12}선택")
    if (item.get("area") in ("학업", "탐구", "기타") and item.get("quote") and "guidance" in item and sources
            and all(source.get("category") in ("career", "진로활동") or "진로활동" in str(source.get("label", "")) for source in sources)
            and career_words.search(str(item.get("text", "")))
            and all(career_words.search(str(source.get("text", ""))) for source in sources)):
        return "진로"
    if item.get("area") in AREAS:
        return item["area"]
    labels = " ".join(str(source.get("label", "")) + " " + str(source.get("category", "")) for source in sources)
    for area, words in (("학업", ("교과", "세부능력", "subject", "academic")),
                        ("진로", ("진로", "career")),
                        ("공동체", ("봉사", "자율", "자치", "행동특성", "volunteer", "autonomous", "autonomy", "behavior")),
                        ("탐구", ("동아리", "club")), ("자기관리", ("출결", "attendance"))):
        if any(word in labels for word in words):
            return area
    return "기타"


def write_grouped_findings(report, items, sections, *, improvement=False):
    grouped = {}
    for item in items:
        grouped.setdefault(finding_area(item, sections), []).append(item)
    for area in AREAS:
        if area not in grouped:
            continue
        report.heading(area + " 영역")
        report.table(["기록에서 확인한 특징", "보완 방향·필요한 도움" if improvement else "이어갈 방향"],
                     [[item.get("text", ""), item.get("guidance") or "교사와 학생이 함께 확인할 필요가 있습니다."]
                      for item in grouped[area]], [270, 233])



def write_proposed_actions(report, actions, sections, *, section_title=None):
    if not actions:
        return
    rows = []
    for index, item in enumerate(actions, 1):
        task = f"{index}. {item.get('text', '')}"
        if item.get("reason"):
            task += "\n\n제안 이유: " + item["reason"]
        outcome = "준비할 자료·결과물: " + (item.get("expected_output") or "상담에서 구체화할 내용")
        if item.get("review_criteria"):
            outcome += "\n\n담을 내용: " + item["review_criteria"]
        support = "교사 도움: " + (item.get("teacher_support") or "교사·학생 확인 필요")
        rows.append([finding_area(item, sections), task, outcome, support])
    widths = [55, 165, 140, 143]
    first_height = max(len(report.wrapped_lines(value, 9.5, width - 18))
                       for value, width in zip(rows[0], widths)) * 15.2 + 18
    needed = min(first_height, 570) + 70
    if section_title:
        report.section(section_title, minimum_height=needed + 47)
    elif report.y > 68 and report.y + needed + len(report.pending_headings) * 34 > 785:
        report.new_page()
    report.table(["영역", "추천 준비 방향·이유", "준비할 자료·결과물", "필요한 도움"], rows, widths)


def write_saved_actions(report, session, heading):
    write_actions(report, session, heading)


def write_saved_strategy(report, session, heading):
    strategy = strategy_value(session.get("strategy", {}))
    present = [(label, key, strategy[key]) for label, key in STRATEGY_LABELS if strategy[key]]
    if present:
        report.heading(heading)
        for label, key, value in present:
            report.heading(label)
            (report.roadmap_text if key == "semester_plan" else report.plan_text)(value)


def analysis_counts(analysis):
    return " · ".join(f"{label} {len(analysis.get(key) or [])}개" for label, key in
                      (("강점", "strengths"), ("보완 판단", "improvements"),
                       ("행동 후보", "actions"), ("확인 질문", "questions")))


def is_consolidated(analysis):
    details = analysis.get("analysis_details")
    synthesis = details.get("synthesis") if isinstance(details, dict) else None
    return isinstance(synthesis, dict) and synthesis.get("method") == "candidate_selection"


def teacher_report_pdf(case, session, *, synthetic, valid_confirmation, imported,
                       unverified_record, unverified_analysis):
    """Export useful current analysis and strategy, without private working history."""
    title = analysis_document_title(case, session)
    report = TeacherReport(title)
    report.paragraph(title, 19)
    status = "시연 확정본" if synthetic and valid_confirmation else "교사 확인본" if valid_confirmation else "초안 · 교사 확인 전"
    student = session.get("student_snapshot") or case["student"]
    teacher = session.get("teacher_snapshot") or case["teacher"]
    metadata = [f"{student['academic_year']}학년도",
                f"{'중학교' if student['school_stage'] == 'middle' else '고등학교'} {student['grade']}학년"]
    if student.get("student_number"):
        metadata.append("학번 " + student["student_number"])
    report.paragraph(" · ".join(metadata), 9)
    details = [status, "작성일 " + session["date"]]
    if teacher.get("display_name"):
        details.append("담당 교사 " + teacher["display_name"])
    report.paragraph(" · ".join(details), 9)
    write_admission_targets(report, session)
    if synthetic:
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이나 교사의 검토 결과가 아닙니다.", 9)
    if imported and (unverified_record or unverified_analysis):
        report.paragraph("가져온 미검증 참고 자료 · 학생부 원문과 대조하여 확인해야 합니다.", 9)

    analysis = session.get("analysis") or {}
    record = session.get("record") or {}
    sections = {item.get("id"): item for item in record.get("sections", []) if isinstance(item, dict)}
    strategy = strategy_value(session.get("strategy", {}))
    section_number = 1

    def section(label):
        nonlocal section_number
        report.section(f"{section_number:02}  {label}")
        section_number += 1

    # The current direction appears before source detail, regardless of saved history length.
    if session.get("topic") or any(strategy.values()):
        section("학습·진로 전략의 핵심")
        if session.get("topic"):
            report.paragraph(session["topic"], 12)
        if strategy["student_message"]:
            report.heading("전략의 핵심과 먼저 준비할 사항")
            report.plan_text(strategy["student_message"])
        for label, key in STRATEGY_LABELS[:2]:
            if strategy[key]:
                report.heading(label)
                report.plan_text(strategy[key])

    if analysis:
        section("학교생활기록부 상세 분석")
        if analysis.get("summary"):
            report.heading("기록 전체에서 읽히는 특징")
            report.plan_text(analysis["summary"])
        for label, key in (("영역별 강점과 이어갈 방향", "strengths"),
                           ("영역별 보완 방향과 필요한 도움", "improvements")):
            if analysis.get(key):
                report.heading(label)
                write_grouped_findings(report, analysis[key], sections, improvement=key == "improvements")
    elif not record:
        report.paragraph("학생부가 아직 없어 입력한 자료를 바탕으로 준비 방향을 정리했습니다.", 9)

    present = [(label, strategy[key]) for label, key in STRATEGY_LABELS[2:4] if strategy[key]]
    if present:
        section("분석을 바탕으로 선택한 성장 방향")
        for label, value in present:
            report.heading(label)
            report.plan_text(value)
    for label, key in STRATEGY_LABELS[4:8]:
        if strategy[key]:
            section(label)
            (report.roadmap_text if key == "semester_plan" else report.plan_text)(strategy[key])
    if not any(strategy.values()) and session.get("actions"):
        section("학생이 준비할 사항")
        write_saved_actions(report, session, "추천 준비 내용")
    # The current strategy supersedes preliminary record-analysis suggestions.
    # Keep those candidates in the independent analysis export, without mixing
    # unselected ideas and questions into a consultation-informed strategy.
    if not any(strategy.values()) and analysis.get("actions"):
        write_proposed_actions(report, analysis["actions"], sections,
                               section_title=f"{section_number:02}  근거에 따른 추천 준비 방향")
        section_number += 1
    if not any(strategy.values()) and analysis.get("questions"):
        section("진로 선택을 구체화할 질문")
        for index, question in enumerate(analysis["questions"], 1):
            report.paragraph(f"{index}. {question}")
    if record or analysis:
        section("자료 범위와 해석 시 참고할 점")
        if record:
            total = record.get("page_count", 0)
            readable = len(record.get("readable_pages") or [])
            report.paragraph(f"제공된 학교생활기록부 {total}쪽" +
                             (f" · 판독된 자료 {readable}쪽" if readable < total else ""), 9)
        for item in dict.fromkeys([*(record.get("warnings") or []), *(analysis.get("limitations") or [])]):
            report.paragraph(item, 9)
    return report.finish()
