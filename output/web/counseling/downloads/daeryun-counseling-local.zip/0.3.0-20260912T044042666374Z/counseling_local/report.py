"""Offline PDF rendering. No HTML renderer, external font, or network dependency."""
from __future__ import annotations

import fitz

from .domain import CounselingError, content_hash, strategy_value


STRATEGY_LABELS = (("목표 전공·관심 분야", "target_major"), ("희망 진로·진학 방향", "target_path"),
                   ("근거에서 확인한 강점", "strengths"), ("보완할 점과 필요한 도움", "gaps"),
                   ("교과 학습 계획", "subject_plan"), ("탐구 계획", "inquiry_plan"),
                   ("활동 계획", "activity_plan"), ("학기별 실행 계획", "semester_plan"),
                   ("학생에게 전하는 안내", "student_message"))


def write_strategy(report, session):
    strategy = strategy_value(session.get("strategy", {}))
    if any(strategy.values()):
        report.heading("학생 성장·학습·진학 전략")
        for label, key in STRATEGY_LABELS:
            if strategy[key]:
                report.heading(label)
                report.paragraph(strategy[key])


def write_actions(report, session):
    if session.get("actions"):
        report.heading("합의한 실행 과제")
        labels = {"planned": "예정", "in_progress": "진행 중", "done": "완료", "deferred": "보류"}
        for index, action in enumerate(session["actions"]):
            report.paragraph(f"{index + 1}. {action['text']} ({labels.get(action['status'], action['status'])})")
            if action.get("due_date"):
                report.paragraph("점검 기한: " + action["due_date"], 9)


def student_report_pdf(case, session):
    """Render only the teacher-confirmed student-facing projection."""
    report = Report("대륜고 학생 안내 · 학종 전략과 실행 계획")
    report.paragraph("학생 안내 · 학종 전략과 실행 계획", 19)
    synthetic = case.get("origin") == "synthetic"
    if synthetic:
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이나 실제 교사의 검토 결과가 아닙니다.")
    report.paragraph("상태: " + ("시연 확정본" if synthetic else "교사 확인본"))
    student = session.get("student_snapshot") or case["student"]
    teacher = session.get("teacher_snapshot") or case["teacher"]
    report.paragraph(f"학년도 {student['academic_year']} / 학번 {student['student_number'] or '미입력'}")
    if student.get("name"):
        report.paragraph("학생 이름: " + student["name"])
    report.paragraph("담당 교사: " + teacher.get("display_name", ""))
    report.paragraph("작성일: " + session["date"])
    if session.get("topic"):
        report.heading("전략 제목")
        report.paragraph(session["topic"])
    write_strategy(report, session)
    write_actions(report, session)
    if session.get("next_date"):
        report.heading("다음 점검")
        report.paragraph(session["next_date"])
    report.heading("교사 확인 및 전달")
    report.paragraph("합성자료 시연의 확정 표시입니다. 실제 교사의 검토나 학생 전달을 뜻하지 않습니다." if synthetic else
                     "교사가 현재 전략과 실행 과제의 근거·내용·문체를 확인했습니다. 이 PDF는 교사가 학생에게 직접 전달합니다.", 9)
    return report.finish()


class Report:
    def __init__(self, title):
        self.doc = fitz.open()
        self.font = fitz.Font("korea")
        self.title = title
        self.page = None
        self.y = 0
        self.new_page()

    def new_page(self):
        self.page = self.doc.new_page(width=595, height=842)
        self.page.insert_font(fontname="CounselingFont", fontbuffer=self.font.buffer)
        self.page.insert_text((46, 34), "대륜고 학종 전략실", fontname="CounselingFont", fontsize=9, color=(0.25, 0.3, 0.4))
        self.page.draw_line((46, 43), (549, 43), color=(0.8, 0.83, 0.87), width=0.5)
        self.y = 68

    def line(self, value, size=10.5, color=(0.13, 0.17, 0.22)):
        if self.y + size * 1.65 > 785:
            self.new_page()
        self.page.insert_text((46, self.y), value, fontname="CounselingFont", fontsize=size, color=color)
        self.y += size * 1.65

    def paragraph(self, value, size=10.5):
        value = str(value or "")
        for paragraph in value.splitlines() or [""]:
            buffer = ""
            for char in paragraph:
                if char == "\x00":
                    continue
                if buffer and self.font.text_length(buffer + char, fontsize=size) > 500:
                    boundary = buffer.rfind(" ")
                    if boundary > len(buffer) // 2:
                        self.line(buffer[:boundary], size)
                        buffer = buffer[boundary + 1:]
                    else:
                        self.line(buffer, size)
                        buffer = ""
                buffer += char
            self.line(buffer, size)
        self.y += 5

    def heading(self, value):
        if self.y > 736:
            self.new_page()
        self.y += 9
        self.paragraph(value, 12.5)

    def finish(self):
        count = len(self.doc)
        for index, page in enumerate(self.doc):
            page.insert_text((46, 813), "개인 전략 자료 · 로컬 보관", fontname="CounselingFont", fontsize=8, color=(0.4, 0.43, 0.48))
            page.insert_text((500, 813), f"{index + 1} / {count}", fontname="CounselingFont", fontsize=8, color=(0.4, 0.43, 0.48))
        self.doc.set_metadata({"title": self.title, "author": "대륜고 학종 전략실", "subject": self.title})
        output = self.doc.tobytes(garbage=4, deflate=True)
        self.doc.close()
        return output


def report_pdf(case, session, audience="teacher"):
    if audience not in ("teacher", "student"):
        raise CounselingError("invalid_audience", "보고서 대상은 교사 또는 학생으로 선택해 주세요.")
    synthetic = case.get("origin") == "synthetic"
    confirmed = session.get("confirmed")
    imported = bool(session.get("imported_unverified"))
    unverified_analysis = imported and session.get("analysis") is not None
    unverified_record = imported and session.get("record") is not None
    valid_confirmation = bool(not (unverified_record or unverified_analysis) and confirmed and confirmed.get("content_hash") == content_hash(case, session))
    if audience == "student":
        if not any(strategy_value(session.get("strategy", {})).values()):
            raise CounselingError("student_guidance_required", "학생 안내 내용이 없습니다. 새 전략 차수에 안내 내용을 작성한 뒤 검토·확정해 주세요.", 409)
        if not valid_confirmation:
            raise CounselingError("student_report_unconfirmed", "학생 안내 PDF는 현재 전략과 실행 과제를 교사가 검토하고 확정한 뒤 저장할 수 있습니다.", 409)
        return student_report_pdf(case, session)
    report = Report("대륜고 교사용 분석·학종 전략 보고서")
    report.paragraph("교사용 분석·학종 전략 보고서", 19)
    if synthetic:
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이나 실제 교사의 검토 결과가 아닙니다.")
    report.paragraph("상태: " + ("시연 확정본" if synthetic and valid_confirmation else "교사 확인본" if valid_confirmation else "초안 · 교사 확인 전"))
    if imported:
        report.paragraph("가져온 상담 자료입니다. 이전 파일의 검토·확정 표시는 현재 교사의 확인을 대신하지 않습니다.")
        if unverified_record or unverified_analysis:
            report.paragraph("가져온 학생부·분석은 원본 PDF와 대조하지 않은 참고 자료입니다. 원본 PDF를 다시 불러와 확인하기 전에는 이 회차를 확정할 수 없습니다.")
    student = session.get("student_snapshot") or case["student"]
    teacher = session.get("teacher_snapshot") or case["teacher"]
    report.paragraph(f"학년도 {student['academic_year']} / {'중학교' if student['school_stage'] == 'middle' else '고등학교'} {student['grade']}학년 / 학번 {student['student_number'] or '미입력'}")
    if student.get("name"):
        report.paragraph("학생 이름: " + student["name"])
    report.paragraph(f"작성일 {session['date']} / 담당 교사 {teacher.get('display_name') or '미입력'}")
    report.paragraph(f"전략 차수 {case['sessions'].index(session) + 1} / 저장 버전 {case['revision']}", 9)
    for heading, key in (("전략 제목", "topic"), ("학생의 질문", "student_question"), ("현재 상황과 이전 상담", "context"),
                         ("검토한 자료", "evidence_notes"), ("교사의 상담 의견", "teacher_opinion")):
        if session.get(key):
            report.heading(heading)
            report.paragraph(session[key])
    write_strategy(report, session)
    record = session.get("record") or {}
    analysis = session.get("analysis")
    if record:
        report.heading("학생부 분석 범위")
        report.paragraph(f"제공된 PDF {record.get('page_count', 0)}쪽 / 읽힌 페이지 {len(record.get('readable_pages', []))}쪽")
        for warning in record.get("warnings", []):
            report.paragraph(warning, 9)
    if analysis:
        report.heading("분석 요약 · 가져온 미검증 참고 자료" if unverified_analysis else "분석 요약")
        report.paragraph(analysis.get("summary", ""))
        sections = {item.get("id"): item for item in record.get("sections", []) if isinstance(item, dict)}
        for label, key in (("기록에서 확인한 강점", "strengths"), ("보완할 부분과 지도 방향", "improvements")):
            report.heading(label)
            if not analysis.get(key):
                report.paragraph("제공된 자료에서 판단할 근거가 충분하지 않습니다.")
            for index, item in enumerate(analysis.get(key, [])):
                report.paragraph(f"{index + 1}. {item.get('text', '')}")
                if item.get("quote"):
                    report.paragraph("원문 근거: " + item["quote"], 9)
                references = []
                for evidence_id in item.get("evidence_ids", []):
                    source = sections.get(evidence_id)
                    if source:
                        references.append(source.get("label", "기록") + " " + ", ".join(map(str, source.get("pages", []))) + "쪽")
                if references:
                    report.paragraph("확인 위치: " + "; ".join(references), 9)
                if item.get("guidance"):
                    report.paragraph("지도 방향: " + item["guidance"])
        if analysis.get("actions"):
            report.heading("학생의 다음 행동 제안")
            for index, item in enumerate(analysis["actions"]):
                report.paragraph(f"{index + 1}. {item.get('text', '')}")
                if item.get("reason"):
                    report.paragraph(item["reason"], 9)
        if analysis.get("questions"):
            report.heading("상담에서 확인할 질문")
            for index, question in enumerate(analysis["questions"]):
                report.paragraph(f"{index + 1}. {question}")
        if analysis.get("limitations"):
            report.heading("해석 범위와 확인할 점")
            for item in analysis["limitations"]:
                report.paragraph(item, 9)
        report.paragraph(f"분석 모델: {analysis.get('model', '확인 필요')} / " + ("가져온 파일의 표기 · 실행 이력 미검증" if unverified_analysis else "로컬 실행"), 9)
    write_actions(report, session)
    if session.get("next_date"):
        report.heading("다음 점검")
        report.paragraph(session["next_date"])
    review = session.get("review")
    report.heading("최종 확인")
    if review:
        review_label = {"passed": "검토 통과", "needs_revision": "수정 필요", "pending": "교사 확인 필요"}.get(review.get("state"), "미검토")
        report.paragraph("문체 검토: " + review_label + (" / 로컬 AI 검토" if review.get("method") == "ollama" else " / 수동 검토"), 9)
    else:
        report.paragraph("문체 검토와 교사 확인을 거치기 전의 초안입니다.", 9)
    return report.finish()
