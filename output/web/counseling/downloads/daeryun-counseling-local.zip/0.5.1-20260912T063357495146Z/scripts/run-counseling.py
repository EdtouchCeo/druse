"""Start the local-only counseling application from any working directory."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from counseling_local.server import main

if __name__ == "__main__":
    main()
