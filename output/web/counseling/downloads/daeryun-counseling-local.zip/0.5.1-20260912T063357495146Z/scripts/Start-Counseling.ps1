param([switch]$Demo, [int]$Port = 8765, [string]$ModelsDir = '')
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$taskRuntime = Join-Path $env:LOCALAPPDATA 'DaeryunCounselRuntime\v1\Scripts\python.exe'
$taskPython = if (Test-Path -LiteralPath $taskRuntime) { $taskRuntime } else { (Get-Command python -ErrorAction Stop).Source }
& $taskPython -c 'import fitz,httpx,pypdf'
if ($LASTEXITCODE -ne 0) { throw 'Run scripts\Setup-Counseling.ps1 first.' }
$taskHealth = $null
try { $taskHealth = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 2 } catch { }
if ($taskHealth) {
    if ($taskHealth.mode -ne 'local' -or $taskHealth.demo -ne [bool]$Demo) { throw 'This port is already in use in another mode. Close that counseling window or choose -Port 8766.' }
    Start-Process "http://127.0.0.1:$Port/counseling/"
    exit 0
}
$taskArguments = @('-X', 'utf8', (Join-Path $taskRoot 'scripts\run-counseling.py'), '--port', "$Port", '--open')
if ($Demo) { $taskArguments += '--demo' }
if ($ModelsDir) { $taskArguments += @('--models-dir', $ModelsDir) }
Write-Host 'Daeryun counseling is running locally. Close this console with Ctrl+C when finished.'
& $taskPython @taskArguments
exit $LASTEXITCODE
