$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$taskRuntime = Join-Path $env:LOCALAPPDATA 'DaeryunCounselRuntime\v1'
$taskPython = (Get-Command python -ErrorAction Stop).Source
& $taskPython -c 'import sys; assert sys.version_info >= (3,11), "Python 3.11 or later required"'
if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or later is required.' }
& $taskPython -m venv $taskRuntime
if ($LASTEXITCODE -ne 0) { throw 'Could not create the local runtime.' }
$taskRuntimePython = Join-Path $taskRuntime 'Scripts\python.exe'
& $taskRuntimePython -m pip install --disable-pip-version-check -r (Join-Path $taskRoot 'counseling_local\requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check the network and retry.' }
Write-Host 'Setup completed. Open the counseling demo launcher.'
