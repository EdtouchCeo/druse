"""Deterministic, identifier-free technical PDF fixtures generated in memory."""
from __future__ import annotations

from functools import lru_cache
import fitz


_FIXTURES = [
    {"id": "middle-3", "title": "중3 합성 학생부", "description": "중학교 원항목·자유학기·여러 기록 학년도를 포함한 기술 합성 자료"},
    {"id": "high-1-partial", "title": "고1 부분 작성 합성 학생부", "description": "작성된 학습 근거와 빈 항목을 구별하는 기술 합성 자료"},
    {"id": "high-2-complete", "title": "고2 작성 완료 합성 학생부", "description": "학기별 학습·활동·피드백 변화와 별도 원항목을 포함한 기술 합성 자료"},
]


def list_fixtures() -> list[dict]:
    return [dict(item) for item in _FIXTURES]


def _page(document, stage: str, lines: list[str]):
    page = document.new_page(width=595, height=842)
    page.insert_text((40, 35), "교육용 기술 합성 자료 - 실제 학생 기록 아님", fontname="korea", fontsize=10)
    page.insert_text((40, 57), f"기술합성 {stage} 학교생활기록부", fontname="korea", fontsize=12)
    y = 83
    for line in lines:
        if line:
            page.insert_text((40, y), line, fontname="korea", fontsize=10)
        y += 20
    page.insert_text((285, 817), str(len(document)), fontname="helv", fontsize=9)


@lru_cache(maxsize=3)
def fixture_pdf(fixture_id: str) -> bytes:
    if fixture_id not in {item["id"] for item in _FIXTURES}:
        raise ValueError("알 수 없는 합성 PDF입니다.")
    document = fitz.open()
    if fixture_id == "middle-3":
        _page(document, "중학교", [
            "2026학년도 3학년", "1. 출결상황", "수업일수 190일, 결석 0일, 지각 0회, 조퇴 0회, 결과 0회", "2. 수상경력", "없음",
            "3. 창의적 체험활동상황", "자율활동", "공동 물품 사용 규칙을 비교하고 친구들의 의견에 따라 안내문을 수정함.",
            "동아리활동", "씨앗의 발아를 관찰하고 조건을 같게 유지해야 하는 이유를 설명함.", "봉사활동실적", "도서 정리 활동 2시간", "진로활동",
            "환경과 디자인 관련 활동을 비교하고 앞으로 알아볼 질문을 작성함.",
        ])
        _page(document, "중학교", [
            "2024학년도 1학년 1학기", "4. 자유학기활동상황", "주제선택활동", "생활 속 물 사용량을 표로 정리하고 절약 방법을 토론함.",
            "진로탐색활동", "관심 있는 일의 일상적인 업무를 알아보고 궁금한 점을 정리함.",
            "2026학년도 3학년 1학기", "5. 교과학습발달상황", "과목: 과학, 성취도: B", "세부능력 및 특기사항",
            "실험에서 변인을 구별하고 관찰 결과와 자신의 예상을 분리하여 설명함.",
            "6. 독서활동상황", "가상의 환경 탐구 책(합성 저자)", "7. 행동특성 및 종합의견",
            "의견이 다른 상황에서 상대의 이유를 듣고 공동 과제의 방법을 수정함.",
        ])
    elif fixture_id == "high-1-partial":
        _page(document, "고등학교", [
            "2026학년도 1학년 1학기", "1. 출결상황", "수업일수 95일, 결석 0일, 지각 0회, 조퇴 0회, 결과 0회",
            "2. 수상경력", "미기재", "3. 자격증 및 인증 취득상황", "해당 없음", "4. 교과학습발달상황",
            "과목: 통합과학1, 성취도: B", "세부능력 및 특기사항",
            "측정값을 표로 정리하고 예상과 다른 결과가 나온 조건을 다시 확인함.",
            "과목: 공통국어1, 성취도: B", "서로 다른 자료의 관점을 비교하고 출처를 확인하여 설명을 수정함.",
        ])
        _page(document, "고등학교", [
            "2026학년도 1학년 2학기", "5. 창의적 체험활동상황", "자율·자치활동", "공동 활동의 진행 순서를 정하는 회의에서 대안을 제시함.",
            "동아리활동", "작성 중", "진로활동", "미작성", "6. 독서활동상황", "미기재", "7. 행동특성 및 종합의견", "미작성",
        ])
    else:
        for year, grade, semester in [(2025, 1, 1), (2025, 1, 2), (2026, 2, 1), (2026, 2, 2)]:
            _page(document, "고등학교", [
                f"{year}학년도 {grade}학년 {semester}학기", "1. 출결상황", "수업일수 95일, 결석 0일, 지각 0회, 조퇴 0회, 결과 0회",
                "2. 수상경력", "가상 교내 탐구 발표상, 학교 주관, 기술 합성 수상 기록", "3. 자격증 및 인증 취득상황", "해당 없음",
                "4. 국가직무능력표준 이수상황", "해당 없음", "5. 창의적 체험활동상황", "자율·자치활동",
                "학급의 자료 공유 방법을 비교하고 사용자의 의견을 받아 운영 방법을 수정함.", "동아리활동",
                "공개된 환경 자료의 측정 조건을 비교하고 비교 가능한 범위를 구별함.", "진로활동",
                "관심 분야가 바뀐 이유를 설명하고 관련 과목에서 확인할 학습 질문을 정함.",
                "6. 교과학습발달상황", "세부능력 및 특기사항",
                f"{grade}학년 {semester}학기의 합성 학습 관찰: 서로 다른 자료를 비교하고 해석의 한계를 설명함.",
                "피드백을 받아 표의 단위를 수정하고 수정 전후의 차이를 직접 설명함.",
                "7. 독서활동상황", "가상의 자료 해석 책(합성 저자)", "8. 행동특성 및 종합의견",
                "과제를 작은 단계로 나누고 필요한 도움을 요청하며 정한 행동을 점검함.",
            ])
    document.set_metadata({"title": "교육용 기술 합성 학생부", "subject": "실제 학생자료를 사용하지 않은 PDF 파서 검증용", "author": "Synthetic fixture generator"})
    result = document.tobytes(garbage=4, deflate=True, no_new_id=True)
    document.close()
    return result
