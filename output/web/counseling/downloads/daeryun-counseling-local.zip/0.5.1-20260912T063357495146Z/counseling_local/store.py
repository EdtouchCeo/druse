"""Private local SQLite storage outside the shared source tree."""
from __future__ import annotations

import json
import os
import sqlite3
import stat
from contextlib import contextmanager
from pathlib import Path

from .domain import CounselingError, normalize_case, now, require_revision


def _require_private_location(path: Path) -> None:
    forbidden = [Path(__file__).resolve().parents[1]]
    for key in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        if os.environ.get(key):
            forbidden.append(Path(os.environ[key]).resolve())
    if any("onedrive" in part.lower() for part in path.parts) or any(path == item or path.is_relative_to(item) for item in forbidden):
        raise CounselingError("synced_storage", "상담 저장 폴더는 소스 폴더와 OneDrive 동기화 폴더 밖에 지정해 주세요.")


def private_data_root(path=None) -> Path:
    root = Path(path) if path else Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local" / "share"))) / "DaeryunCounsel"
    root = root.expanduser().absolute()
    _require_private_location(root)
    root = root.resolve()
    _require_private_location(root)
    root.mkdir(parents=True, exist_ok=True)
    return root


class Store:
    def __init__(self, root: Path):
        self.root = private_data_root(root)
        self.db_path = self.root / "counseling.sqlite3"
        self.files = self.root / "documents"
        self._checked_path(self.files, directory=True)
        self.files.mkdir(exist_ok=True)
        self._checked_path(self.files, directory=True)
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("CREATE TABLE IF NOT EXISTS cases (id TEXT PRIMARY KEY, owner TEXT NOT NULL, revision INTEGER NOT NULL, body TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, at TEXT NOT NULL, owner TEXT NOT NULL, case_id TEXT NOT NULL, event TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS case_versions (case_id TEXT NOT NULL, owner TEXT NOT NULL, revision INTEGER NOT NULL, body TEXT NOT NULL, at TEXT NOT NULL, PRIMARY KEY(case_id, revision))")
            db.execute("INSERT OR IGNORE INTO case_versions SELECT id, owner, revision, body, ? FROM cases", (now(),))

    def _checked_path(self, path: Path, *, directory=False) -> Path:
        """Check existing nodes without following links, including dangling links.

        The root is canonical and pinned when this Store is opened. Recheck it on
        each access so a later documents/root junction is not silently followed.
        This guards persisted redirects, not concurrent changes by the OS user.
        """
        try:
            relative = path.relative_to(self.root)
            if ".." in relative.parts or self.root.resolve() != self.root:
                raise ValueError("redirected root")
            _require_private_location(self.root)
            resolved = path.resolve()
            if not resolved.is_relative_to(self.root):
                raise ValueError("outside private root")
            _require_private_location(resolved)
            nodes = [self.root]
            for part in relative.parts:
                nodes.append(nodes[-1] / part)
            for node in nodes:
                try:
                    info = node.lstat()
                except FileNotFoundError:
                    if node == self.root:
                        raise ValueError("missing private root") from None
                    continue
                # Junctions and other Windows reparse points need not be symlinks.
                if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
                    raise ValueError("redirected storage entry")
                expected_directory = node != path or directory
                if expected_directory and not stat.S_ISDIR(info.st_mode):
                    raise ValueError("expected directory")
                if not expected_directory and not stat.S_ISREG(info.st_mode):
                    raise ValueError("expected regular file")
        except CounselingError:
            raise
        except (OSError, ValueError, RuntimeError):
            raise CounselingError("unsafe_storage_path", "상담 저장 경로에 연결 폴더나 파일이 있거나 경로를 확인할 수 없습니다. 개인 로컬 저장 폴더를 확인해 주세요.") from None
        return path

    def _check_database_paths(self) -> None:
        # These are SQLite's companions for the single database (no ATTACH).
        for suffix in ("", "-wal", "-shm", "-journal"):
            self._checked_path(self.db_path.with_name(self.db_path.name + suffix))

    @contextmanager
    def connect(self):
        self._check_database_paths()
        db = sqlite3.connect(self.db_path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
                self._check_database_paths()
        finally:
            db.close()

    def list(self, owner: str) -> list:
        with self.connect() as db:
            return [normalize_case(json.loads(row["body"])) for row in db.execute("SELECT body FROM cases WHERE owner=? ORDER BY rowid DESC", (owner,))]

    def get(self, case_id: str, owner: str) -> dict:
        with self.connect() as db:
            row = db.execute("SELECT body FROM cases WHERE id=? AND owner=?", (case_id, owner)).fetchone()
            if not row:
                raise CounselingError("case_not_found", "상담 기록을 찾을 수 없습니다.", 404)
            return normalize_case(json.loads(row["body"]))

    def create(self, case: dict, owner: str) -> dict:
        case = normalize_case(case)
        with self.connect() as db:
            db.execute("INSERT INTO cases VALUES (?, ?, ?, ?)", (case["id"], owner, case["revision"], json.dumps(case, ensure_ascii=False)))
            db.execute("INSERT INTO case_versions VALUES(?,?,?,?,?)", (case["id"], owner, case["revision"], json.dumps(case, ensure_ascii=False), now()))
            db.execute("INSERT INTO audit(at,owner,case_id,event) VALUES(?,?,?,?)", (now(), owner, case["id"], "created"))
        return case

    def save(self, case: dict, owner: str, expected: int, event="saved") -> dict:
        case = normalize_case(case)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT revision FROM cases WHERE id=? AND owner=?", (case["id"], owner)).fetchone()
            if not row:
                raise CounselingError("case_not_found", "상담 기록을 찾을 수 없습니다.", 404)
            require_revision({"revision": row["revision"]}, expected)
            case["revision"] = expected + 1
            case["updated_at"] = now()
            db.execute("UPDATE cases SET revision=?, body=? WHERE id=? AND owner=?", (case["revision"], json.dumps(case, ensure_ascii=False), case["id"], owner))
            db.execute("INSERT INTO case_versions VALUES(?,?,?,?,?)", (case["id"], owner, case["revision"], json.dumps(case, ensure_ascii=False), now()))
            db.execute("INSERT INTO audit(at,owner,case_id,event) VALUES(?,?,?,?)", (now(), owner, case["id"], event))
        return case

    def history(self, case_id: str, owner: str):
        self.get(case_id, owner)
        with self.connect() as db:
            return [dict(row) for row in db.execute("SELECT revision, at FROM case_versions WHERE case_id=? AND owner=? ORDER BY revision DESC", (case_id, owner))]

    def save_document(self, file_id: str, content: bytes):
        # The server, never the request, supplies a SHA256 identifier.
        if len(file_id) != 64 or any(char not in "0123456789abcdef" for char in file_id):
            raise CounselingError("invalid_document", "문서 식별자를 확인할 수 없습니다.")
        destination = self._checked_path(self.files / (file_id + ".pdf"))
        if not destination.exists():
            with destination.open("xb") as stream:
                stream.write(content)
        return destination

    def document(self, file_id: str) -> bytes:
        if len(file_id) != 64 or any(char not in "0123456789abcdef" for char in file_id):
            raise CounselingError("invalid_document", "문서 식별자를 확인할 수 없습니다.")
        path = self._checked_path(self.files / (file_id + ".pdf"))
        if not path.exists():
            raise CounselingError("document_missing", "이 PC에 원본 PDF가 없습니다. 학생부 PDF를 다시 불러와 주세요.", 404)
        return path.read_bytes()
