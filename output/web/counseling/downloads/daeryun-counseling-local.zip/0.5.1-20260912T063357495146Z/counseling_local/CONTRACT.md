# 1차 구현 계약

코디네이터: 로컬 Python 서버·저장·Ollama·PDF 보고서·실행기. 프론트: `apps/counseling/`. 학생부 파서: `counseling_local/records.py`. 대륜고 연결: `integrations/daeryun/` 격리 체크아웃. 실제 학생 데이터는 이 소스 폴더에 저장하지 않는다.

로컬 서버는 `127.0.0.1:8765`에서 Vue 빌드(`/counseling/`)와 `/api/*`를 제공한다. JSON 성공 응답은 아래 구조, 오류는 `{error:{code,message}}`. 모든 변경 요청에 `/api/health`가 반환한 `csrf_token`을 `X-Counseling-Token`으로 보낸다. 데이터에는 `privacy: "local_only"`를 고정한다. 웹 배포 일반 상담은 별도 cloud transport를 사용한다.

## Case

```json
{
 "schema_version":1,"id":"uuid","revision":1,"privacy":"local_only",
 "created_at":"ISO","updated_at":"ISO","origin":"teacher",
 "student":{"student_id":"uuid","student_number":"10101","academic_year":2026,"school_stage":"high","grade":1,"name":""},
 "teacher":{"display_name":""},"current_session_id":"uuid",
 "sessions":[{"id":"uuid","date":"2026-09-11","topic":"","student_question":"","context":"","evidence_notes":"","teacher_opinion":"","actions":[{"id":"uuid","text":"","due_date":"","status":"planned"}],"next_date":"","record":null,"analysis":null,"review":null,"confirmed":null}]
}
```

세션의 record와 analysis는 API가 저장한다. 리뷰·확정은 임의 PUT으로 통과시킬 수 없다. PUT은 읽었던 revision을 포함하며 충돌 시 409. 수정된 세션의 review/confirmed를 무효화한다. 기존 확정 세션은 다음 회차로 이어서 쓰고 원본을 보존한다.

## Local API

- GET `/api/health` → `{version,mode:"local",demo:boolean,csrf_token,teacher:null|{id,display_name,approved:true},storage_path,ollama:{available,models:[{name,vision}],message}}`. models는 로컬 모델만.
- POST `/api/auth` `{access_token}` → 승인 교사를 고정 대륜고 endpoint에서 확인 후 로컬 메모리 세션 시작. 분석 본문은 전송하지 않음. 실제 endpoint 배포 전에는 demo로 검증.
- GET `/api/cases` → `{cases:[Case]}`.
- POST `/api/cases` `{student,teacher}` → `{case:Case}`. 최초 세션 생성.
- GET `/api/cases/{id}` → `{case:Case}`.
- PUT `/api/cases/{id}` `{case:Case}` → `{case:Case}`. ID·privacy·원본 보관 제약 검사.
- POST `/api/cases/{id}/sessions` `{revision}` → `{case:Case}`. 이전 상담 참고한 새 회차 생성.
- POST `/api/cases/{id}/record` `{revision,session_id,filename,pdf_base64,password?}` → `{case:Case}`. PDF 20MB/80페이지 제한, 원본은 로컬 개인 저장소. demo 모드는 제공한 합성 PDF 해시만 허용.
- POST `/api/cases/{id}/analyze` `{revision,session_id,model,goal,time_budget_minutes}` → `{job:{id,state}}`.
- POST `/api/cases/{id}/review` `{revision,session_id,model?}` → `{job:{id,state}}`. model이 있으면 Ollama 문체 검토, 없으면 자동 점검+교사 수동 검토용 결과. 수동 확인은 아래 별도 경로.
- POST `/api/cases/{id}/confirm` `{revision,session_id,review_acknowledged:true}` → `{case:Case}`. 근거·문체 검토 내용을 교사가 확인. 필수 내용/이력 검사.
- GET `/api/jobs/{id}` → `{job:{id,state:"queued"|"running"|"succeeded"|"needs_revision"|"failed"|"cancelled",stage,message,case_id}}`.
- POST `/api/jobs/{id}/cancel` `{}` → `{job}`.
- GET `/api/cases/{id}/export` → JSON 첨부. `{format:"daeryun-counseling",version:1,case:Case}`.
- POST `/api/import` `{bundle}` → `{case:Case}`. 새 ID/사본, 이전 확인 표시는 참고 이력으로만 보존. 상담 학생 식별을 UI에서 확인한 뒤 가져오기.
- GET `/api/cases/{id}/report.pdf?session_id=...` → 로컬 생성 PDF. 미확정은 초안 표시.
- GET `/api/cases/{id}/report.pdf?session_id=...&audience=student` → 현재 내용의 교사 확정 후 학생 안내 PDF. 미확정·해시 불일치·전략 내용이 모두 빈 경우는 409. `audience=teacher` 또는 생략은 원문 분석·전략을 포함한 교사용 보고서이며 초안 출력 가능. 학생용에는 전략 9개 항목, 실행 과제, 전략 제목·작성일·다음 점검일, 학년도·학번, 학생·담당 교사 표시 이름만 포함하고 학생부 원문·AI 분석 상세·교사 내부 메모는 제외한다. 교사가 직접 전달하며 온라인 게시하지 않는다. 문서의 공통 명칭은 대륜고 학종 전략실이며 합성자료 시연의 확정은 실제 교사 검토와 구분한다.
- GET `/api/fixtures` → `{fixtures:[{id,title,description}]}`; GET `/api/fixtures/{id}.pdf` 합성 PDF 다운로드.

## Record/Analysis

records.py는 `extract_record(pdf_bytes: bytes, filename: str, password: str|None=None) -> dict`를 제공한다. 출력은 `{id,filename,sha256,page_count,school_stage,sections:[{id,category,label,school_stage,academic_year,grade,semester,pages:[1],text,status}],warnings:[str],readable_pages:[int],unreadable_pages:[int]}`. status는 `present|empty|not_applicable|uncertain`. 범위에 없는 항목은 임의 empty로 추가하지 않는다. PDF의 식별 머리말은 분석에 불필요하면 제외하며 원문 페이지와 수치는 보존한다.

analysis는 `{summary,strengths:[{text,evidence_ids:[section-id],guidance}],improvements:[{text,evidence_ids:[section-id],guidance}],questions:[str],actions:[{text,reason,evidence_ids:[section-id]}],limitations:[str],model,created_at}`. Ollama 결과에서 실재하고 present인 section ID만 인용한다. 분석 텍스트는 사실 확인을 위한 초안이다. 누락/빈칸만으로 약점 판단 금지.

review는 `{state:"passed"|"needs_revision"|"pending",method:"manual"|"ollama",content_hash,notes:[str],created_at}`. content hash와 교사의 확인 기록은 로컬 서버 또는 인증된 cloud API만 생성한다. 프론트가 통과를 만들어 보내지 않는다.

## 로컬 0.3.0 전략

각 Session에 `strategy:{target_major,target_path,strengths,gaps,subject_plan,inquiry_plan,activity_plan,semester_plan,student_message}`를 추가한다. 모든 값은 문자열이며 필드당 12,000자 이내다. 기존 기록의 누락 필드는 빈 문자열로 읽고, 빈 기본값 때문에 기존 확정 해시가 달라지지 않도록 유지한다. 전략 변경은 현재 회차의 검토를 무효화하며 확정 회차는 직접 변경할 수 없다. 최종 수동·Ollama 문체 검토 입력에 전략 전체와 실행 과제를 포함한다. `student_message`가 있으면 교사 의견 입력 요건을 충족한다.

학생부 분석 입력에도 전략 9개 항목 전체를 포함하며 원문·공통 기준·질문과 함께 동적 입력 예산을 계산한다. 범위를 넘으면 명료한 오류로 중단하며 전략이나 원문을 누락해 분석하지 않는다. 새로운 입시 사실이나 평가 기준은 이 변경에서 추가하지 않는다.

`guidance:null`은 보호 필드다. 로컬에서 온라인 게시 상태를 만들거나 가져온 백업의 게시 상태를 승계하지 않는다. 학생부·분석·파생 전략은 계속 `privacy:"local_only"`이며 Ollama와 로컬 저장·PDF 생성만 사용한다. 다음 회차는 마지막 회차의 전략과 완료되지 않은 과제를 새 과제 ID로 이어받고, 원문·분석·검토·확정·게시 상태는 승계하지 않는다.

## 로컬 0.4.0 학생 기본자료

각 회차의 `profile`에는 `target_major,interests,learning_concerns,study_habits,activities,reading,attendance_notes,teacher_observations` 문자열(각 6,000자), `selected_subjects` 목록(중복 없이 최대20개·각100자), `weekly_minutes`(미입력 null 또는 0~2,400 정수), `grades`(최대60개)를 저장한다. 성적 행은 `id,subject,academic_year,semester,grade_scale,rank_grade,score,achievement`를 사용한다. 5등급·9등급·성취도·미확인 체계를 구분하고 석차등급은 해당 척도 범위, 원점수는 0~100으로 검증한다. 서로 다른 등급 체계는 변환하지 않는다.

빈 기본자료는 이전 확정 해시를 바꾸지 않으며, 내용이 바뀌면 새 최종 검토가 필요하다. 다음 전략에는 자료를 이어받고 확정된 이전 회차는 보존한다. 가져오기에서도 형식과 값 범위를 검증한다. profile은 교사 참고자료이므로 학생 안내 PDF에 포함하지 않으며 교사용 PDF에만 입력 요약·성적표를 표시한다. Ollama 원문 분석·문체 검토에 기본자료를 포함하되 입력 예산을 넘으면 중단하며 자료를 누락하지 않는다. 학생부 원문과 교사가 입력한 맥락을 구분한다.

## 0.5.0 교사 전략 준비 → 학생 상담 → 최종 결과

새 회차에는 `workflow_version:2`, `preparation:null`, `consultation:{status:"not_started",date:"",student_response:"",agreed_direction:"",adjustments:"",summary:""}`를 저장한다. 이전 회차는 버전을 강제로 부여하지 않고 기존 확정 해시를 보존한다.

POST `/api/cases/{id}/prepare` `{revision,session_id}`는 승인된 교사가 현재 전략을 상담 전 사본으로 보관하는 기능이다. 제목과 교과·탐구·활동·학기 계획 중 하나 이상이 필요하다. 서버가 `preparation:{prepared_at,prepared_by,topic,strategy,actions}`를 만들고 `consultation.status`를 `in_progress`로 바꾼다. 시간·작성자는 서버가 기록하며 사전 전략과 버전은 임의 PUT으로 수정할 수 없다. 이미 준비한 사본을 덮어쓰지 않는다.

교사는 이후 실제 상담의 학생 반응·합의한 방향·수정 사항·요약을 PUT으로 작성하고 현재 전략을 조정한다. 상담 서술은 항목당 6,000자, 날짜는 유효한 `YYYY-MM-DD`다. 준비 전 상담 내용 입력은 금지하며 준비 후 `not_started`로 되돌릴 수 없다. `completed`에는 상담일·학생 반응·합의한 방향이 필요하다. 상담 반영이 완료된 회차만 문체 검토 후 최종 확정·학생 안내 PDF를 만들 수 있다. 상담 기록 변경도 기존 문체 검토를 무효화한다.

사전 전략 사본과 상담 내용은 교사용 보고서에 포함한다. 학생 PDF와 온라인 학생 조회에서는 `profile,preparation,consultation,workflow_version`의 키와 값을 모두 제외한다. 학생에게는 명시적으로 안내한 최종 전략만 제공한다. 사전 전략 준비서는 상담 전에도 교사가 출력할 수 있다.

가져온 사전 전략은 작성자·시각을 검증하지 않은 참고본으로 표시한다. 기존 확정·게시·검토는 승계하지 않고 상담을 `in_progress`로 돌려 교사가 다시 확인한다. 다음 회차는 현재 전략·기본자료·미완료 과제를 이어받되 새로운 사전 전략과 상담으로 시작한다. 로컬 학생부·분석·파생 전략은 계속 Ollama와 로컬 저장만 사용한다.

## Cloud adapter 연결

`/.netlify/functions/counseling-session` GET Bearer → `{user:{id,role:"teacher"|"student",approved:boolean,display_name,student_id?},ai:{server:boolean}}`.
`/.netlify/functions/counseling-cases` GET 목록, GET `?id=`, POST 생성, PUT 수정, POST `?action=next|confirm|import` 등은 로컬 Case 형식과 대응. 실제 cloud 계약은 integration 담당자가 API.md로 명시하고 프론트에 전달.
`/.netlify/functions/counseling-ai` POST 표준 상담용만. 학생부/프리미엄 입력 불허. Supabase 승인 역할을 검증한 뒤 기존 Vertex/Gemini 서버 모듈을 재사용. Firebase 토큰을 위조하거나 공개 generate-open에 우회하지 않음.

Cloud에서는 private student PDF 분석 UI를 제공하지 않고 로컬 실행 안내로 연결한다. Local 브라우저는 local assets만 사용하고 학생부 데이터를 외부로 보내는 AI transport를 포함하지 않는다.
