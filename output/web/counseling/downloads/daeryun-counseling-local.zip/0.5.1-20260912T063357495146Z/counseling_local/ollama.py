"""A dedicated, cloud-disabled Ollama process; no provider fallback exists here."""
from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import threading
import time
from pathlib import Path

import httpx

from .domain import CounselingError

CONTEXT_TOKENS = 32768
TEMPLATE_RESERVE = 4096


def prompt_size(system, prompt, schema=None, images=None):
    # UTF-8 bytes deliberately overestimate the text tokens of supported local
    # models. Reserve room for the model's template and image embeddings too.
    return (len(system.encode("utf-8")) + len(prompt.encode("utf-8"))
            + (len(json.dumps(schema, ensure_ascii=False).encode("utf-8")) if schema else 0)
            + 4096 * len(images or []))


def check_prompt_budget(system, prompt, schema=None, images=None, max_tokens=2600, template=""):
    reserve = max(TEMPLATE_RESERVE, len(template.encode("utf-8")) + 512)
    if prompt_size(system, prompt, schema, images) + reserve + max_tokens > CONTEXT_TOKENS:
        raise CounselingError("input_too_large", "상담 배경이나 질문이 모델의 입력 범위를 넘었습니다. 내용을 나누거나 줄여 주세요. 원문을 임의로 잘라 분석하지 않았습니다.")


class Cancelled(Exception):
    pass


def check_cancel(stop):
    if stop is not None and stop.is_set():
        raise Cancelled()


class Ollama:
    def __init__(self, models_dir=None):
        self.process = None
        self.url = None
        self._lock = threading.Lock()
        self._discovery_cache = None
        self._discovery_at = 0
        self.models_dir = models_dir or os.environ.get("OLLAMA_MODELS")
        if not self.models_dir:
            # Both locations are used by the installed desktop apps. Select
            # only an existing Ollama manifest store; never download a model.
            for candidate in (Path.home() / ".ollama/models", Path.home() / ".lmstudio/models"):
                manifests = candidate / "manifests"
                if manifests.is_dir() and any(p.is_file() for p in manifests.rglob("*")):
                    self.models_dir = str(candidate)
                    break

    @staticmethod
    def _request(base, path, body=None, timeout=4):
        if not base.startswith("http://127.0.0.1:") or "/" in base.split(":")[-1] or not base.split(":")[-1].isdigit():
            raise CounselingError("local_only", "이 기능은 교사 PC의 Ollama만 사용할 수 있습니다.")
        with httpx.Client(trust_env=False, follow_redirects=False, timeout=timeout) as client:
            response = client.get(base + path) if body is None else client.post(base + path, json=body)
            if response.status_code != 200:
                raise CounselingError("ollama_response", "Ollama 응답을 확인할 수 없습니다. 실행 상태와 설치 모델을 확인해 주세요.", 503)
            return response.json()

    @staticmethod
    def _local_models(response):
        models = []
        for model in response.get("models", []):
            name = model.get("name", "")
            if not isinstance(name, str) or not name or len(name) > 160:
                continue
            if "cloud" in name.lower() or model.get("remote_host") or model.get("remote_model") or not model.get("size"):
                continue
            models.append({"name": name, "vision": False})
        return models

    def status(self):
        if self._discovery_cache is not None and time.monotonic() - self._discovery_at < 10:
            return self._discovery_cache
        try:
            base = self.url if self.process and self.process.poll() is None else "http://127.0.0.1:11434"
            models = self._local_models(self._request(base, "/api/tags"))
            for model in models:
                info = self._request(base, "/api/show", {"model": model["name"]})
                model["vision"] = "vision" in info.get("capabilities", [])
            result = {"available": bool(models) and bool(shutil.which("ollama")), "models": models,
                      "message": "분석에는 클라우드를 끈 별도 로컬 실행기를 사용합니다." if models else "Ollama에 로컬 모델을 설치해 주세요."}
        except (httpx.HTTPError, ValueError, KeyError, CounselingError):
            result = {"available": False, "models": [], "message": "Ollama를 실행한 뒤 연결을 다시 확인해 주세요."}
        self._discovery_cache, self._discovery_at = result, time.monotonic()
        return result

    def _ensure_service(self, stop=None):
        with self._lock:
            check_cancel(stop)
            if self.process and self.process.poll() is None:
                return
            executable = shutil.which("ollama")
            if not executable:
                raise CounselingError("ollama_missing", "Ollama 설치를 확인해 주세요.", 503)
            with socket.socket() as address:
                address.bind(("127.0.0.1", 0))
                port = address.getsockname()[1]
            self.url = f"http://127.0.0.1:{port}"
            environment = os.environ.copy()
            environment.update({"OLLAMA_NO_CLOUD": "1", "OLLAMA_NOPRUNE": "1", "OLLAMA_HOST": f"127.0.0.1:{port}", "OLLAMA_KEEP_ALIVE": "2m",
                                "OLLAMA_NUM_PARALLEL": "1", "OLLAMA_CONTEXT_LENGTH": str(CONTEXT_TOKENS), "OLLAMA_DEBUG": "0"})
            environment.pop("OLLAMA_ORIGINS", None)
            if self.models_dir:
                environment["OLLAMA_MODELS"] = str(Path(self.models_dir).expanduser().resolve())
            self.process = subprocess.Popen([executable, "serve"], env=environment, stdin=subprocess.DEVNULL,
                                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            for _ in range(60):
                check_cancel(stop)
                if self.process.poll() is not None:
                    raise CounselingError("ollama_start_failed", "로컬 Ollama 실행기를 시작하지 못했습니다. 메모리와 실행 상태를 확인해 주세요.", 503)
                try:
                    self._request(self.url, "/api/version", timeout=1)
                    return
                except (httpx.HTTPError, ValueError, CounselingError):
                    time.sleep(0.2)
            raise CounselingError("ollama_timeout", "Ollama 실행 준비가 지연되고 있습니다. 잠시 뒤 다시 시도해 주세요.", 503)

    def model_info(self, model, stop=None):
        self._ensure_service(stop)
        allowed = {item["name"] for item in self._local_models(self._request(self.url, "/api/tags"))}
        if model not in allowed:
            raise CounselingError("model_not_local", "이 PC에 설치된 로컬 모델을 선택해 주세요. 클라우드 모델은 사용할 수 없습니다.")
        info = self._request(self.url, "/api/show", {"model": model})
        if info.get("remote_host") or info.get("remote_model"):
            raise CounselingError("model_not_local", "원격 모델은 학생부 분석에 사용할 수 없습니다.")
        return info

    def generate(self, model: str, system: str, prompt: str, schema=None, images=None, stop=None, on_transport=None, max_tokens=2600):
        check_prompt_budget(system, prompt, schema, images, max_tokens)
        info = self.model_info(model, stop)
        check_prompt_budget(system, prompt, schema, images, max_tokens,
                            str(info.get("template", "")) + str(info.get("system", "")))
        if images and "vision" not in info.get("capabilities", []):
            raise CounselingError("vision_required", "스캔 PDF를 읽으려면 이미지 판독을 지원하는 로컬 모델이 필요합니다.")
        check_cancel(stop)
        message = {"role": "user", "content": prompt}
        if images:
            message["images"] = images
        payload = {"model": model, "messages": [{"role": "system", "content": system}, message], "stream": True,
                   "options": {"temperature": 0.1, "num_ctx": CONTEXT_TOKENS, "num_predict": max_tokens}}
        if "thinking" in info.get("capabilities", []):
            payload["think"] = False
        if schema is not None:
            payload["format"] = schema
        client = httpx.Client(trust_env=False, follow_redirects=False, timeout=httpx.Timeout(240, connect=8))
        output, done = [], False
        try:
            if on_transport:
                on_transport(client.close)
            check_cancel(stop)
            with client.stream("POST", self.url + "/api/chat", json=payload) as response:
                if response.status_code != 200:
                    raise CounselingError("ollama_generation", "로컬 모델이 분석을 완료하지 못했습니다. 모델 설정과 사용 가능한 메모리를 확인해 주세요.", 503)
                for line in response.iter_lines():
                    check_cancel(stop)
                    if not line:
                        continue
                    item = json.loads(line)
                    if item.get("error"):
                        raise CounselingError("ollama_generation", "로컬 모델의 응답에 오류가 있습니다. 다른 로컬 모델로 다시 시도해 주세요.", 503)
                    output.append(item.get("message", {}).get("content", ""))
                    if sum(len(part) for part in output) > 180_000:
                        raise CounselingError("response_too_large", "모델 응답이 너무 깁니다. 상담 범위를 나누어 다시 실행해 주세요.")
                    if item.get("done"):
                        if item.get("done_reason") == "length":
                            raise CounselingError("response_truncated", "모델 응답이 길이 제한으로 끝났습니다. 다른 로컬 모델이나 짧은 분석 범위로 다시 시도해 주세요.")
                        done = True
            check_cancel(stop)
            if not done:
                raise CounselingError("response_incomplete", "모델 응답이 끝나기 전에 연결이 종료되었습니다. 결과는 확정하지 않았습니다.")
            return "".join(output)
        except (httpx.HTTPError, OSError) as exc:
            check_cancel(stop)
            raise CounselingError("ollama_connection", "Ollama 연결이 끊어졌습니다. 로컬 실행 상태를 확인한 뒤 다시 시도해 주세요.", 503) from exc
        finally:
            if on_transport:
                on_transport(None)
            client.close()

    def close(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
