"""Versioned counseling records. Client data never grants review or approval."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import uuid
from datetime import date, datetime, timezone


class CounselingError(ValueError):
    def __init__(self, code: str, message: str, status: int = 400):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def text(value, limit=12000) -> str:
    if not isinstance(value, str) or len(value) > limit or "\x00" in value:
        raise CounselingError("invalid_text", "입력 내용을 확인해 주세요. 허용된 글자 수를 넘었거나 읽을 수 없는 문자가 있습니다.")
    return value.strip()


def object_value(value) -> dict:
    if not isinstance(value, dict):
        raise CounselingError("invalid_object", "상담 자료의 형식을 확인해 주세요.")
    return value


def day(value: str, optional=True) -> str:
    value = text(value, 10)
    if optional and not value:
        return ""
    try:
        date.fromisoformat(value)
    except ValueError as exc:
        raise CounselingError("invalid_date", "날짜를 연-월-일 형식으로 입력해 주세요.") from exc
    return value


def student_value(value: dict, existing=None) -> dict:
    value = object_value(value)
    number = text(value.get("student_number", ""), 32)
    if number and not re.fullmatch(r"[\w-]+", number):
        raise CounselingError("invalid_student_number", "학번에는 문자, 숫자, 밑줄, 붙임표만 사용할 수 있습니다.")
    academic_year = value.get("academic_year", date.today().year)
    grade = value.get("grade", 1)
    stage = value.get("school_stage", "high")
    if type(academic_year) is not int or not 1990 <= academic_year <= 2100 or type(grade) is not int or grade not in (1, 2, 3) or stage not in ("middle", "high"):
        raise CounselingError("invalid_student", "학교급, 학년도, 학년을 확인해 주세요.")
    return {"student_id": existing["student_id"] if existing else new_id(), "student_number": number,
            "academic_year": academic_year, "school_stage": stage, "grade": grade, "name": text(value.get("name", ""), 80)}


def actions_value(value) -> list:
    if not isinstance(value, list) or len(value) > 30:
        raise CounselingError("invalid_actions", "실천 항목은 30개 이내로 작성해 주세요.")
    result, seen = [], set()
    for item in value:
        item = object_value(item)
        action_id = text(item.get("id", new_id()), 80)
        status = item.get("status", "planned")
        if action_id in seen or status not in ("planned", "in_progress", "done", "deferred"):
            raise CounselingError("invalid_actions", "실천 항목의 중복이나 상태를 확인해 주세요.")
        seen.add(action_id)
        result.append({"id": action_id, "text": text(item.get("text", ""), 2000), "due_date": day(item.get("due_date", "")), "status": status})
    return result


EDITABLE_TEXT = ("topic", "student_question", "context", "evidence_notes", "teacher_opinion")
STRATEGY_FIELDS = ("target_major", "target_path", "strengths", "gaps", "subject_plan", "inquiry_plan", "activity_plan", "semester_plan", "student_message")
PROFILE_FIELDS = ("target_major", "interests", "learning_concerns", "study_habits", "activities", "reading", "attendance_notes", "teacher_observations")
CONSULTATION_FIELDS = ("student_response", "agreed_direction", "adjustments", "summary")
PROTECTED = ("record", "analysis", "review", "confirmed", "guidance", "student_snapshot", "teacher_snapshot", "preparation", "workflow_version", "imported_history")


def strategy_value(value) -> dict:
    value = object_value(value)
    if set(value) - set(STRATEGY_FIELDS):
        raise CounselingError("invalid_strategy", "학습전략에 허용하지 않은 항목이 있습니다.")
    return {key: text(value.get(key, ""), 12000) for key in STRATEGY_FIELDS}


def profile_value(value) -> dict:
    value = object_value(value)
    if set(value) - set((*PROFILE_FIELDS, "selected_subjects", "weekly_minutes", "grades")):
        raise CounselingError("invalid_profile", "학생 기본자료에 허용하지 않은 항목이 있습니다.")
    result = {key: text(value.get(key, ""), 6000) for key in PROFILE_FIELDS}
    subjects = value.get("selected_subjects", [])
    if not isinstance(subjects, list) or len(subjects) > 20:
        raise CounselingError("invalid_profile", "실제 이수 과목은 20개 이내로 입력해 주세요.")
    result["selected_subjects"] = [text(subject, 100) for subject in subjects]
    if any(not subject for subject in result["selected_subjects"]) or len(set(result["selected_subjects"])) != len(result["selected_subjects"]):
        raise CounselingError("invalid_profile", "이수 과목의 빈 이름이나 중복을 확인해 주세요.")
    minutes = value.get("weekly_minutes")
    if minutes is not None and (type(minutes) is not int or not 0 <= minutes <= 2400):
        raise CounselingError("invalid_profile", "주간 가용 시간은 0~2,400분의 정수로 입력하거나 미입력으로 남겨 주세요.")
    result["weekly_minutes"] = minutes
    grades = value.get("grades", [])
    if not isinstance(grades, list) or len(grades) > 60:
        raise CounselingError("invalid_grades", "성적 자료는 60개 이내로 입력해 주세요.")
    result["grades"], seen = [], set()
    for row in grades:
        row = object_value(row)
        if set(row) - {"id", "subject", "academic_year", "semester", "grade_scale", "rank_grade", "score", "achievement"}:
            raise CounselingError("invalid_grades", "성적 자료에 허용하지 않은 항목이 있습니다.")
        row_id = text(row.get("id", ""), 80)
        if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", row_id, re.I) or row_id in seen:
            raise CounselingError("invalid_grades", "성적 항목의 식별자나 중복을 확인해 주세요.")
        seen.add(row_id)
        year, semester = row.get("academic_year"), row.get("semester")
        scale, rank, score = row.get("grade_scale", "unknown"), row.get("rank_grade"), row.get("score")
        subject = text(row.get("subject", ""), 100)
        if type(year) is not int or not 1990 <= year <= 2100 or type(semester) is not int or semester not in (1, 2):
            raise CounselingError("invalid_grades", "성적의 과목 이름·학년도·학기를 확인해 주세요.")
        if scale not in ("5", "9", "achievement", "unknown"):
            raise CounselingError("invalid_grades", "5등급·9등급·성취도·미확인 중 성적 체계를 선택해 주세요.")
        if rank is not None and (scale not in ("5", "9") or type(rank) is not int or not 1 <= rank <= int(scale)):
            raise CounselingError("invalid_grades", "석차등급은 선택한 5등급 또는 9등급 체계의 범위에서 입력해 주세요.")
        if score is not None and (type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 100):
            raise CounselingError("invalid_grades", "원점수는 0~100 사이로 입력하거나 미입력으로 남겨 주세요.")
        result["grades"].append({"id": row_id, "subject": subject, "academic_year": year, "semester": semester,
                                 "grade_scale": scale, "rank_grade": rank, "score": score,
                                 "achievement": text(row.get("achievement", ""), 20)})
    return result


def has_profile(profile: dict) -> bool:
    return any(profile[key] for key in PROFILE_FIELDS) or bool(profile["grades"] or profile["selected_subjects"]) or profile["weekly_minutes"] is not None


def consultation_value(value) -> dict:
    value = object_value(value)
    if set(value) - {"status", "date", *CONSULTATION_FIELDS}:
        raise CounselingError("invalid_consultation", "상담 반영 자료에 허용하지 않은 항목이 있습니다.")
    result = {key: text(value.get(key, ""), 6000) for key in CONSULTATION_FIELDS}
    result["date"] = day(value.get("date", ""))
    if result["date"] and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", result["date"]):
        raise CounselingError("invalid_consultation", "상담일은 연-월-일 형식으로 입력해 주세요.")
    result["status"] = value.get("status", "not_started")
    if result["status"] not in ("not_started", "in_progress", "completed"):
        raise CounselingError("invalid_consultation", "상담 진행 상태를 확인해 주세요.")
    if result["status"] == "completed" and not all(result[key] for key in ("date", "student_response", "agreed_direction")):
        raise CounselingError("consultation_incomplete", "상담일, 학생의 반응과 합의한 방향을 입력한 뒤 상담 반영을 완료해 주세요.", 409)
    return result


def has_consultation(value: dict) -> bool:
    return value["status"] != "not_started" or bool(value["date"]) or any(value[key] for key in CONSULTATION_FIELDS)


def preparation_value(value) -> dict | None:
    if value is None:
        return None
    value = object_value(value)
    if set(value) != {"prepared_at", "prepared_by", "topic", "strategy", "actions"}:
        raise CounselingError("invalid_preparation", "상담 전 교사 전략 자료의 형식을 확인해 주세요.")
    timestamp = text(value["prepared_at"], 100)
    try:
        parsed = datetime.fromisoformat(timestamp)
        if "T" not in timestamp or parsed.tzinfo is None:
            raise ValueError()
    except ValueError as exc:
        raise CounselingError("invalid_preparation", "교사 전략의 준비 시각을 확인해 주세요.") from exc
    result = {"prepared_at": timestamp, "prepared_by": text(value["prepared_by"], 160),
              "topic": text(value["topic"], 200), "strategy": strategy_value(value["strategy"]),
              "actions": actions_value(value["actions"])}
    if not result["prepared_by"] or not result["topic"] or not any(result["strategy"][key] for key in ("subject_plan", "inquiry_plan", "activity_plan", "semester_plan")):
        raise CounselingError("invalid_preparation", "상담 전 전략의 작성자·제목·구체적인 계획을 확인해 주세요.")
    return result


def validate_workflow(session: dict) -> None:
    if "workflow_version" in session and (type(session["workflow_version"]) is not int or session["workflow_version"] != 2):
        raise CounselingError("invalid_workflow", "지원하지 않는 전략 작성 절차입니다.")
    preparation = preparation_value(session.get("preparation"))
    consultation = consultation_value(session.get("consultation", {}))
    if preparation and session.get("workflow_version") != 2:
        raise CounselingError("invalid_workflow", "사전 전략과 작성 절차가 일치하지 않습니다.")
    if not preparation and has_consultation(consultation):
        raise CounselingError("preparation_required", "교사 전략을 먼저 수립하고 준비 완료를 누른 뒤 학생 상담을 기록해 주세요.", 409)
    if preparation and consultation["status"] == "not_started":
        raise CounselingError("invalid_workflow", "준비한 전략의 상담 진행 상태를 확인해 주세요.")


def require_consultation_complete(session: dict) -> None:
    if session.get("workflow_version") == 2:
        validate_workflow(session)
        if not session.get("preparation") or consultation_value(session.get("consultation", {}))["status"] != "completed":
            raise CounselingError("consultation_required", "교사 전략 준비와 학생 상담 반영을 완료한 뒤 최종 결과물을 확정해 주세요.", 409)


def prepare_session(case: dict, session_id: str, teacher_id: str) -> dict:
    case = normalize_case(case)
    session = session_of(case, session_id)
    if session.get("confirmed") or session.get("preparation"):
        raise CounselingError("preparation_exists", "준비한 전략은 보존됩니다. 상담 결과는 현재 전략에 반영하고 새 준비는 다음 회차에서 진행해 주세요.", 409)
    if not session["topic"] or not any(session["strategy"][key] for key in ("subject_plan", "inquiry_plan", "activity_plan", "semester_plan")):
        raise CounselingError("missing_strategy", "전략 제목과 교과·탐구·활동·학기 계획 중 하나 이상을 작성해 주세요.")
    session["preparation"] = preparation_value({"prepared_at": now(), "prepared_by": teacher_id,
                                                "topic": session["topic"], "strategy": copy.deepcopy(session["strategy"]),
                                                "actions": copy.deepcopy(session["actions"])})
    session["workflow_version"] = 2
    session["consultation"] = consultation_value({"status": "in_progress"})
    session["review"] = None
    return case


def normalize_case(case: dict) -> dict:
    """Project legacy local cases with defaults without rewriting stored history."""
    result = copy.deepcopy(case)
    for session in result["sessions"]:
        session["strategy"] = strategy_value(session.get("strategy", {}))
        session["profile"] = profile_value(session.get("profile", {}))
        session["preparation"] = preparation_value(session.get("preparation"))
        session["consultation"] = consultation_value(session.get("consultation", {}))
        validate_workflow(session)
        if session.get("guidance") is not None:
            raise CounselingError("local_guidance", "로컬 상담 자료는 온라인으로 게시하지 않습니다.")
        session["guidance"] = None
    return result


def new_session() -> dict:
    return {"id": new_id(), "date": date.today().isoformat(), **{key: "" for key in EDITABLE_TEXT},
            "strategy": strategy_value({}), "profile": profile_value({}), "guidance": None,
            "workflow_version": 2, "preparation": None, "consultation": consultation_value({}),
            "actions": [], "next_date": "", "record": None, "analysis": None, "review": None, "confirmed": None}


def new_case(student: dict, teacher: dict, origin="teacher") -> dict:
    session = new_session()
    timestamp = now()
    return {"schema_version": 1, "id": new_id(), "revision": 1, "privacy": "local_only", "created_at": timestamp,
            "updated_at": timestamp, "origin": origin, "student": student_value(student),
            "teacher": {"display_name": text(object_value(teacher).get("display_name", ""), 80)},
            "sessions": [session], "current_session_id": session["id"]}


def session_of(case: dict, session_id: str) -> dict:
    for item in case["sessions"]:
        if item["id"] == session_id:
            return item
    raise CounselingError("session_not_found", "상담 회차를 찾을 수 없습니다.", 404)


def content_hash(case: dict, session: dict) -> str:
    content = {key: value for key, value in session.items() if key not in
               ("strategy", "profile", "preparation", "consultation", "guidance", "review", "confirmed", "student_snapshot", "teacher_snapshot", "imported_review", "imported_confirmation", "imported_history")}
    strategy = strategy_value(session.get("strategy", {}))
    # Empty defaults keep pre-0.3 confirmation hashes valid. Nonempty strategies
    # participate in review/confirmation exactly like the other authored fields.
    if any(strategy.values()):
        content["strategy"] = strategy
    profile = profile_value(session.get("profile", {}))
    if has_profile(profile):
        content["profile"] = profile
    if session.get("preparation") is not None:
        content["preparation"] = preparation_value(session["preparation"])
    consultation = consultation_value(session.get("consultation", {}))
    if has_consultation(consultation):
        content["consultation"] = consultation
    return digest({"student": case["student"], "teacher": case["teacher"],
                   "session": content})


def require_revision(case: dict, revision) -> None:
    if type(revision) is not int or case["revision"] != revision:
        raise CounselingError("revision_conflict", "다른 창이나 작업에서 상담이 바뀌었습니다. 현재 입력을 백업하고 최신 기록을 다시 열어 주세요.", 409)


def edit_case(old: dict, incoming: dict) -> dict:
    incoming = object_value(incoming)
    require_revision(old, incoming.get("revision"))
    if incoming.get("id") != old["id"] or incoming.get("privacy") != "local_only":
        raise CounselingError("protected_field", "이 상담의 식별자와 로컬 보관 조건은 변경할 수 없습니다.")
    old = normalize_case(old)
    proposed = copy.deepcopy(old)
    proposed["student"] = student_value(incoming.get("student", {}), old["student"])
    proposed["teacher"] = {"display_name": text(object_value(incoming.get("teacher", {})).get("display_name", ""), 80)}
    identity_changed = proposed["student"] != old["student"] or proposed["teacher"] != old["teacher"]
    if identity_changed and any(s.get("confirmed") for s in old["sessions"]):
        raise CounselingError("confirmed_identity", "확정한 상담의 학생·교사 정보는 바꿀 수 없습니다. 정정이 필요하면 새 사본으로 보관해 주세요.")
    sessions = incoming.get("sessions")
    if not isinstance(sessions, list) or len(sessions) != len(old["sessions"]) or [s.get("id") for s in sessions if isinstance(s, dict)] != [s["id"] for s in old["sessions"]]:
        raise CounselingError("protected_sessions", "상담 회차는 새 상담 기능으로 추가해 주세요. 이전 회차를 삭제하거나 바꿀 수 없습니다.")
    for original, submitted, updated in zip(old["sessions"], sessions, proposed["sessions"]):
        for key in PROTECTED:
            if submitted.get(key) != original.get(key):
                raise CounselingError("protected_field", "분석·검토·확정 기록은 지정된 기능을 통해 변경해 주세요.")
        for key in EDITABLE_TEXT:
            updated[key] = text(submitted.get(key, ""), 200 if key == "topic" else 12000)
        updated["date"] = day(submitted.get("date", ""), optional=False)
        updated["next_date"] = day(submitted.get("next_date", ""))
        updated["actions"] = actions_value(submitted.get("actions", []))
        updated["strategy"] = strategy_value(submitted.get("strategy", original["strategy"]))
        updated["profile"] = profile_value(submitted.get("profile", original["profile"]))
        updated["consultation"] = consultation_value(submitted.get("consultation", original["consultation"]))
        validate_workflow(updated)
        changed = any(updated.get(key) != original.get(key) for key in (*EDITABLE_TEXT, "date", "next_date", "actions", "strategy", "profile", "consultation")) or identity_changed
        if changed and original.get("confirmed"):
            raise CounselingError("confirmed_session", "확정한 회차는 보존됩니다. 후속 상담을 추가해 수정 내용을 남겨 주세요.", 409)
        if changed:
            updated["review"] = updated["confirmed"] = None
    current = incoming.get("current_session_id", old["current_session_id"])
    session_of(proposed, current)
    proposed["current_session_id"] = current
    return proposed


def append_session(case: dict) -> dict:
    case = normalize_case(case)
    if len(case["sessions"]) >= 100:
        raise CounselingError("session_limit", "이 상담 묶음은 100회까지 보관할 수 있습니다. 새 상담 묶음을 만들어 주세요.")
    previous = case["sessions"][-1]
    session = new_session()
    session["topic"] = "후속 전략 점검"
    session["strategy"] = copy.deepcopy(previous["strategy"])
    session["profile"] = copy.deepcopy(previous["profile"])
    session["actions"] = [{**copy.deepcopy(action), "id": new_id()} for action in
                          actions_value(previous.get("actions", [])) if action["status"] != "done"]
    agreements = "\n".join(f"- {a['text']}" for a in session["actions"] if a["text"])
    session["context"] = f"이전 작성일: {previous['date']}\n이전 전략 제목: {previous['topic']}\n확인할 실행 과제:\n{agreements}".strip()
    case["sessions"].append(session)
    case["current_session_id"] = session["id"]
    return case


def manual_style_review(case: dict, session: dict) -> dict:
    notes = []
    prose = "\n".join([*(session.get(key, "") for key in EDITABLE_TEXT),
                        *strategy_value(session.get("strategy", {})).values(),
                        *(consultation_value(session.get("consultation", {}))[key] for key in CONSULTATION_FIELDS),
                        *(action.get("text", "") for action in session.get("actions", []))])
    for phrase in ("시사하는 바가 크", "혁명적", "무조건 합격", "합격을 보장", "다양한 역량"):
        if phrase in prose:
            notes.append(f"‘{phrase}’ 표현의 근거와 구체적인 행동을 확인해 주세요.")
    if any(len(sentence.strip()) > 160 for sentence in re.split(r"[.!?\n]", prose)):
        notes.append("긴 문장에 핵심이 여러 개 들어 있는지 확인하고 나누어 주세요.")
    notes.extend(["학생 원문·직접 인용·수치가 바뀌지 않았는지 확인해 주세요.", "확인한 사실, 교사의 해석, 앞으로의 계획을 구분해 읽어 주세요."])
    return {"state": "pending", "method": "manual", "content_hash": content_hash(case, session), "notes": notes, "created_at": now()}


def confirm_session(case: dict, session_id: str, teacher_id: str, acknowledged: bool) -> dict:
    case = normalize_case(case)
    session = session_of(case, session_id)
    if session.get("imported_unverified") and (session.get("record") is not None or session.get("analysis") is not None):
        raise CounselingError("imported_analysis_unverified", "가져온 학생부·분석은 원본 PDF를 다시 불러와 확인한 뒤 확정해 주세요. 이전 내용은 참고 기록으로 보존됩니다.", 409)
    if acknowledged is not True:
        raise CounselingError("review_required", "문체와 근거를 검토한 뒤 확인란을 선택해 주세요.")
    if not case["student"]["student_number"] or not case["teacher"]["display_name"] or not session["topic"]:
        raise CounselingError("missing_required", "학생 학번, 담당 교사, 전략 제목을 입력해 주세요.")
    if not session["teacher_opinion"] and not session.get("analysis") and not session["strategy"]["student_message"]:
        raise CounselingError("missing_opinion", "교사의 검토 의견 또는 전략의 학생 안내 문장을 작성해 주세요.")
    require_consultation_complete(session)
    review = session.get("review")
    if not review or review.get("content_hash") != content_hash(case, session):
        raise CounselingError("review_required", "현재 내용에 대한 최종 문체 검토를 먼저 진행해 주세요.")
    if review["state"] == "needs_revision":
        raise CounselingError("revision_required", "문체 검토에서 제안한 내용을 반영한 뒤 다시 검토해 주세요.")
    session["review"] = {**review, "state": "passed", "teacher_acknowledged": True}
    session["student_snapshot"], session["teacher_snapshot"] = copy.deepcopy(case["student"]), copy.deepcopy(case["teacher"])
    session["confirmed"] = {"by": teacher_id, "at": now(), "content_hash": content_hash(case, session)}
    return case


def imported_list(value, limit=2000) -> list:
    if not isinstance(value, list) or len(value) > limit:
        raise CounselingError("invalid_import", "가져온 자료의 목록 형식이나 항목 수를 확인해 주세요.")
    return value


def imported_record(value) -> dict | None:
    """Validate the portable structure, without treating its claimed PDF hash as proof."""
    if value is None:
        return None
    value = object_value(value)
    if len(json.dumps(value, ensure_ascii=False)) > 1_000_000:
        raise CounselingError("import_too_large", "상담 파일의 학생부 항목이 너무 큽니다.")
    page_count = value.get("page_count")
    if type(page_count) is not int or not 1 <= page_count <= 80 or not isinstance(value.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
        raise CounselingError("invalid_import_record", "가져온 학생부의 페이지 수와 파일 식별 정보를 확인해 주세요.")
    for key, limit in (("id", 100), ("filename", 200)):
        if not text(value.get(key, ""), limit):
            raise CounselingError("invalid_import_record", "가져온 학생부의 파일 정보를 확인해 주세요.")
    if value.get("school_stage") not in ("middle", "high", "unknown"):
        raise CounselingError("invalid_import_record", "가져온 학생부의 학교급을 확인해 주세요.")

    def pages(items, required=False):
        items = imported_list(items, page_count)
        if (required and not items) or any(type(p) is not int or not 1 <= p <= page_count for p in items) or len(set(items)) != len(items):
            raise CounselingError("invalid_import_record", "가져온 학생부의 페이지 연결을 확인해 주세요.")
        return items

    readable = pages(value.get("readable_pages"))
    unreadable = pages(value.get("unreadable_pages"))
    if set(readable) & set(unreadable) or set(readable) | set(unreadable) != set(range(1, page_count + 1)):
        raise CounselingError("invalid_import_record", "읽힌 페이지와 미판독 페이지의 구분을 확인해 주세요.")
    if "ocr_pages" in value:
        pages(value["ocr_pages"])
    for warning in imported_list(value.get("warnings")):
        text(warning, 2000)
    sections = imported_list(value.get("sections"))
    seen = set()
    for section in sections:
        section = object_value(section)
        sid = text(section.get("id", ""), 120)
        if not sid or sid in seen:
            raise CounselingError("invalid_import_record", "학생부 항목의 식별자가 없거나 중복되었습니다.")
        seen.add(sid)
        for key, limit in (("label", 200), ("category", 80), ("text", 1_000_000)):
            text(section.get(key), limit)
        if section.get("school_stage") not in ("middle", "high", "unknown") or section.get("status") not in ("present", "empty", "not_applicable", "uncertain"):
            raise CounselingError("invalid_import_record", "학생부 항목의 학교급과 판독 상태를 확인해 주세요.")
        for key, low, high in (("academic_year", 1900, 2100), ("grade", 1, 6), ("semester", 1, 2)):
            number = section.get(key)
            if number is not None and (type(number) is not int or not low <= number <= high):
                raise CounselingError("invalid_import_record", "학생부 항목의 학년도·학년·학기를 확인해 주세요.")
        pages(section.get("pages"), required=True)
    for entry in imported_list(value.get("evidence_index", []), 10000):
        entry = object_value(entry)
        if not isinstance(entry.get("section_id"), str) or entry["section_id"] not in seen:
            raise CounselingError("invalid_import_record", "학생부 근거 색인의 항목 연결을 확인해 주세요.")
        pages([entry.get("page")], required=True)
    return copy.deepcopy(value)


def imported_analysis(value, record: dict | None) -> dict | None:
    """Check shapes and internal citations; original source authenticity still needs re-upload."""
    if value is None:
        return None
    value = object_value(value)
    if record is None or len(json.dumps(value, ensure_ascii=False)) > 1_000_000:
        raise CounselingError("invalid_import_analysis", "가져온 분석의 학생부 근거와 자료 크기를 확인해 주세요.")
    # Imported batches may have been merged; preserve their larger lists instead of
    # applying per-model-response item limits. Share the exact source-quote check.
    from .analysis import source_quote
    value = copy.deepcopy(value)
    text(value.get("summary"), 1_000_000)
    for key in ("questions", "limitations"):
        for item in imported_list(value.get(key)):
            text(item, 12000)
    allowed = {s["id"]: s for s in record["sections"] if s["status"] == "present" and s["text"].strip()}
    for key in ("strengths", "improvements", "actions"):
        for item in imported_list(value.get(key)):
            item = object_value(item)
            text(item.get("text"), 12000)
            ids = imported_list(item.get("evidence_ids"))
            if (key != "actions" and not ids) or any(not isinstance(sid, str) or sid not in allowed for sid in ids):
                raise CounselingError("invalid_import_analysis", "가져온 분석의 근거가 읽힌 학생부 항목과 연결되지 않았습니다.")
            if key == "actions":
                text(item.get("reason", ""), 12000)
            else:
                text(item.get("guidance", ""), 12000)
                quote = text(item.get("quote", ""), 400)
                matched = source_quote(quote, [allowed[sid]["text"] for sid in ids])
                if matched is None:
                    raise CounselingError("invalid_import_analysis", "가져온 분석의 직접 인용이 학생부 항목과 일치하지 않습니다.")
                item["quote"] = matched
    for key, limit in (("model", 200), ("created_at", 100)):
        if key in value:
            text(value[key], limit)
    if "record_sha256" in value and value["record_sha256"] != record["sha256"]:
        raise CounselingError("invalid_import_analysis", "분석과 학생부 파일의 식별 정보가 다릅니다.")
    return copy.deepcopy(value)


def import_case(bundle: dict, teacher: dict, origin="teacher") -> dict:
    bundle = object_value(bundle)
    if bundle.get("format") != "daeryun-counseling" or bundle.get("version") != 1:
        raise CounselingError("unsupported_import", "대륜고 상담실에서 저장한 다음 상담용 파일을 선택해 주세요.")
    original = object_value(bundle.get("case"))
    if original.get("schema_version") != 1 or original.get("privacy") not in ("local_only", "standard"):
        raise CounselingError("unsupported_import", "지원하지 않는 상담 파일 버전입니다.")
    sessions = original.get("sessions")
    if not isinstance(sessions, list) or not 1 <= len(sessions) <= 100:
        raise CounselingError("invalid_import", "상담 회차 수를 확인해 주세요.")
    result = new_case(original.get("student", {}), teacher, origin)
    result["imported_from"] = {"case_id": text(original.get("id", ""), 80), "at": now()}
    result["sessions"] = []
    for source in sessions:
        source = object_value(source)
        item = new_session()
        for key in EDITABLE_TEXT:
            item[key] = text(source.get(key, ""), 200 if key == "topic" else 12000)
        item["date"] = day(source.get("date", ""), False)
        item["next_date"] = day(source.get("next_date", ""))
        item["actions"] = actions_value(source.get("actions", []))
        item["strategy"] = strategy_value(source.get("strategy", {}))
        item["profile"] = profile_value(source.get("profile", {}))
        if "workflow_version" not in source:
            item.pop("workflow_version", None)
        else:
            item["workflow_version"] = source["workflow_version"]
        item["preparation"] = preparation_value(source.get("preparation"))
        item["consultation"] = consultation_value(source.get("consultation", {}))
        validate_workflow(item)
        if item["preparation"]:
            item["consultation"]["status"] = "in_progress"
            item["imported_history"] = {"preparation_imported": True}
        # Published guidance from an online backup never becomes a local publication.
        item["guidance"] = None
        item["record"] = imported_record(source.get("record"))
        item["analysis"] = imported_analysis(source.get("analysis"), item["record"])
        item["imported_review"] = copy.deepcopy(source.get("review"))
        item["imported_confirmation"] = copy.deepcopy(source.get("confirmed"))
        item["imported_unverified"] = True
        # Imported assertions and source references must be checked before analysis/finalization.
        item["review"] = item["confirmed"] = None
        result["sessions"].append(item)
    result["current_session_id"] = result["sessions"][-1]["id"]
    return result
