"""Local PDF evidence extraction. No model, network, or filesystem writes.

The result preserves source labels and explicit record periods. Missing headings
are never synthesized as empty fields. Scanned/uncertain pages are passed to the
caller for local vision review; absence is never a student weakness.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import re
import unicodedata

import fitz

MAX_PDF_BYTES = 20 * 1024 * 1024
MAX_PDF_PAGES = 80


class RecordError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


_HEADINGS = {
    "인적학적사항": ("identity", "인적·학적사항"),
    "인적사항": ("identity", "인적사항"),
    "학적사항": ("identity", "학적사항"),
    "출결상황": ("attendance", "출결상황"),
    "출결사항": ("attendance", "출결사항"),
    "수상경력": ("awards", "수상경력"),
    "자격증및인증취득상황": ("certifications", "자격증 및 인증 취득상황"),
    "자격증및인증취득사항": ("certifications", "자격증 및 인증 취득사항"),
    "자격증및인증취득": ("certifications", "자격증 및 인증 취득"),
    "국가직무능력표준이수상황": ("ncs", "국가직무능력표준 이수상황"),
    "학교폭력조치상황관리": ("school_violence", "학교폭력 조치상황 관리"),
    "창의적체험활동상황": ("creative_activity", "창의적 체험활동상황"),
    "자율자치활동": ("autonomy", "자율·자치활동"),
    "자율활동": ("autonomy", "자율활동"),
    "동아리활동": ("club", "동아리활동"),
    "진로활동": ("career", "진로활동"),
    "봉사활동실적": ("volunteer", "봉사활동실적"),
    "봉사활동": ("volunteer", "봉사활동"),
    "일상생활활동상황": ("daily_living", "일상생활 활동상황"),
    "교과학습발달상황": ("academic", "교과학습발달상황"),
    "세부능력및특기사항": ("subject_detail", "세부능력 및 특기사항"),
    "세부능력특기사항": ("subject_detail", "세부능력 특기사항"),
    "개인별세부능력및특기사항": ("subject_detail", "개인별 세부능력 및 특기사항"),
    "자유학기활동상황": ("free_semester", "자유학기활동상황"),
    "자유학년활동상황": ("free_semester", "자유학년활동상황"),
    "진로탐색활동": ("free_semester", "진로탐색활동"),
    "주제선택활동": ("free_semester", "주제선택활동"),
    "예술체육활동": ("free_semester", "예술·체육활동"),
    "독서활동상황": ("reading", "독서활동상황"),
    "행동특성및종합의견": ("behavior", "행동특성 및 종합의견"),
    "행동특성종합의견": ("behavior", "행동특성 종합의견"),
    "기타사항": ("outside_scope", "기타사항"),
    "학교생활기록부정정대장": ("outside_scope", "학교생활기록부 정정대장"),
}
_SUBHEADINGS = {"autonomy", "club", "career", "volunteer", "subject_detail"}
_TABLE_LABELS = {
    "학년", "학년도", "학기", "영역", "시간", "특기사항", "활동내용", "내용", "교과", "과목",
    "학점", "단위수", "이수시간", "성취도", "수강자수", "수업일수", "결석일수", "지각", "조퇴",
    "결과", "질병", "미인정", "기타", "원점수", "과목평균", "원점수과목평균", "비고",
    "세부능력및특기사항", "수상명", "등급위", "수상연월일", "수여기관", "참가대상참가인원",
}
_EMPTY = {"", "-", "—", "미기재", "미작성", "작성중", "작성예정", "기재예정", "공란", "없음", "기록없음"}
_NOT_APPLICABLE = {"해당없음", "해당사항없음", "적용대상아님"}
_IDENTITY_LINE = re.compile(r"^(?:성명|이름|주민등록번호|생년월일|주소|보호자|학번|반번호|학년반번호|학교코드|문서확인번호|발급번호|출력일시|출력일|발급일시|발급일)\s*[:：]?")
_YEAR = re.compile(r"(?<!\d)((?:19|20)\d{2})\s*학년도|학년도\s*[:：]?\s*((?:19|20)\d{2})(?!\d)")
_GRADE = re.compile(r"(?<![\d~～\-])([1-6])\s*학년|(?<![가-힣])학년\s*[:：]?\s*([1-6])(?!\d)")
_SEMESTER = re.compile(r"(?<![\d~～\-])([12])\s*학기|학기\s*[:：]?\s*([12])(?!\d)")


def _compact(text: str) -> str:
    return re.sub(r"[\s·･ㆍ・•:：()\[\]{}._\-/|]", "", unicodedata.normalize("NFC", text))


def _metadata(text: str) -> dict:
    result = {}
    for key, pattern in (("academic_year", _YEAR), ("grade", _GRADE), ("semester", _SEMESTER)):
        matches = {int(next(part for part in match if part)) for match in pattern.findall(text)}
        if len(matches) == 1:
            result[key] = matches.pop()
    return result


def _metadata_line(text: str) -> bool:
    if not _metadata(text):
        return False
    remaining = _YEAR.sub("", text)
    remaining = _GRADE.sub("", remaining)
    remaining = _SEMESTER.sub("", remaining)
    remaining = re.sub(r"(?:중학교|고등학교|학교생활세부사항기록부|학교생활기록부|기술합성|합성|기록|현재|중|고)", "", remaining)
    return not re.search(r"[가-힣a-zA-Z0-9]", remaining)


def _context_update(context: dict, updates: dict) -> dict:
    result = deepcopy(context)
    # A grade alone does not identify an academic year in a multi-year record.
    if "grade" in updates and result.get("grade") is not None and updates["grade"] != result.get("grade") and "academic_year" not in updates:
        result["academic_year"] = None
        result["semester"] = None
    if "academic_year" in updates and result.get("academic_year") is not None and updates["academic_year"] != result.get("academic_year") and "grade" not in updates:
        result["grade"] = None
        result["semester"] = None
    result.update(updates)
    return result


def _page_rows(page) -> list[dict]:
    """Keep visual rows and horizontal cell boundaries without flattening tables."""
    fragments = []
    for block in page.get_text("dict", sort=True).get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            text = "".join(span.get("text", "") for span in line.get("spans", []))
            text = unicodedata.normalize("NFC", text).strip()
            if text:
                x0, y0, x1, y1 = line["bbox"]
                fragments.append({"text": text, "x0": x0, "x1": x1, "y0": y0, "y1": y1})
    fragments.sort(key=lambda item: (round(item["y0"], 1), item["x0"]))
    grouped = []
    for fragment in fragments:
        if grouped and abs(fragment["y0"] - grouped[-1]["y0"]) <= 2.5:
            grouped[-1]["cells"].append(fragment)
        else:
            grouped.append({"y0": fragment["y0"], "cells": [fragment]})
    rows = []
    for number, group in enumerate(grouped, 1):
        cells = sorted(group["cells"], key=lambda item: item["x0"])
        rows.append({"number": number, "cells": cells, "text": " | ".join(cell["text"] for cell in cells)})
    return rows


def _merge_heading_fragments(rows: list[dict]) -> list[dict]:
    """Join a wrapped heading in one narrow cell, retaining adjacent body cells."""
    rows = deepcopy(rows)
    for index, row in enumerate(rows):
        for cell in row["cells"]:
            if not cell["text"]:
                continue
            joined = re.sub(r"^\s*(?:\d{1,2}\s*[.)]|[①-⑳])\s*", "", cell["text"])
            key = _compact(joined)
            if key in _HEADINGS or not any(label.startswith(key) for label in _HEADINGS) or len(key) < 2:
                continue
            consumed = []
            for later in rows[index + 1:index + 4]:
                matches = [part for part in later["cells"] if abs(part["x0"] - cell["x0"]) <= 4 and part["text"]]
                if len(matches) != 1:
                    break
                part = matches[0]
                joined += " " + part["text"]
                consumed.append(part)
                key = _compact(joined)
                if key in _HEADINGS:
                    cell["text"] = joined
                    for used in consumed:
                        used["text"] = ""
                    break
                if not any(label.startswith(key) for label in _HEADINGS):
                    break
    result = []
    for row in rows:
        row["cells"] = [cell for cell in row["cells"] if cell["text"]]
        row["text"] = " | ".join(cell["text"] for cell in row["cells"])
        if row["cells"]:
            result.append(row)
    return result


def _heading(row: dict, parent_category: str | None) -> tuple[str, str, str] | None:
    cells = [cell["text"].strip() for cell in row["cells"]]
    for index, original in enumerate(cells):
        candidate = re.sub(r"^\s*(?:\d{1,2}\s*[.)]|[①-⑳])\s*", "", original)
        label_part, remainder = candidate, ""
        match = re.match(r"^(.+?)(?:\s*[:：]\s*)(.*)$", candidate)
        if match:
            label_part, remainder = match.groups()
        key = _compact(label_part)
        if key not in _HEADINGS:
            base_label = re.sub(r"\s*\((?:특수교육\s*기본\s*교육과정|계속|[1-6](?:\s*[~～-]\s*[1-6])?\s*학년|[12]\s*학기)\)\s*$", "", label_part)
            key = _compact(base_label)
        if key not in _HEADINGS:
            continue
        category, _canonical_label = _HEADINGS[key]
        if category == "club" and parent_category == "free_semester":
            category = "free_semester"
        tail = [remainder] if remainder else []
        # Grade/semester cells before an area label are metadata, not narrative.
        tail.extend(cell for pos, cell in enumerate(cells) if pos > index)
        return category, label_part.strip(), " | ".join(tail).strip()
    # An unfamiliar numbered heading still closes the preceding known section.
    if re.fullmatch(r"\s*\d{1,2}[.)]\s*[가-힣·ㆍ\s]{2,35}", row["text"]):
        return "unclassified", row["text"].strip(), ""
    return None


def _table_columns(row: dict) -> dict:
    cells = row["cells"]
    labels = [_compact(cell["text"]) for cell in cells]
    if not labels or sum(label in _TABLE_LABELS for label in labels) < 2:
        return {}
    columns = {}
    for index, label in enumerate(labels):
        if label not in {"학년도", "학년", "학기"}:
            continue
        cell = cells[index]
        right = cells[index + 1]["x0"] - 2 if index + 1 < len(cells) else cell["x1"] + 25
        columns[{"학년도": "academic_year", "학년": "grade", "학기": "semester"}[label]] = (cell["x0"] - 5, right)
    return columns


def _row_metadata(row: dict, columns: dict) -> dict:
    result = {}
    for key, (left, right) in columns.items():
        for cell in row["cells"]:
            text = cell["text"].strip()
            if left <= cell["x0"] < right and re.fullmatch(r"\d{1,4}", text):
                value = int(text)
                if (key == "academic_year" and 1900 <= value <= 2099 or
                        key == "grade" and 1 <= value <= 6 or key == "semester" and value in (1, 2)):
                    result[key] = value
    return result


def _is_header_or_identity(text: str) -> bool:
    compact = _compact(text)
    if _IDENTITY_LINE.match(text):
        return True
    if len(text) < 180 and re.search(r"(?:^|\s|\|)(?:성명|주민등록번호|생년월일|주소|보호자|학번)\s*[:：]", text):
        return True
    if re.fullmatch(r"\s*[-–—]?\s*\d{1,3}\s*(?:/\s*\d{1,3})?\s*[-–—]?\s*", text):
        return True
    if compact in {"학교생활기록부", "학교생활기록부I", "학교생활기록부II", "학교생활세부사항기록부"}:
        return True
    if len(text) < 80 and ("학교생활기록부" in text or "학교생활세부사항기록부" in text):
        return True
    if len(text) < 60 and (text.endswith("중학교") or text.endswith("고등학교")):
        return True
    return "실제 학생 기록 아님" in text or "실제학생기록아님" in compact


def _content_status(text: str, category: str) -> str:
    compact = _compact(text)
    if compact in _NOT_APPLICABLE:
        return "not_applicable"
    if compact in {_compact(marker) for marker in _EMPTY}:
        return "empty"
    if category == "unclassified" or text.count("\ufffd") > max(2, len(text) // 30):
        return "uncertain"
    return "present"


def _stage_hints(rows: list[dict]) -> set[str]:
    stages = set()
    for row in rows[:8]:
        header = row["text"]
        if not ("학교생활기록부" in header or "학교생활세부사항기록부" in header
                or re.fullmatch(r".{0,40}(?:중학교|고등학교)", header)
                or re.match(r"학교급\s*[:：]", header)):
            continue
        if "중학교" in header:
            stages.add("middle")
        if "고등학교" in header:
            stages.add("high")
    return stages


def _parse_pages(pages: list[dict], school_stage: str) -> tuple[list[dict], list[dict], list[str]]:
    sections = []
    evidence = []
    warnings = []
    context = {"academic_year": None, "grade": None, "semester": None}
    active = None
    parent_category = None
    excluded = False
    columns = {}
    continuation = None

    def finish():
        nonlocal active
        if active is None:
            return
        text = "\n".join(item["text"] for item in active["lines"]).strip()
        number = len(sections) + 1
        sid = f"section-{number:04}-{hashlib.sha256((active['label'] + text).encode('utf-8')).hexdigest()[:8]}"
        section = {
            "id": sid, "category": active["category"], "label": active["label"],
            "school_stage": school_stage, **active["context"],
            "pages": sorted(active["pages"]), "text": text,
            "status": _content_status(text, active["category"]),
        }
        sections.append(section)
        source_lines = active["lines"] or [active["heading_source"]]
        for page in section["pages"]:
            locations = [item["line"] for item in source_lines if item["page"] == page]
            if locations:
                evidence.append({"section_id": sid, "page": page, "line_start": min(locations),
                                 "line_end": max(locations), "text_sha256": hashlib.sha256(text.encode('utf-8')).hexdigest()})
        active = None

    def start(category, label, page, line, scoped_context=None):
        nonlocal active
        active = {"category": category, "label": label, "context": deepcopy(scoped_context or context),
                  "pages": {page}, "lines": [], "heading_source": {"page": page, "line": line}}

    for page in pages:
        if not page["readable"]:
            # Unknown image content could contain a new heading or a different
            # year. Do not attach subsequent text to the preceding known section.
            finish()
            parent_category = None
            excluded = False
            columns = {}
            continuation = None
            context = {"academic_year": None, "grade": None, "semester": None}
            continue
        for row in _merge_heading_fragments(page["rows"]):
            text, line = row["text"].strip(), row["number"]
            if not text or (_is_header_or_identity(text) and not _metadata_line(text)):
                continue
            if _metadata_line(text):
                updates = _metadata(text)
                new_context = _context_update(context, updates)
                if active and new_context != active["context"]:
                    category, label = active["category"], active["label"]
                    if active["lines"]:
                        finish()
                        continuation = (category, label)
                    else:
                        active["context"] = deepcopy(new_context)
                context = new_context
                continue
            heading = _heading(row, parent_category)
            if heading:
                category, label, tail = heading
                scoped_context = _context_update(context, {**_row_metadata(row, columns), **_metadata(label)})
                if active and not active["lines"] and (
                    active["category"] == "creative_activity" and category in {"autonomy", "club", "career", "volunteer"}
                    or active["category"] == "academic" and category == "subject_detail"
                    or active["category"] == "free_semester" and category == "free_semester"
                ):
                    # A containing title is not a separate blank student field.
                    active = None
                finish()
                continuation = None
                excluded = category in {"identity", "outside_scope"}
                if category not in _SUBHEADINGS:
                    parent_category = category
                    columns = {}
                if excluded:
                    continue
                start(category, label, page["number"], line, scoped_context)
                if tail and not _metadata_line(tail):
                    active["lines"].append({"page": page["number"], "line": line, "text": tail})
                continue
            discovered_columns = _table_columns(row)
            if discovered_columns:
                columns = discovered_columns
            if all(_compact(cell["text"]) in _TABLE_LABELS for cell in row["cells"]):
                continue
            if excluded:
                continue
            row_context = _row_metadata(row, columns)
            if active and row_context:
                new_context = _context_update(active["context"], row_context)
                if new_context != active["context"] and active["lines"]:
                    category, label = active["category"], active["label"]
                    finish()
                    start(category, label, page["number"], line, new_context)
                else:
                    active["context"] = new_context
            if row_context and all(
                re.fullmatch(r"\d{1,4}", cell["text"].strip()) and
                any(left <= cell["x0"] < right for left, right in columns.values())
                for cell in row["cells"]
            ):
                continue
            if active is None:
                if continuation:
                    start(*continuation, page["number"], line)
                    continuation = None
                else:
                    start("unclassified", "항목명 확인 필요", page["number"], line)
            active["pages"].add(page["number"])
            active["lines"].append({"page": page["number"], "line": line, "text": text})
        columns = {}
    finish()
    if any(section["status"] == "empty" for section in sections):
        warnings.append("빈 항목은 작성 중·기재 대상 차이일 수 있습니다. 학생의 부족함이나 미참여로 해석하지 않습니다.")
    if any(section["status"] == "uncertain" for section in sections):
        warnings.append("항목명 또는 판독이 불확실한 구간은 근거로 확정하지 않고 원문을 확인합니다.")
    if any(section["academic_year"] is None for section in sections):
        warnings.append("일부 구간의 기록 학년도가 명시되지 않았습니다. 입학 연도나 현재 학년으로 역산하지 않았습니다.")
    return sections, evidence, warnings


def extract_record(pdf_bytes: bytes, filename: str, password: str | None = None) -> dict:
    """Extract a private record in memory; returned status describes evidence only."""
    if not isinstance(pdf_bytes, bytes):
        raise RecordError("PDF_INVALID", "PDF 파일 데이터를 확인할 수 없습니다.")
    if len(pdf_bytes) > MAX_PDF_BYTES:
        raise RecordError("PDF_TOO_LARGE", "PDF 파일은 20MB 이하로 올려주세요.")
    if not pdf_bytes.startswith(b"%PDF-"):
        raise RecordError("PDF_INVALID", "PDF 형식의 파일을 선택해주세요.")
    if b"%%EOF" not in pdf_bytes[-1024:]:
        raise RecordError("PDF_DAMAGED", "PDF가 잘렸거나 저장이 끝나지 않았습니다. 원본을 다시 저장해주세요.")
    if not isinstance(filename, str) or not filename.strip() or "\x00" in filename or len(filename) > 500:
        raise RecordError("PDF_FILENAME", "PDF 파일 이름을 확인해주세요.")
    if password is not None and not isinstance(password, str):
        raise RecordError("PDF_PASSWORD", "PDF 암호는 문자로 입력해주세요.")
    name = re.split(r"[\\/]", filename)[-1].strip()
    try:
        document = fitz.open(stream=pdf_bytes, filetype="pdf")
    except Exception:
        raise RecordError("PDF_DAMAGED", "PDF 구조를 읽지 못했습니다. 원본을 다시 저장해주세요.") from None
    try:
        if document.needs_pass:
            if not password:
                raise RecordError("PDF_PASSWORD_REQUIRED", "암호가 설정된 PDF입니다. 파일 암호를 입력해주세요.")
            if not document.authenticate(password):
                raise RecordError("PDF_PASSWORD_INCORRECT", "PDF 암호가 일치하지 않습니다.")
        if document.is_repaired:
            raise RecordError("PDF_DAMAGED", "PDF 구조가 손상되어 자동 복구가 필요합니다. 원본을 다시 저장해주세요.")
        page_count = len(document)
        if not 1 <= page_count <= MAX_PDF_PAGES:
            raise RecordError("PDF_PAGE_LIMIT", "학생부 PDF는 1~80페이지 범위로 올려주세요.")
        pages = []
        stages = set()
        warnings = []
        for number, page in enumerate(document, 1):
            try:
                rows = _page_rows(page)
                extracted = "\n".join(row["text"] for row in rows)
                meaningful = re.sub(r"\s", "", extracted)
                readable = len(re.findall(r"[가-힣A-Za-z0-9]", meaningful)) >= 4
                if meaningful.count("\ufffd") > max(2, len(meaningful) // 20):
                    readable = False
                image_area = 0
                for item in page.get_images(full=True):
                    for rectangle in page.get_image_rects(item[0]):
                        image_area += rectangle.get_area()
                if image_area > page.rect.get_area() * 0.35 and len(meaningful) < 100:
                    readable = False
                stages.update(_stage_hints(rows))
                pages.append({"number": number, "rows": rows, "readable": readable})
            except Exception:
                pages.append({"number": number, "rows": [], "readable": False})
                warnings.append(f"{number}쪽의 텍스트 판독에 실패했습니다. 로컬 화면에서 원문을 확인해주세요.")
        school_stage = next(iter(stages)) if len(stages) == 1 else "unknown"
        if school_stage == "unknown":
            warnings.append("학교급을 확정하지 못했습니다. 중·고교 항목 및 성적 기준을 자동 변환하지 않습니다.")
        sections, evidence, parser_warnings = _parse_pages(pages, school_stage)
        unreadable = [page["number"] for page in pages if not page["readable"]]
        if unreadable:
            warnings.append("텍스트를 읽지 못한 페이지가 있습니다. 스캔·빈 페이지·문자 인코딩 문제를 구별하기 위해 로컬 판독이 필요합니다.")
        sha = hashlib.sha256(pdf_bytes).hexdigest()
        return {
            "id": "record-" + sha[:20], "filename": name, "sha256": sha,
            "page_count": page_count, "school_stage": school_stage,
            "sections": sections, "warnings": list(dict.fromkeys(warnings + parser_warnings)),
            "readable_pages": [page["number"] for page in pages if page["readable"]],
            "unreadable_pages": unreadable, "evidence_index": evidence,
        }
    finally:
        document.close()


def merge_ocr_pages(record: dict, page_texts: dict[int, str]) -> dict:
    """Merge caller-provided local vision text; never call a model or mix sources.

    Native PDF sections remain unchanged. Each OCR page is independently parsed
    at its original page number. A heading missing from an OCR page remains an
    uncertain fragment rather than inheriting a previous page's category/year.
    """
    if not isinstance(record, dict) or not isinstance(page_texts, dict):
        raise RecordError("OCR_INPUT", "로컬 판독 결과의 형식을 확인해주세요.")
    result = deepcopy(record)
    eligible = set(record.get("unreadable_pages", [])) | set(record.get("ocr_pages", []))
    for page, text in page_texts.items():
        if type(page) is not int or page not in eligible or not isinstance(text, str) or len(text) > 60000:
            raise RecordError("OCR_INPUT", "판독 대상 페이지와 로컬 판독 결과가 일치하지 않습니다.")
    replacements = set(page_texts)
    old_ocr_ids = {section["id"] for section in result.get("sections", [])
                   if section.get("extraction_method") == "local_vision_ocr" and replacements.intersection(section["pages"])}
    result["sections"] = [section for section in result.get("sections", []) if section["id"] not in old_ocr_ids]
    result["evidence_index"] = [entry for entry in result.get("evidence_index", []) if entry["section_id"] not in old_ocr_ids]
    recovered = set()
    attempted = set(record.get("ocr_pages", []))
    for page, text in sorted(page_texts.items()):
        attempted.add(page)
        unrecognized = bool(re.search(r"판독\s*(?:불가|실패)|읽을\s*수\s*없|인식\s*(?:불가|실패)|unreadable", text, re.I))
        meaningful = re.sub(r"\s+", "", text)
        if len(re.findall(r"[가-힣A-Za-z0-9]", meaningful)) < 4 or meaningful in {"빈페이지", "공백페이지", "내용없음"}:
            continue
        rows = []
        for number, line in enumerate(text.splitlines(), 1):
            if not line.strip():
                continue
            cells = [cell.strip() for cell in line.split("|") if cell.strip()]
            rows.append({"number": number, "text": " | ".join(cells),
                         "cells": [{"text": cell, "x0": index * 150, "x1": index * 150 + 100} for index, cell in enumerate(cells)]})
        stage_hints = _stage_hints(rows)
        stage = next(iter(stage_hints)) if len(stage_hints) == 1 else record.get("school_stage", "unknown")
        sections, evidence, warnings = _parse_pages([{"number": page, "rows": rows, "readable": True}], stage)
        id_map = {}
        for section in sections:
            prior_id = section["id"]
            section["id"] = f"ocr-p{page:03}-" + prior_id
            id_map[prior_id] = section["id"]
            section["extraction_method"] = "local_vision_ocr"
            if re.search(r"판독\s*(?:불가|실패)|읽을\s*수\s*없|unreadable", section["text"], re.I):
                section["status"] = "uncertain"
        for entry in evidence:
            entry["section_id"] = id_map[entry["section_id"]]
            entry["method"] = "local_vision_ocr"
        result["sections"].extend(sections)
        result["evidence_index"].extend(evidence)
        result["warnings"].extend(warnings)
        if not unrecognized and any(section["status"] in {"present", "empty", "not_applicable"} for section in sections):
            recovered.add(page)
    result["sections"].sort(key=lambda section: (min(section["pages"]), section["id"]))
    section_stages = {section["school_stage"] for section in result["sections"] if section["school_stage"] != "unknown"}
    if result.get("school_stage") == "unknown" and len(section_stages) == 1:
        result["school_stage"] = next(iter(section_stages))
    result["ocr_pages"] = sorted(attempted)
    result["readable_pages"] = sorted((set(record.get("readable_pages", [])) - replacements) | recovered)
    result["unreadable_pages"] = sorted((set(record.get("unreadable_pages", [])) | replacements) - recovered)
    result["warnings"].append("일부 페이지는 로컬 비전 모델의 판독 결과입니다. 항목·수치·문장을 원본 PDF와 대조한 뒤 상담 근거를 확인해주세요.")
    result["warnings"] = list(dict.fromkeys(result["warnings"]))
    return result
