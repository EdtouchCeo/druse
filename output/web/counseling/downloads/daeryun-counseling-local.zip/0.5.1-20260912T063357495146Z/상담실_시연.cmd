@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Start-Counseling.ps1" -Demo
if errorlevel 1 pause
