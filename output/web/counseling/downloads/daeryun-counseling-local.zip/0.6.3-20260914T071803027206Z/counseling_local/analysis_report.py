"""A self-contained student-record report independent of the counseling workflow."""
from __future__ import annotations

from .domain import CounselingError
from .teacher_report import TeacherReport, evidence_location, is_consolidated


def require_current_analysis(session):
    """An export must describe the record currently attached to this session."""
    record = session.get("record")
    analysis = session.get("analysis")
    if not record:
        raise CounselingError("record_required", "학생부 PDF를 불러오고 분석하면 학생부 분석 보고서를 저장할 수 있습니다.", 409)
    if not analysis:
        raise CounselingError("analysis_required", "학생부 분석을 완료하면 학생부 분석 보고서를 저장할 수 있습니다.", 409)
    if not record.get("sha256") or not analysis.get("record_sha256"):
        raise CounselingError("analysis_source_unverified", "저장된 분석과 현재 학생부의 연결을 확인할 수 없습니다. 학생부를 다시 분석해 주세요.", 409)
    if analysis["record_sha256"] != record["sha256"]:
        raise CounselingError("stale_analysis", "현재 학생부와 저장된 분석의 원본이 다릅니다. 현재 학생부를 다시 분석해 주세요.", 409)
    return record, analysis


def analysis_report_pdf(case, session):
    """Project final analysis only, without consulting or changing teacher decisions."""
    record, analysis = require_current_analysis(session)
    report = TeacherReport("학생부 분석 보고서")
    report.paragraph("학생부 분석 보고서", 19)
    report.paragraph("학생부 분석 기반 · 상담 미반영", 10.5)
    report.paragraph("분석 초안 · 교사의 최종 전략 및 확정 실행 과제와 구분되는 자료입니다.", 9)
    student = session.get("student_snapshot") or case["student"]
    metadata = [f"{student['academic_year']}학년도",
                f"{'중학교' if student['school_stage'] == 'middle' else '고등학교'} {student['grade']}학년"]
    if student.get("student_number"):
        metadata.append("학번 " + student["student_number"])
    if student.get("name"):
        metadata.append(student["name"])
    report.paragraph(" · ".join(metadata), 9)
    report.paragraph("작성일 " + session["date"], 9)
    if case.get("origin") == "synthetic":
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이나 교사의 검토 결과가 아닙니다.", 9)
    if session.get("imported_unverified"):
        report.paragraph("가져온 미검증 참고 자료 · 저장된 원본 식별 정보는 일치하지만, 원본 PDF 대조와 분석 실행 이력은 검증되지 않았습니다.", 9)

    sections = {item.get("id"): item for item in record.get("sections", []) if isinstance(item, dict)}
    report.section("01  분석 요약")
    report.paragraph(analysis.get("summary") or "제공된 학생부에서 확인한 내용과 근거를 아래 항목별로 정리했습니다.")

    report.section("02  기록에서 확인한 강점과 근거")
    strengths = analysis.get("strengths") or []
    if not strengths:
        report.paragraph("제공된 자료만으로 강점을 판단할 근거가 충분하지 않습니다.")
    for index, item in enumerate(strengths, 1):
        report.finding(index, item, sections)

    section_number = 3
    improvements = analysis.get("improvements") or []
    actions = analysis.get("actions") or []
    if improvements or actions:
        report.section(f"{section_number:02}  보완 방향과 활동 제안")
        section_number += 1
        if improvements:
            report.heading("보완할 부분과 지도 방향")
            for index, item in enumerate(improvements, 1):
                report.finding(index, item, sections)
        if actions:
            report.heading("다음 활동 제안")
            report.paragraph("아래 제안은 확정 과제가 아닙니다. 학생의 희망과 가용 시간을 확인하여 조정합니다.", 9)
            if len(actions) > 1 and not is_consolidated(analysis):
                report.paragraph("저장된 활동 후보를 함께 제시합니다. 나열 순서는 우선순위를 뜻하지 않습니다.", 9)
            for index, item in enumerate(actions, 1):
                report.heading(f"제안 {index}")
                report.paragraph(item.get("text", ""))
                if item.get("reason"):
                    report.paragraph("제안 이유: " + item["reason"], 9)
                location = evidence_location(item, sections)
                if location:
                    report.paragraph("확인 위치: " + location, 9)

    questions = analysis.get("questions") or []
    if questions:
        report.section(f"{section_number:02}  추가로 확인할 질문")
        section_number += 1
        for index, question in enumerate(questions, 1):
            report.paragraph(f"{index}. {question}")

    report.section(f"{section_number:02}  분석 범위와 해석의 한계")
    report.paragraph(f"제공된 학생부 {record.get('page_count', 0)}쪽 · 읽힌 페이지 {len(record.get('readable_pages', []))}쪽", 9)
    report.paragraph("학생부에 기록된 사실과 분석을 정리했습니다. 기록에 없는 능력·경험의 부족이나 입시 결과를 단정하지 않습니다. 상담 후의 전략과 실행 과제는 이 보고서에 반영하지 않습니다.", 9)
    for warning in record.get("warnings") or []:
        report.paragraph(warning, 9)
    for limitation in analysis.get("limitations") or []:
        report.paragraph(limitation, 9)
    return report.finish()
