"""Structured teacher review document, with saved evidence kept in appendices."""
from __future__ import annotations

from .domain import consultation_value, profile_value, strategy_value
from .report import Report, STRATEGY_LABELS, write_profile


NAVY = (0.13, 0.25, 0.37)
MUTED = (0.36, 0.42, 0.48)
PALE = (0.92, 0.95, 0.97)
ACTION_STATUSES = {"planned": "예정", "in_progress": "진행 중", "done": "완료", "deferred": "보류"}


class TeacherReport(Report):
    """Add document hierarchy without changing the student report renderer."""

    def __init__(self, title):
        self.bookmarks = []
        super().__init__(title)

    def section(self, title, *, page_break=False):
        self.flush_headings()
        if (page_break and self.y > 68) or self.y + 105 > 785:
            self.new_page()
        self.y += 6
        self.page.draw_rect((46, self.y - 10, 549, self.y + 21), color=None, fill=PALE)
        self.page.draw_rect((46, self.y - 10, 49, self.y + 21), color=None, fill=NAVY)
        self.page.insert_text((58, self.y + 10), title, fontname="CounselingFont", fontsize=12.5, color=NAVY)
        self.bookmarks.append([1, title, self.page.number + 1])
        self.y += 41

    def flush_headings(self, body_lines=0, body_size=10.5):
        if not self.pending_headings:
            return
        headings = [self.wrapped_lines(value, 11.5) for value in self.pending_headings]
        fragment = min(3 if body_lines == 3 else 2, body_lines)
        needed = sum(14 + len(lines) * 11.5 * 1.65 for lines in headings) + fragment * body_size * 1.65
        if self.y > 68 and self.y + needed > 785:
            self.new_page()
        self.pending_headings = []
        for lines in headings:
            self.y += 9
            for value in lines:
                self.line(value, 11.5, NAVY)
            self.y += 5

    def finding(self, index, item, sections):
        title = f"{index}. {item.get('text', '')}"
        quote = item.get("quote") or ""
        location = evidence_location(item, sections)
        guidance = item.get("guidance") or ""
        height = len(self.wrapped_lines(title, 11.5)) * 11.5 * 1.65 + 20
        for value, size in (("원문 근거: " + quote if quote else "", 9),
                            ("확인 위치: " + location if location else "", 9),
                            ("지도 방향: " + guidance if guidance else "", 10.5)):
            if value:
                height += len(self.wrapped_lines(value, size)) * size * 1.65 + 5
        # Ordinary findings travel with their quote; long quotes can still flow.
        if height <= 340 and self.y > 68 and self.y + height > 785:
            self.new_page()
        self.heading(title)
        if quote:
            self.paragraph("원문 근거: " + quote, 9)
        if location:
            self.paragraph("확인 위치: " + location, 9)
        if guidance:
            self.paragraph("지도 방향: " + guidance)
        self.flush_headings()

    def finish(self):
        if self.bookmarks:
            self.doc.set_toc(self.bookmarks)
        return super().finish()


def evidence_location(item, sections):
    references = []
    for evidence_id in item.get("evidence_ids", []):
        source = sections.get(evidence_id)
        if source:
            pages = ", ".join(map(str, source.get("pages", [])))
            references.append(source.get("label", "기록") + (" " + pages + "쪽" if pages else ""))
        else:
            references.append("자료 ID: " + str(evidence_id) + " · 원문 위치 확인 필요")
    return "; ".join(references)


def write_saved_actions(report, session, heading):
    actions = session.get("actions") or []
    report.heading(heading)
    if not actions:
        report.paragraph("아직 작성된 실행 과제가 없습니다.")
    for index, action in enumerate(actions, 1):
        status = ACTION_STATUSES.get(action.get("status"), action.get("status", "확인 필요"))
        report.task(f"{index}. {action.get('text', '')}",
                    f"기한: {action.get('due_date') or '미정'} · 상태: {status}")


def write_saved_strategy(report, session, heading):
    strategy = strategy_value(session.get("strategy", {}))
    present = [(label, strategy[key]) for label, key in STRATEGY_LABELS if strategy[key]]
    if present:
        report.heading(heading)
        for label, value in present:
            report.heading(label)
            report.plan_text(value)


def analysis_counts(analysis):
    return " · ".join(f"{label} {len(analysis.get(key) or [])}개" for label, key in
                      (("강점", "strengths"), ("보완 판단", "improvements"),
                       ("행동 후보", "actions"), ("확인 질문", "questions")))


def is_consolidated(analysis):
    details = analysis.get("analysis_details")
    synthesis = details.get("synthesis") if isinstance(details, dict) else None
    return isinstance(synthesis, dict) and synthesis.get("method") == "candidate_selection"


def teacher_report_pdf(case, session, *, synthetic, valid_confirmation, imported,
                       unverified_record, unverified_analysis):
    consultation = consultation_value(session.get("consultation", {}))
    workflow = session.get("workflow_version") == 2
    completed = workflow and consultation["status"] == "completed"
    title = ("교사용 상담 반영·최종 전략 보고서" if completed else "교사용 사전 전략 준비서") if workflow else "교사용 분석·학종 전략 보고서"
    report = TeacherReport("대륜고 " + title)
    report.paragraph(title, 19)
    status = "시연 확정본" if synthetic and valid_confirmation else "교사 확인본" if valid_confirmation else "초안 · 교사 확인 전"
    report.paragraph("상태: " + status, 10.5)
    student = session.get("student_snapshot") or case["student"]
    teacher = session.get("teacher_snapshot") or case["teacher"]
    student_line = f"학년도 {student['academic_year']} / {'중학교' if student['school_stage'] == 'middle' else '고등학교'} {student['grade']}학년 / 학번 {student['student_number'] or '미입력'}"
    if student.get("name"):
        student_line += " / 학생 이름: " + student["name"]
    report.paragraph(student_line, 9)
    report.paragraph(f"작성일 {session['date']} / 담당 교사 {teacher.get('display_name') or '미입력'} / 전략 차수 {case['sessions'].index(session) + 1} / 저장 버전 {case['revision']}", 9)
    if synthetic:
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이나 실제 교사의 검토 결과가 아닙니다.", 9)
    if imported:
        report.paragraph("가져온 상담 자료입니다. 이전 파일의 검토·확정 표시는 현재 교사의 확인을 대신하지 않습니다.", 9)
        if unverified_record or unverified_analysis:
            report.paragraph("가져온 학생부·분석은 원본 PDF와 대조하지 않은 참고 자료입니다. 원본 PDF를 다시 불러와 확인하기 전에는 이 회차를 확정할 수 없습니다.", 9)
    review = session.get("review")
    if review:
        label = {"passed": "검토 통과", "needs_revision": "수정 필요", "pending": "교사 확인 필요"}.get(review.get("state"), "미검토")
        report.paragraph("최종 확인 · 문체 검토: " + label + (" / 로컬 AI 검토 의견" if review.get("method") == "ollama" else " / 규칙 점검 및 교사 직접 검토"), 9)
    elif valid_confirmation:
        report.paragraph("최종 확인: " + ("시연 확정본" if synthetic else "교사 확인본") + "입니다. 별도 문체 검토 기록은 없습니다.", 9)
    else:
        report.paragraph("최종 확인: 문체 검토와 교사 확인을 거치기 전의 초안입니다.", 9)

    analysis = session.get("analysis") or {}
    record = session.get("record") or {}
    sections = {item.get("id"): item for item in record.get("sections", []) if isinstance(item, dict)}
    profile = profile_value(session.get("profile", {}))
    saved_strategy = strategy_value(session.get("strategy", {}))
    has_current_plan = any(saved_strategy.values()) or bool(session.get("actions") or session.get("next_date"))
    coverage = analysis.get("coverage")
    batches = coverage.get("batches", 1) if isinstance(coverage, dict) else 1
    batches = batches if type(batches) is int else 1
    legacy_long_analysis = bool(analysis and not is_consolidated(analysis) and
                                (batches > 1 or
                                 len(analysis.get("summary", "")) > 900 or
                                 len(analysis.get("strengths") or []) > 3 or
                                 len(analysis.get("actions") or []) > 1 or
                                 len(analysis.get("questions") or []) > 3))

    report.section("01  검토 개요")
    if session.get("topic"):
        report.heading("전략 제목")
        report.paragraph(session["topic"], 12)
    if workflow:
        if completed:
            report.paragraph("학생 상담 반영 완료 · 아래 현재 전략과 실행 과제를 검토합니다.")
        elif session.get("preparation"):
            report.paragraph("교사가 사전 전략을 준비했습니다. 학생 상담과 최종 전략 반영을 진행합니다.")
        else:
            report.paragraph("교사가 사전 전략을 작성하고 있습니다. 아직 상담을 시작하지 않았습니다.")
    minutes = profile["weekly_minutes"]
    report.paragraph("주간 가용 시간: 미확인 · 추가 과제 배정 전 학생과 확인" if minutes is None else
                     f"주간 가용 시간: {minutes}분" + (" · 기존 수업·활동 안에서 계획" if minutes == 0 else ""), 9)
    if not has_current_plan:
        report.paragraph("현재 전략·실행 과제: 작성 전 · 다음 점검: 미정", 9)
    if analysis:
        report.paragraph("AI 분석 참고 항목: " + analysis_counts(analysis), 9)
        if legacy_long_analysis:
            report.paragraph("여러 구간의 분석이 저장되어 있습니다. 전체 요약·행동 후보·질문은 부록 A에서 원문 근거와 함께 검토합니다. 나열 순서는 우선순위를 뜻하지 않습니다.", 9)

    if has_current_plan:
        report.section("02  현재 전략과 실행 과제")
        action_heading = "최종 실행 과제" if completed else "교사가 제안한 실행 과제" if workflow else "합의한 실행 과제"
        write_saved_actions(report, session, action_heading)
        report.heading("다음 점검")
        report.paragraph(session.get("next_date") or "미정")
        strategy_heading = "상담 반영 후 최종 전략" if completed else "작성 중인 교사 전략" if workflow else "학생 성장·학습·진학 전략"
        write_saved_strategy(report, session, strategy_heading)

    # A consolidated analysis is short enough to review before consulting quotes.
    # Older independent batch responses remain complete in the appendix.
    if analysis and not legacy_long_analysis:
        report.section(("03" if has_current_plan else "02") + "  AI 제안 검토")
        report.paragraph("아래는 교사의 선택과 학생 상담이 필요한 분석 제안입니다." +
                         (" 실행 과제 확정 여부는 앞의 현재 전략에서 확인합니다." if has_current_plan else " 아직 확정한 실행 과제가 아닙니다."), 9)
        report.heading("분석 요약 · 가져온 미검증 참고 자료" if unverified_analysis else "분석 요약")
        report.paragraph(analysis.get("summary", ""))
        for label, key in (("기록에서 확인한 강점", "strengths"), ("보완할 부분과 지도 방향", "improvements")):
            if not analysis.get(key):
                report.paragraph(label + ": 제공된 자료에서 판단할 근거가 충분하지 않습니다.", 9)
                continue
            report.heading(label)
            for index, item in enumerate(analysis.get(key) or [], 1):
                report.paragraph(f"{index}. {item.get('text', '')}")
        report.heading("학생의 다음 행동 제안")
        if not analysis.get("actions"):
            report.paragraph("저장된 행동 제안이 없습니다.")
        for index, item in enumerate(analysis.get("actions") or [], 1):
            report.heading(f"후보 {index}")
            report.paragraph(item.get("text", ""))
            if item.get("reason"):
                report.paragraph("제안 이유: " + item["reason"], 9)
            location = evidence_location(item, sections)
            if location:
                report.paragraph("확인 위치: " + location, 9)
        if analysis.get("questions"):
            report.heading("상담에서 확인할 질문")
            for index, question in enumerate(analysis["questions"], 1):
                report.paragraph(f"{index}. {question}")

    if record or analysis:
        report.section("부록 A  분석과 원문 근거", page_break=report.y > 365)
        report.paragraph("저장된 분석과 인용을 확인하기 위한 자료입니다. 인용의 줄 나눔·수치·미완결 문구는 보존하며 원본 PDF와 대조합니다.", 9)
        if record:
            report.heading("학생부 분석 범위")
            report.paragraph(f"제공된 PDF {record.get('page_count', 0)}쪽 / 읽힌 페이지 {len(record.get('readable_pages', []))}쪽", 9)
            for warning in record.get("warnings", []):
                report.paragraph(warning, 9)
        if legacy_long_analysis:
            report.heading("분석 요약 · 가져온 미검증 참고 자료" if unverified_analysis else "분석 요약 · 저장된 전체 내용")
            report.paragraph(analysis.get("summary", ""))
        elif unverified_analysis:
            report.heading("분석 근거 · 가져온 미검증 참고 자료")
        if analysis:
            for label, key in (("기록에서 확인한 강점 · 원문 대조", "strengths"), ("보완할 부분과 지도 방향 · 원문 대조", "improvements")):
                report.heading(label)
                if not analysis.get(key):
                    report.paragraph("제공된 자료에서 판단할 근거가 충분하지 않습니다.")
                for index, item in enumerate(analysis.get(key) or [], 1):
                    report.finding(index, item, sections)
            if legacy_long_analysis:
                if analysis.get("actions"):
                    report.heading("학생의 다음 행동 제안 · 저장된 전체 후보")
                    for index, item in enumerate(analysis["actions"], 1):
                        report.heading(f"후보 {index}")
                        report.paragraph(item.get("text", ""))
                        if item.get("reason"):
                            report.paragraph("제안 이유: " + item["reason"], 9)
                        location = evidence_location(item, sections)
                        if location:
                            report.paragraph("확인 위치: " + location, 9)
                if analysis.get("questions"):
                    report.heading("상담에서 확인할 질문 · 저장된 전체 내용")
                    for index, question in enumerate(analysis["questions"], 1):
                        report.paragraph(f"{index}. {question}")
            if analysis.get("limitations"):
                report.heading("해석 범위와 확인할 점")
                for item in analysis["limitations"]:
                    report.paragraph(item, 9)
            report.paragraph(f"분석 모델: {analysis.get('model', '확인 필요')} / " + ("가져온 파일의 표기 · 실행 이력 미검증" if unverified_analysis else "로컬 실행"), 9)

    private_fields = (("학생의 질문", "student_question"), ("현재 상황과 이전 상담", "context"),
                      ("검토한 자료", "evidence_notes"), ("교사의 상담 의견", "teacher_opinion"))
    has_context = any(session.get(key) for _, key in private_fields)
    has_profile = any(profile[key] for key in profile if key != "weekly_minutes") or minutes is not None
    has_workflow_history = workflow and (session.get("preparation") or consultation["status"] != "not_started")
    if has_context or has_profile or has_workflow_history:
        report.section("부록 B  학생 자료와 상담 기록", page_break=report.y > 365)
        write_profile(report, session)
        for heading, key in private_fields:
            if session.get(key):
                report.heading(heading)
                if key == "evidence_notes":
                    report.source_text(session[key])
                else:
                    report.paragraph(session[key])
        if workflow:
            report.heading("전략 수립과 상담 진행")
            report.paragraph("학생 자료 분석 → 교사 전략 수립 → 학생 상담·반영 → 최종 전략·실행 계획", 9)
            if consultation["status"] != "not_started":
                report.heading("학생 상담 및 반영 기록 · 교사용")
                report.paragraph("상담 반영 상태: " + ("완료" if consultation["status"] == "completed" else "진행 중"))
                if consultation["date"]:
                    report.paragraph("상담일: " + consultation["date"], 9)
                for label, key in (("학생의 반응", "student_response"), ("합의한 방향", "agreed_direction"),
                                   ("전략 수정 사항", "adjustments"), ("상담 요약", "summary")):
                    if consultation[key]:
                        report.heading(label)
                        report.paragraph(consultation[key])
            preparation = session.get("preparation")
            if preparation:
                imported_preparation = (session.get("imported_history") or {}).get("preparation_imported") is True
                report.heading("가져온 사전 전략 참고본" if imported_preparation else "상담 전 교사가 준비한 전략")
                report.paragraph("준비 시각: " + preparation["prepared_at"], 9)
                if imported_preparation:
                    report.paragraph("백업에 포함된 사전 전략입니다. 이전 작성자·시각은 현재 교사의 검증된 확인 이력이 아닙니다.", 9)
                report.paragraph("준비 당시 제목: " + preparation["topic"])
                write_saved_strategy(report, preparation, "상담 전 전략 사본")
                write_saved_actions(report, preparation, "상담 전 제안한 실행 과제")
    return report.finish()
