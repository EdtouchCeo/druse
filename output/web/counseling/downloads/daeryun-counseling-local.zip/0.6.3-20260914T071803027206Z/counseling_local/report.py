"""Offline PDF rendering. No HTML renderer, external font, or network dependency."""
from __future__ import annotations

import fitz
import math

from .domain import (CounselingError, content_hash,
                     has_profile, profile_value, require_consultation_complete, strategy_value)


def write_profile(report, session):
    profile = profile_value(session.get("profile", {}))
    if not has_profile(profile):
        return
    report.heading("학생 기본자료 · 교사 검토용")
    report.paragraph("교사가 입력한 자료를 정리했습니다. 학생부 원문이나 검증된 평가 결과와 구분하며, 미입력 항목은 약점을 뜻하지 않습니다.", 9)
    fields = (("희망 전공", "target_major"), ("관심 분야", "interests"), ("학습 고민", "learning_concerns"),
              ("학습 습관", "study_habits"), ("참여 활동", "activities"), ("읽기·독서", "reading"),
              ("출결 관련 확인", "attendance_notes"), ("교사의 관찰", "teacher_observations"))
    for label, key in fields:
        if profile[key]:
            report.heading(label)
            report.paragraph(profile[key])
    if profile["selected_subjects"]:
        report.paragraph("실제 이수 과목: " + ", ".join(profile["selected_subjects"]))
    if profile["weekly_minutes"] is not None:
        report.paragraph(f"주간 가용 시간: {profile['weekly_minutes']}분")
    if profile["grades"]:
        report.heading("입력한 교과 성적")
        for grade in sorted(profile["grades"], key=lambda g: (g["academic_year"], g["semester"], g["subject"])):
            scale = grade["grade_scale"]
            parts = [f"{grade['academic_year']}학년도 {grade['semester']}학기", grade["subject"] or "과목 미입력",
                     f"{scale}등급 체계" if scale in ("5", "9") else "성취도 체계" if scale == "achievement" else "등급 체계 미확인"]
            if grade["rank_grade"] is not None:
                parts.append(f"석차등급 {grade['rank_grade']}")
            if grade["score"] is not None:
                parts.append(f"원점수 {grade['score']}")
            if grade["achievement"]:
                parts.append("성취도 " + grade["achievement"])
            report.paragraph(" · ".join(parts), 9)
        report.paragraph("5등급과 9등급을 변환·합산하지 않습니다. 원점수의 변화는 평가 조건을 확인한 뒤 해석합니다.", 9)


STRATEGY_LABELS = (("목표 전공·관심 분야", "target_major"), ("희망 진로·진학 방향", "target_path"),
                   ("근거에서 확인한 강점", "strengths"), ("보완할 점과 필요한 도움", "gaps"),
                   ("교과 학습 계획", "subject_plan"), ("탐구 계획", "inquiry_plan"),
                   ("활동 계획", "activity_plan"), ("학기별 실행 계획", "semester_plan"),
                   ("학생에게 전하는 안내", "student_message"))


def write_strategy(report, session, heading="학생 성장·학습·진학 전략", student=False):
    strategy = strategy_value(session.get("strategy", {}))
    if any(strategy.values()):
        report.heading(heading)
        fields = sorted(STRATEGY_LABELS, key=lambda item: item[1] != "student_message") if student else STRATEGY_LABELS
        for label, key in fields:
            if strategy[key]:
                report.heading(label)
                report.paragraph(strategy[key])


def write_actions(report, session, heading="합의한 실행 과제"):
    if session.get("actions"):
        report.heading(heading)
        labels = {"planned": "예정", "in_progress": "진행 중", "done": "완료", "deferred": "보류"}
        for index, action in enumerate(session["actions"]):
            report.paragraph(f"{index + 1}. {action['text']} ({labels.get(action['status'], action['status'])})")
            if action.get("due_date"):
                report.paragraph("점검 기한: " + action["due_date"], 9)


def write_student_strategy(report, session):
    """Order the public final document for action without rewriting saved text."""
    strategy = strategy_value(session.get("strategy", {}))
    if strategy["student_message"]:
        report.heading("학생에게 전하는 안내")
        report.paragraph(strategy["student_message"])
    report.heading("이번 실행 과제")
    actions = [action for action in session.get("actions", []) if action.get("text", "").strip()]
    statuses = {"planned": "예정", "in_progress": "진행 중", "done": "완료", "deferred": "보류"}
    for index, action in enumerate(actions, 1):
        # Keep the task with its date/status when a page break is necessary.
        report.task(f"{index}. {action['text']}",
                    f"기한: {action.get('due_date') or '미정'} · 상태: {statuses.get(action['status'], action['status'])}")
    if not actions:
        report.paragraph("실행 과제: 미정")
    report.heading("다음 점검")
    report.paragraph(session.get("next_date") or "미정")
    for heading, fields in (("선택한 방향과 근거", STRATEGY_LABELS[:4]),
                            ("교과·탐구·활동 계획", STRATEGY_LABELS[4:8])):
        present = [(label, strategy[key]) for label, key in fields if strategy[key]]
        if present:
            report.heading(heading)
            for label, value in present:
                report.heading(label)
                report.plan_text(value)


def student_report_pdf(case, session):
    """Render only the teacher-confirmed student-facing projection."""
    title = "학생 안내 · 상담 후 최종 전략과 실행 계획" if session.get("workflow_version") == 2 else "학생 안내 · 학종 전략과 실행 계획"
    report = Report("대륜고 " + title)
    report.paragraph(title, 19)
    synthetic = case.get("origin") == "synthetic"
    if synthetic:
        report.paragraph("합성자료 시연입니다. 실제 학생 기록이 아니며 실제 교사의 검토나 학생 전달을 뜻하지 않습니다.")
    student = session.get("student_snapshot") or case["student"]
    teacher = session.get("teacher_snapshot") or case["teacher"]
    metadata = [f"{student['academic_year']}학년도"]
    if student.get("student_number"):
        metadata.append("학번 " + student["student_number"])
    if student.get("name"):
        metadata.append(student["name"])
    report.paragraph(" · ".join(metadata), 9)
    details = ["시연 확정본" if synthetic else "교사 확인본", "작성일 " + session["date"]]
    if teacher.get("display_name"):
        details.append("담당 교사 " + teacher["display_name"])
    report.paragraph(" · ".join(details), 9)
    if session.get("topic"):
        report.paragraph(session["topic"], 14)
    write_student_strategy(report, session)
    if not synthetic:
        report.paragraph("교사가 확인한 최종 전략과 실행 과제입니다. 이 PDF는 교사가 학생에게 직접 전달합니다.", 9)
    return report.finish()


class Report:
    def __init__(self, title):
        self.doc = fitz.open()
        self.font = fitz.Font("korea")
        self.title = title
        self.page = None
        self.y = 0
        self.pending_headings = []
        self.new_page()

    def new_page(self):
        self.page = self.doc.new_page(width=595, height=842)
        self.page.insert_font(fontname="CounselingFont", fontbuffer=self.font.buffer)
        self.page.insert_text((46, 34), "대륜고 학종 전략실", fontname="CounselingFont", fontsize=9, color=(0.25, 0.3, 0.4))
        self.page.draw_line((46, 43), (549, 43), color=(0.8, 0.83, 0.87), width=0.5)
        self.y = 68

    def line(self, value, size=10.5, color=(0.13, 0.17, 0.22)):
        if self.y + size * 1.65 > 785:
            self.new_page()
        self.page.insert_text((46, self.y), value, fontname="CounselingFont", fontsize=size, color=color)
        self.y += size * 1.65

    def wrapped_lines(self, value, size):
        value = str(value or "")
        lines = []
        for paragraph in value.splitlines() or [""]:
            buffer = ""
            for char in paragraph:
                if char == "\x00":
                    continue
                if buffer and self.font.text_length(buffer + char, fontsize=size) > 500:
                    boundary = buffer.rfind(" ")
                    if boundary > len(buffer) // 2:
                        lines.append(buffer[:boundary])
                        buffer = buffer[boundary + 1:]
                    else:
                        lines.append(buffer)
                        buffer = ""
                buffer += char
            lines.append(buffer)
        return lines

    def write_lines(self, lines, size):
        """Keep at least two lines together at a page boundary when possible."""
        remaining = list(lines)
        while remaining:
            capacity = max(0, math.floor((785 - self.y) / (size * 1.65)))
            if capacity < min(2, len(remaining)):
                self.new_page()
                continue
            count = min(capacity, len(remaining))
            if len(remaining) - count == 1 and count > 1:
                count -= 1
            if count == 1 and len(remaining) > 1:
                # Three lines cannot split into two non-orphan fragments.
                self.new_page()
                continue
            for line in remaining[:count]:
                self.line(line, size)
            remaining = remaining[count:]
            if remaining:
                self.new_page()

    def flush_headings(self, body_lines=0, body_size=10.5):
        if not self.pending_headings:
            return
        headings = [(value, self.wrapped_lines(value, 12.5)) for value in self.pending_headings]
        first_fragment = min(3 if body_lines == 3 else 2, body_lines)
        needed = sum(14 + len(lines) * 12.5 * 1.65 for _, lines in headings) + first_fragment * body_size * 1.65
        if self.y > 68 and self.y + needed > 785:
            self.new_page()
        self.pending_headings = []
        for _, lines in headings:
            self.y += 9
            self.write_lines(lines, 12.5)
            self.y += 5

    def paragraph(self, value, size=10.5):
        lines = self.wrapped_lines(value, size)
        self.flush_headings(len(lines), size)
        self.write_lines(lines, size)
        self.y += 5

    def heading(self, value):
        self.pending_headings.append(value)

    def task(self, value, metadata):
        body = self.wrapped_lines(value, 10.5)
        details = self.wrapped_lines(metadata, 9)
        required = len(body) * 10.5 * 1.65 + len(details) * 9 * 1.65 + 10
        required += sum(14 + len(self.wrapped_lines(heading, 12.5)) * 12.5 * 1.65
                        for heading in self.pending_headings)
        # Long free-text tasks may span pages; ordinary tasks keep their deadline.
        if required <= 717 and self.y > 68 and self.y + required > 785:
            self.new_page()
        self.paragraph(value)
        self.paragraph(metadata, 9)

    def plan_text(self, value):
        """Style reference lines in place. No block parsing, deduplication or cuts.

        School references are editable prose and lack a reliable closing marker.
        A line resembling a reference is therefore only styled, never moved.
        """
        normal = []
        for line in str(value).splitlines():
            prefix = line.lstrip()
            reference = prefix.startswith(("학교 계획 참고:", "학교 활동 참고:"))
            source = prefix.startswith(("출처:", "자료 ID:", "원문 위치:"))
            condition = prefix.startswith(("조건:", "AI 관련 원문:", "원문 대상:", "원문 시기:", "적용 상태:"))
            if reference or source or condition:
                if normal:
                    self.paragraph("\n".join(normal))
                    normal = []
                if reference:
                    self.heading(line)
                else:
                    self.paragraph(line, 9 if source else 10.5)
            else:
                normal.append(line)
        if normal:
            self.paragraph("\n".join(normal))

    def source_text(self, value):
        """Style source identifiers without deleting or rewriting any source text."""
        for line in str(value).splitlines():
            self.paragraph(line, 9 if line.lstrip().startswith(("출처:", "자료 ID:", "원문 위치:")) else 10.5)

    def finish(self):
        self.flush_headings()
        count = len(self.doc)
        for index, page in enumerate(self.doc):
            page.insert_text((46, 813), "개인 전략 자료 · 로컬 보관", fontname="CounselingFont", fontsize=8, color=(0.4, 0.43, 0.48))
            page.insert_text((500, 813), f"{index + 1} / {count}", fontname="CounselingFont", fontsize=8, color=(0.4, 0.43, 0.48))
        self.doc.set_metadata({"title": self.title, "author": "대륜고 학종 전략실", "subject": self.title})
        output = self.doc.tobytes(garbage=4, deflate=True)
        self.doc.close()
        return output


def report_pdf(case, session, audience="teacher"):
    if audience not in ("teacher", "student", "analysis"):
        raise CounselingError("invalid_audience", "학생부 분석 보고서, 교사 검토용 또는 학생 안내용을 선택해 주세요.")
    if audience == "analysis":
        from .analysis_report import analysis_report_pdf
        return analysis_report_pdf(case, session)
    synthetic = case.get("origin") == "synthetic"
    confirmed = session.get("confirmed")
    imported = bool(session.get("imported_unverified"))
    unverified_analysis = imported and session.get("analysis") is not None
    unverified_record = imported and session.get("record") is not None
    valid_confirmation = bool(not (unverified_record or unverified_analysis) and confirmed and confirmed.get("content_hash") == content_hash(case, session))
    if audience == "student":
        require_consultation_complete(session)
        if not any(strategy_value(session.get("strategy", {})).values()):
            raise CounselingError("student_guidance_required", "학생 안내 내용이 없습니다. 새 전략 차수에 안내 내용을 작성한 뒤 검토·확정해 주세요.", 409)
        if not valid_confirmation:
            raise CounselingError("student_report_unconfirmed", "학생 안내 PDF는 현재 전략과 실행 과제를 교사가 검토하고 확정한 뒤 저장할 수 있습니다.", 409)
        return student_report_pdf(case, session)
    from .teacher_report import teacher_report_pdf
    return teacher_report_pdf(case, session, synthetic=synthetic,
                              valid_confirmation=valid_confirmation, imported=imported,
                              unverified_record=unverified_record,
                              unverified_analysis=unverified_analysis)
