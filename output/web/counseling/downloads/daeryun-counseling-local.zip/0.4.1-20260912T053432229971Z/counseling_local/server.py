"""Loopback-only counseling service with a separate local-only inference route."""
from __future__ import annotations

import argparse
import base64
import copy
import hashlib
import json
import mimetypes
import secrets
import ssl
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

import httpx

from . import __version__
from .analysis import ocr_record, policy_bundle, run_analysis, run_style_review
from .domain import (CounselingError, append_session, confirm_session, edit_case, import_case, manual_style_review,
                     new_case, new_id, now, object_value, require_revision, session_of, text)
from .ollama import Cancelled, Ollama, check_cancel
from .report import report_pdf
from .store import Store, private_data_root


MAX_BODY = 29 * 1024 * 1024


class Application:
    def __init__(self, root=None, data_dir=None, demo=False, models_dir=None):
        self.root = Path(root or Path(__file__).resolve().parents[1]).resolve()
        self.static = self.root / "apps/counseling/dist"
        self.store = Store(private_data_root(data_dir))
        self.demo = demo
        self.teacher = None
        self.teacher_until = 0
        self.csrf = secrets.token_urlsafe(32)
        self.ollama = Ollama(models_dir)
        self.jobs = {}
        self.jobs_lock = threading.Lock()
        self.inference_lock = threading.Lock()
        self.passwords = {}
        self._policy = None

    def user(self):
        if self.demo:
            return {"id": "synthetic-demo", "display_name": "시연 교사", "approved": True, "synthetic": True}
        if not self.teacher or time.monotonic() >= self.teacher_until:
            self.teacher = None
            raise CounselingError("teacher_required", "대륜고에서 승인된 교사 계정으로 연결해 주세요.", 401)
        return self.teacher

    def authenticate(self, access_token):
        if self.demo:
            raise CounselingError("demo_auth", "시연 모드를 종료한 뒤 교사용 실행기로 연결해 주세요.")
        token = text(access_token, 12000)
        if len(token) < 20:
            raise CounselingError("invalid_token", "대륜고 로그인 연결 정보를 확인해 주세요.", 401)
        try:
            with httpx.Client(verify=ssl.create_default_context(), trust_env=False, follow_redirects=False, timeout=12) as client:
                response = client.get("https://daeryun.life/.netlify/functions/counseling-session", headers={"Authorization": "Bearer " + token})
            if response.status_code != 200:
                raise CounselingError("teacher_required", "대륜고의 상담 교사 승인과 로그인 상태를 확인해 주세요.", 401)
            value = response.json().get("user", {})
            if value.get("approved") is not True or value.get("role") != "teacher" or not isinstance(value.get("id"), str):
                raise CounselingError("teacher_required", "이 기능은 승인된 상담 교사만 사용할 수 있습니다.", 403)
        except CounselingError:
            raise
        except (httpx.HTTPError, ValueError, AttributeError) as exc:
            raise CounselingError("auth_unavailable", "대륜고의 교사 인증 연결을 확인할 수 없습니다. 상담 API 배포와 로그인 상태를 확인해 주세요.", 503) from exc
        for job in self.jobs.values():
            if job["state"] in ("queued", "running"):
                job["_stop"].set()
        self.passwords.clear()
        self.teacher = {"id": value["id"], "display_name": text(value.get("display_name", ""), 80), "approved": True}
        self.teacher_until = time.monotonic() + 8 * 60 * 60
        return self.teacher

    def policy(self):
        if self._policy is None:
            self._policy = policy_bundle(self.root)
        return self._policy

    @staticmethod
    def job_public(job):
        return {key: value for key, value in job.items() if not key.startswith("_")}

    def start_job(self, owner, case, session_id, kind, options):
        with self.jobs_lock:
            if any(j["state"] in ("queued", "running") and j["case_id"] == case["id"] for j in self.jobs.values()):
                raise CounselingError("job_busy", "이 상담의 분석이나 검토가 진행 중입니다. 완료하거나 취소한 뒤 다시 실행해 주세요.", 409)
            job = {"id": new_id(), "state": "queued", "stage": "queued", "message": "로컬 작업을 준비하고 있습니다.", "case_id": case["id"],
                   "created_at": now(), "_owner": owner, "_stop": threading.Event(), "_transport": None}
            self.jobs[job["id"]] = job
        thread = threading.Thread(target=self._run_job, args=(job, copy.deepcopy(case), session_id, kind, options), daemon=True)
        thread.start()
        return self.job_public(job)

    def _run_job(self, job, case, session_id, kind, options):
        stop = job["_stop"]
        def progress(stage, message):
            check_cancel(stop)
            job.update(stage=stage, message=message)
        def transport(closer):
            with self.jobs_lock:
                if closer:
                    check_cancel(stop)
                job["_transport"] = closer
        try:
            with self.inference_lock:
                check_cancel(stop)
                job["state"] = "running"
                session = session_of(case, session_id)
                if session.get("confirmed"):
                    raise CounselingError("confirmed_session", "확정한 상담은 보존됩니다. 후속 상담을 추가해 주세요.", 409)
                model = options.get("model")
                if kind == "analyze":
                    if not session.get("record"):
                        raise CounselingError("record_required", "학생부 PDF를 먼저 불러와 주세요.")
                    if session.get("imported_unverified"):
                        raise CounselingError("original_required", "학생부 PDF를 다시 불러와 원문을 확인해 주세요.")
                    if session["record"].get("unreadable_pages"):
                        record = session["record"]
                        progress("reading_image", "스캔된 페이지를 확인하고 있습니다.")
                        pdf = self.store.document(record["sha256"])
                        password = self.passwords.get((job["_owner"], case["id"], record["sha256"]))
                        session["record"] = ocr_record(self.ollama, model, record, pdf, password, stop, progress, transport)
                    session["analysis"] = run_analysis(self.ollama, model, case, session, options["goal"], options["time_budget_minutes"], self.policy(), stop, progress, transport)
                    session["review"] = session["confirmed"] = None
                elif model:
                    progress("style_review", "공통 문체 기준으로 보고서를 검토하고 있습니다.")
                    session["review"] = run_style_review(self.ollama, model, case, session, self.policy(), stop, transport)
                else:
                    session["review"] = manual_style_review(case, session)
                check_cancel(stop)
                if self.user()["id"] != job["_owner"]:
                    raise CounselingError("session_changed", "교사 연결이 바뀌어 결과를 저장하지 않았습니다.", 401)
                with self.jobs_lock:
                    check_cancel(stop)
                    self.store.save(case, job["_owner"], case["revision"], kind)
                    job.update(state="succeeded", stage="completed", message="완료했습니다. 원문과 결과를 확인해 주세요.", completed_at=now())
        except Cancelled:
            job.update(state="cancelled", stage="cancelled", message="작업을 취소했습니다. 이전 상담 기록은 보존했습니다.")
        except CounselingError as exc:
            if stop.is_set():
                job.update(state="cancelled", stage="cancelled", message="작업을 취소했습니다.")
            else:
                job.update(state="needs_revision" if exc.status in (400, 409) else "failed", stage="error", message=exc.message, code=exc.code)
        except Exception:
            # Do not log exceptions containing document text, tokens, or model responses.
            job.update(state="cancelled" if stop.is_set() else "failed", stage="error", message="로컬 작업을 완료하지 못했습니다. 이전 기록은 보존했습니다.")
        finally:
            job["_transport"] = None

    def close(self):
        for job in self.jobs.values():
            job["_stop"].set()
        self.ollama.close()


class Handler(BaseHTTPRequestHandler):
    server_version = "DaeryunCounsel"
    sys_version = ""

    @property
    def app(self):
        return self.server.app

    def log_message(self, format, *args):
        pass

    def headers_safe(self, content_type, length):
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; frame-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")

    def send_bytes(self, value, content_type="application/json; charset=utf-8", status=200, filename=None):
        self.send_response(status)
        self.headers_safe(content_type, len(value))
        if filename:
            self.send_header("Content-Disposition", 'attachment; filename="' + filename + '"')
        self.end_headers()
        try:
            self.wfile.write(value)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def send_json(self, value, status=200):
        self.send_bytes(json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8"), status=status)

    def guard(self, mutating=False):
        port = self.server.server_port
        allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if self.headers.get("Host") not in allowed_hosts:
            raise CounselingError("invalid_host", "로컬 상담실 주소로 접속해 주세요.", 403)
        origin = self.headers.get("Origin")
        if origin and origin not in {"http://" + host for host in allowed_hosts}:
            raise CounselingError("invalid_origin", "다른 사이트에서는 로컬 상담 자료에 접근할 수 없습니다.", 403)
        if mutating and not secrets.compare_digest(self.headers.get("X-Counseling-Token", ""), self.app.csrf):
            raise CounselingError("csrf", "화면을 새로 연 뒤 다시 시도해 주세요.", 403)

    def body(self):
        if self.headers.get("Content-Type", "").split(";", 1)[0] != "application/json":
            raise CounselingError("content_type", "JSON 형식의 요청만 처리할 수 있습니다.", 415)
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise CounselingError("body_length", "요청 크기를 확인할 수 없습니다.") from exc
        if not 0 < size <= MAX_BODY:
            raise CounselingError("body_too_large", "파일이 너무 큽니다. PDF는 20MB 이내로 준비해 주세요.", 413)
        def pairs(items):
            result = {}
            for key, value in items:
                if key in result:
                    raise ValueError("duplicate key")
                result[key] = value
            return result
        try:
            raw = self.rfile.read(size)
            self._body_received = True
            value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                               parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite")))
        except (ValueError, UnicodeError, RecursionError) as exc:
            raise CounselingError("invalid_json", "요청 자료의 형식을 확인해 주세요.") from exc
        return object_value(value)

    def drain_rejected_body(self):
        # On Windows closing a socket with unread request bytes can reset the
        # connection and discard the 403. Drain only already submitted small
        # bodies, with a short bound; never parse/store an unauthorized body.
        if getattr(self, "_body_received", False):
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if 0 < size <= 65536 and not self.headers.get("Transfer-Encoding"):
                previous = self.connection.gettimeout()
                try:
                    self.connection.settimeout(0.2)
                    self.rfile.read(size)
                finally:
                    self.connection.settimeout(previous)
        except (ValueError, OSError):
            pass

    def do_OPTIONS(self):
        self.send_json({"error": {"code": "local_only", "message": "로컬 화면에서만 접근할 수 있습니다."}}, 403)

    def do_GET(self):
        self.dispatch(False)

    def do_POST(self):
        self.dispatch(True)

    def do_PUT(self):
        self.dispatch(True)

    def dispatch(self, mutating):
        self._body_received = False
        try:
            self.guard(mutating)
            parts = urlsplit(self.path)
            path = unquote(parts.path)
            query = parse_qs(parts.query)
            if not path.startswith("/api/"):
                if mutating:
                    raise CounselingError("method", "지원하지 않는 요청입니다.", 405)
                return self.static_file(path)
            body = self.body() if mutating else {}
            if path == "/api/health" and not mutating:
                teacher = self.app.teacher if time.monotonic() < self.app.teacher_until else None
                return self.send_json({"version": __version__, "mode": "local", "demo": self.app.demo, "csrf_token": self.app.csrf,
                                       "teacher": teacher, "storage_path": str(self.app.store.root), "ollama": self.app.ollama.status()})
            if path == "/api/auth" and self.command == "POST":
                return self.send_json({"teacher": self.app.authenticate(body.get("access_token", ""))})
            user = self.app.user()
            owner = user["id"]
            if path == "/api/fixtures" and not mutating:
                from .fixtures import list_fixtures
                return self.send_json({"fixtures": list_fixtures()})
            if path.startswith("/api/fixtures/") and path.endswith(".pdf") and not mutating:
                from .fixtures import fixture_pdf
                fixture_id = path.rsplit("/", 1)[1][:-4]
                return self.send_bytes(fixture_pdf(fixture_id), "application/pdf", filename="synthetic-record.pdf")
            if path == "/api/cases":
                if self.command == "GET":
                    return self.send_json({"cases": self.app.store.list(owner)})
                if self.command == "POST":
                    case = new_case(body.get("student", {}), {"display_name": user["display_name"]}, "synthetic" if self.app.demo else "teacher")
                    return self.send_json({"case": self.app.store.create(case, owner)}, 201)
            if path == "/api/import" and self.command == "POST":
                case = import_case(body.get("bundle"), {"display_name": user["display_name"]}, "synthetic" if self.app.demo else "teacher")
                return self.send_json({"case": self.app.store.create(case, owner)}, 201)
            if path.startswith("/api/jobs/"):
                segments = path.split("/")
                job = self.app.jobs.get(segments[3])
                if not job or job["_owner"] != owner:
                    raise CounselingError("job_not_found", "작업을 찾을 수 없습니다.", 404)
                if self.command == "POST" and len(segments) == 5 and segments[4] == "cancel":
                    with self.app.jobs_lock:
                        if job["state"] in ("queued", "running"):
                            job["_stop"].set()
                            job.update(state="cancelled", stage="cancelled", message="취소했습니다. 이전 기록을 보존합니다.")
                            closer = job.get("_transport")
                        else:
                            closer = None
                    if closer:
                        threading.Thread(target=closer, daemon=True).start()
                elif self.command != "GET":
                    raise CounselingError("method", "지원하지 않는 요청입니다.", 405)
                return self.send_json({"job": self.app.job_public(job)})
            if path.startswith("/api/cases/"):
                segments = path.split("/")
                case = self.app.store.get(segments[3], owner)
                action = segments[4] if len(segments) == 5 else ""
                if len(segments) not in (4, 5):
                    raise CounselingError("not_found", "요청한 기능을 찾을 수 없습니다.", 404)
                if self.command == "GET":
                    if not action:
                        return self.send_json({"case": case})
                    if action == "export":
                        value = {"format": "daeryun-counseling", "version": 1, "case": case}
                        return self.send_bytes(json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8"), filename=f"counseling-{case['id'][:8]}.json")
                    if action == "history":
                        return self.send_json({"versions": self.app.store.history(case["id"], owner)})
                    if action == "report.pdf":
                        session = session_of(case, query.get("session_id", [case["current_session_id"]])[0])
                        audiences = query.get("audience", ["teacher"])
                        if len(audiences) != 1:
                            raise CounselingError("invalid_audience", "보고서 대상을 하나만 선택해 주세요.")
                        audience = audiences[0]
                        return self.send_bytes(report_pdf(case, session, audience=audience), "application/pdf",
                                               filename=f"counseling-{case['id'][:8]}-{audience}.pdf")
                if self.command == "PUT" and not action:
                    incoming = object_value(body.get("case"))
                    if not self.app.demo and incoming.get("teacher", {}).get("display_name") != user["display_name"]:
                        raise CounselingError("teacher_identity", "상담 교사는 인증된 계정으로 기록됩니다.", 403)
                    updated = edit_case(case, incoming)
                    return self.send_json({"case": self.app.store.save(updated, owner, case["revision"])})
                if self.command == "POST":
                    require_revision(case, body.get("revision"))
                    if action == "sessions":
                        return self.send_json({"case": self.app.store.save(append_session(case), owner, case["revision"], "next_session")})
                    session_id = body.get("session_id", case["current_session_id"])
                    session = session_of(case, session_id)
                    if session.get("confirmed"):
                        raise CounselingError("confirmed_session", "확정한 상담은 보존됩니다. 후속 상담을 추가해 주세요.", 409)
                    if action == "record":
                        return self.upload_record(case, session, owner, body)
                    if action in ("analyze", "review"):
                        model = text(body.get("model", ""), 160)
                        if action == "analyze" and not model:
                            raise CounselingError("model_required", "로컬 모델을 선택해 주세요.")
                        options = {"model": model, "goal": text(body.get("goal", ""), 3000), "time_budget_minutes": body.get("time_budget_minutes", 60)}
                        if type(options["time_budget_minutes"]) is not int or not 5 <= options["time_budget_minutes"] <= 600:
                            raise CounselingError("time_budget", "실천 시간은 5분부터 600분 사이로 입력해 주세요.")
                        return self.send_json({"job": self.app.start_job(owner, case, session_id, action, options)}, 202)
                    if action == "confirm":
                        updated = confirm_session(case, session_id, owner, body.get("review_acknowledged"))
                        if self.app.demo:
                            session_of(updated, session_id)["confirmed"]["synthetic"] = True
                        return self.send_json({"case": self.app.store.save(updated, owner, case["revision"], "confirmed")})
            raise CounselingError("not_found", "요청한 기능을 찾을 수 없습니다.", 404)
        except CounselingError as exc:
            self.drain_rejected_body()
            self.send_json({"error": {"code": exc.code, "message": exc.message}}, exc.status)
        except Exception:
            self.send_json({"error": {"code": "internal_error", "message": "요청을 완료하지 못했습니다. 원본을 보존하고 다시 시도해 주세요."}}, 500)

    def upload_record(self, case, session, owner, body):
        from .records import extract_record
        filename = text(body.get("filename", ""), 200)
        try:
            encoded = body.get("pdf_base64")
            if not isinstance(encoded, str):
                raise ValueError()
            pdf = base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise CounselingError("invalid_pdf", "PDF 파일을 읽을 수 없습니다. 파일을 다시 선택해 주세요.") from exc
        if len(pdf) > 20 * 1024 * 1024:
            raise CounselingError("pdf_too_large", "PDF는 20MB 이내로 준비해 주세요.", 413)
        file_hash = hashlib.sha256(pdf).hexdigest()
        if self.app.demo:
            from .fixtures import fixture_pdf, list_fixtures
            fixture_hashes = {hashlib.sha256(fixture_pdf(item["id"])).hexdigest() for item in list_fixtures()}
            if file_hash not in fixture_hashes:
                raise CounselingError("demo_fixture_only", "시연에서는 제공된 합성 PDF만 사용할 수 있습니다. 실제 학생부는 교사 인증 후 로컬 실행기에서 열어 주세요.", 403)
        password = body.get("password")
        if password is not None:
            password = text(password, 500)
        try:
            record = extract_record(pdf, filename, password)
        except ValueError as exc:
            raise CounselingError(getattr(exc, "code", "invalid_pdf"), getattr(exc, "message", "PDF를 읽을 수 없습니다. 암호와 파일 형식을 확인해 주세요.")) from exc
        # Parse completely before persisting anything; failed uploads keep the previous record.
        self.app.store.save_document(file_hash, pdf)
        if password:
            self.app.passwords[(owner, case["id"], file_hash)] = password
        session["record"], session["analysis"], session["review"], session["confirmed"] = record, None, None, None
        session.pop("imported_unverified", None)
        return self.send_json({"case": self.app.store.save(case, owner, case["revision"], "record_loaded")})

    def static_file(self, path):
        if path in ("", "/"):
            self.send_response(302)
            self.send_header("Location", "/counseling/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if not path.startswith("/counseling/"):
            raise CounselingError("not_found", "화면을 찾을 수 없습니다.", 404)
        relative = path[len("/counseling/"):] or "index.html"
        file = (self.app.static / relative).resolve()
        if not file.is_relative_to(self.app.static.resolve()) or file.suffix not in (".html", ".js", ".css", ".svg", ".png", ".ico", ".woff2", ".woff"):
            raise CounselingError("not_found", "화면을 찾을 수 없습니다.", 404)
        if not file.is_file():
            raise CounselingError("frontend_missing", "상담 화면 빌드가 필요합니다. 실행 안내를 확인해 주세요.", 404)
        content_type = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        if file.suffix == ".js":
            content_type = "application/javascript"
        self.send_bytes(file.read_bytes(), content_type + ("; charset=utf-8" if file.suffix in (".html", ".js", ".css", ".svg") else ""))


class Server(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, app):
        self.app = app
        super().__init__(address, Handler)


def main(argv=None):
    parser = argparse.ArgumentParser(description="대륜고 상담실 로컬 실행")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir")
    parser.add_argument("--models-dir", help="기존 Ollama 모델 폴더. 모델을 다운로드하거나 이동하지 않습니다.")
    parser.add_argument("--demo", action="store_true", help="합성 PDF만 사용하는 시연 모드")
    parser.add_argument("--open", action="store_true", help="브라우저 열기")
    args = parser.parse_args(argv)
    app = Application(data_dir=args.data_dir, demo=args.demo, models_dir=args.models_dir)
    server = Server(("127.0.0.1", args.port), app)
    url = f"http://127.0.0.1:{server.server_port}/counseling/"
    print(url, flush=True)
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        app.close()


if __name__ == "__main__":
    main()
